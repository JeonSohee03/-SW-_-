# Inventory source of truth

Android 앱은 약 잔량을 계산하지 않습니다.

표시에 사용하는 Firebase 값은 다음 3개뿐입니다.

- `devices/{deviceId}/inventory/remainingDoseCountByPeriod/morning`
- `devices/{deviceId}/inventory/remainingDoseCountByPeriod/evening`
- `devices/{deviceId}/inventory/remainingDoseCount`

`initialDays`, `remainingDays`는 Android의 잔량 표시/추가/배출 계산에 사용하지 않습니다.

초기 투입, 약 추가, 약 꺼내기는 Android가 `commands`에 요청만 생성합니다. ESP32가 실제 수량을 계산하고 위 3개 inventory 값을 갱신하면 Android의 Firebase ValueEventListener가 변경값을 받아 Compose 화면에 그대로 반영합니다.

명령 타입:
- `INITIALIZE_INVENTORY` (`loadedDays`)
- `ADD_MEDICATION_STOCK` (`days`)
- `WITHDRAW_MEDICATION` (`morningDays`, `eveningDays`)
