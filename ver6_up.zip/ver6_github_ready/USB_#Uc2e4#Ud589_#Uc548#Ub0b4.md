# USB로 실제 Android 휴대폰에서 실행하기

이 프로젝트는 QR 코드나 무선 디버깅 전용 프로젝트가 아닙니다. 앱 소스를 바꾸는 대신 Android Studio에서 실행 대상을 USB로 연결된 휴대폰으로 선택하면 됩니다.

## 1. 휴대폰 설정

1. 설정 → 휴대전화 정보 → 소프트웨어 정보로 이동합니다.
2. `빌드번호`를 7번 눌러 개발자 옵션을 활성화합니다.
3. 설정 → 개발자 옵션 → `USB 디버깅`을 켭니다.

## 2. USB 연결

1. 데이터 전송을 지원하는 USB 케이블로 휴대폰과 PC를 연결합니다.
2. 휴대폰 USB 알림에서 `파일 전송 / Android Auto`를 선택합니다.
3. `이 컴퓨터에서 USB 디버깅을 허용하시겠습니까?`가 나오면 `항상 허용`을 체크하고 `허용`을 누릅니다.

## 3. 연결 확인

프로젝트 폴더의 `USB_연결확인.bat`를 더블클릭합니다.

정상 연결 예시:

```text
List of devices attached
R3XXXXXXXX    device
```

- `device`: 정상 연결
- `unauthorized`: 휴대폰 화면에서 USB 디버깅 허용 필요
- 기기가 안 나옴: 케이블, USB 포트, 휴대폰 USB 모드, 제조사 USB 드라이버 확인

## 4. Android Studio에서 실행

1. Android Studio에서 `SmartMedicationCareV2` 폴더를 엽니다.
2. Gradle Sync가 끝날 때까지 기다립니다.
3. 상단 기기 선택 메뉴에서 연결된 휴대폰을 선택합니다.
4. `▶ Run app`을 누릅니다.

## 이번 수정 내용

- USB 연결 확인용 Windows 배치 파일 추가
- USB 실행 절차 문서 추가
- Material 3 `TopAppBar` 사용 파일에 실험 API 허용 설정 추가

USB 방식과 QR/무선 방식은 앱 코드 버전 차이가 아니라 설치할 기기를 연결하는 방식의 차이입니다.
