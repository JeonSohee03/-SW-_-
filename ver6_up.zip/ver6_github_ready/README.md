# SmartMedicationCare Ver 5

이 수정본은 Firebase를 `users/{uid}`와 `devices/{deviceId}`로 분리한 기존 v5에
동의·회원가입, B-OMM Wi-Fi 등록, 로드셀 영점 초기 설정, 복용자·약·복용 시간
온보딩과 상세 기기 관리 화면을 추가했습니다. 전체 구조는
`VER5_변경사항_및_최종데이터구조.md`, ESP32 구현 규격은
`ESP32_앱연동_구현요청.md`를 확인하세요.

## QR로 여는 아이폰 스타일 웹앱 (추가됨)

`web/` 폴더에는 휴대폰 카메라로 QR을 촬영해 바로 접속할 수 있는
설치형 웹앱(PWA)이 들어 있습니다. Android 앱과 동일한 Firebase 경로인
`users/{uid}`를 실시간 구독하므로 같은 계정으로 로그인하면 누적된 복약,
중량, 재고, 알림 데이터가 그대로 표시됩니다.

1. Firebase Console의 **프로젝트 설정 > 내 앱 > 웹 앱 추가**에서 웹 설정값을 확인합니다.
2. `web/firebase-config.js`의 `PASTE_...` 값을 실제 설정값으로 교체합니다.
3. `.firebaserc.example`을 `.firebaserc`로 복사하고 프로젝트 ID를 입력합니다.
4. 프로젝트 루트에서 `firebase deploy --only hosting`을 실행합니다.
5. 출력된 `https://프로젝트ID.web.app` 주소로 QR코드를 만듭니다.

QR에는 비밀번호나 Firebase 비밀키가 아니라 위의 **웹 주소만** 넣습니다.
웹 설정 전에는 로그인 화면의 `데모 화면 미리보기`로 디자인을 확인할 수 있습니다.

사용자가 제공한 화면 시안을 기준으로 만든 Android Studio 기본 구조입니다.

## 구현 화면

- 개인정보·알림 동의
- 로그인·회원가입
- B-OMM 연결 후 ESP32 캡티브 포털에서 집 Wi-Fi 설정
- 로드셀 영점 초기 설정
- 복용자·약·복용 시간 초기 설정
- 메인 복약 현황
- 다음 알림
- 주의 알림
- 복약 기록 상세
- 약 현황 요약
- 약 현황 그래프
- 약 현황 표
- 약 정보
- 약 등록·변경
- 부작용 메모
- 상태 체크
- 더보기

## 웹·Android 공통 상태 체크

웹과 Android 앱 모두 **상태 체크** 탭에서 식사·수면·활동·기분을
`좋음 / 보통 / 나쁨` 중 하나로 선택합니다. 선택값은 각각 3/2/1로 저장하고
네 항목을 0~100점으로 환산해 월간 달력에 상태 단계로 표시합니다. 날짜를
선택하면 그날의 상태와 메모를 확인하거나 수정할 수 있습니다. 오늘 기록을
저장한 뒤에는 입력란이 닫히고 `수정하기` 버튼만 표시됩니다.

Firebase 저장 경로는 다음과 같습니다.

`users/{uid}/healthHistory/{yyyy-MM-dd}`

같은 날짜에 다시 저장하면 그 날짜의 기록이 갱신되므로 중복되지 않습니다.

## 월간 기록 및 알림

- 다음 복용 알림은 최근 실제 복용 시각에서 12시간 이후로 직접 설정하며
  `users/{uid}/nextAlarmMillis`에 저장합니다.
- 알림 날짜와 시간은 글자를 입력하지 않고 날짜 선택창과 시계 선택창으로 맞춥니다.
- 홈과 약 현황은 `medication/timesPerDay`가 1이면 아침, 2이면 아침·저녁,
  3이면 아침·점심·저녁 슬롯을 자동 생성합니다. 화면에서 복용 횟수를
  고정하지 않으며 Firebase 초기 입력값이 기준입니다.
- 약 현황의 월간 달력은 날짜별 `TAKEN` 개수를 `timesPerDay`로 나눈 진행률만큼
  날짜 둘레의 원을 채웁니다. `hasAnomaly`, `deviceError`, `switchError`,
  `anomalyMessage` 또는 해당 날짜의 `alerts`가 있으면 작은 `!`를 표시합니다.
- 홈, 약 현황 달력, 오늘 현황은 모두 같은 `doseRecords`를 날짜별로 사용하며
  아침·저녁의 `measuredWeightGram`을 각각 표시합니다.
- 여러 종류의 약은 `users/{uid}/medications` 목록으로 저장하고 첫 번째 약은
  기존 ESP32/앱 호환을 위해 `medication`에도 함께 저장합니다.
- 부작용 메모는 `users/{uid}/sideEffectHistory/{yyyy-MM-dd}`에 날짜별로 저장합니다.
- API/AI 코멘트 영역은 약 주의사항과 사용자가 적은 신체 변화 메모를 함께
  보여주는 보조 영역입니다. 실제 진단을 대신하지 않습니다.

ESP32가 확정한 1회 복약 결과는 다음 위치에 저장해야 Android와 웹에 동시에
반영됩니다.

`users/{uid}/doseRecords/{yyyy-MM-dd_PERIOD}`

필수 필드는 `date`, `period`, `status`이며, 센서 결과에 따라
`dispensedAtMillis`, `takenAtMillis`, `measuredWeightGram`을 함께 기록합니다.
인지 반응 프로그램 결과인 `programScore`와 `reactionTimeMillis`는 아침 기록에만
저장합니다. 화면은 이 값을 생성하거나 임의로 변경하지 않습니다.

## 중요한 구조

앱 안에는 다음 버튼이 없습니다.

- 치매 예방 프로그램 실행 버튼
- 약 제공 버튼
- 열감지 센서 수동 입력 버튼
- 로드셀 값 수동 입력 버튼

해당 기능은 기기 자체 LCD 및 물리 버튼에서 실행합니다.
기기는 반응 시간, 프로그램 점수, 약 배출 시각, 열감지 복용 시각,
로드셀 중량을 Firebase에 업로드하고 앱은 결과만 표시합니다.

## 실행

1. Android Studio에서 프로젝트 폴더를 엽니다.
2. Gradle Sync를 실행합니다.
3. 에뮬레이터 또는 Android 휴대폰으로 실행합니다.
4. Firebase 모드에서는 회원가입 후 생성한 계정으로 로그인합니다.
5. Fake 모드에서는 임의 이메일과 4자 이상의 비밀번호로 로그인합니다.

`app/google-services.json`이 없으면 Fake 데이터로, 파일이 있으면 Firebase 데이터로
자동 실행됩니다. 따라서 데모 확인용 ZIP도 빌드가 깨지지 않습니다.

## Firebase 실제 연결

- Firebase Android 앱의 패키지명을 `com.example.smartmedicationcare`로 등록
- 내려받은 `google-services.json`을 `app/` 폴더에 추가
- Gradle Sync 실행 (`USE_FIREBASE`와 Google Services 플러그인은 자동 활성화)
- Authentication Email/Password 활성화
- Realtime Database 활성화

## USB 실제 기기 실행 수정본

USB 실행 절차는 `USB_실행_안내.md`를 확인하세요. Windows에서는 `USB_연결확인.bat`를 실행해 ADB 연결 상태를 확인할 수 있습니다.
