package com.example.smartmedicationcare.ui.screen

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp

@Composable
fun ConsentScreen(onComplete: () -> Unit) {
    var privacy by remember { mutableStateOf(false) }
    var notification by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center) {
        Text("B-OMM 시작하기", style = MaterialTheme.typography.headlineLarge)
        Spacer(Modifier.height(20.dp))
        Text("서비스 이용을 위해 아래 항목을 확인해 주세요.")
        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(privacy, { privacy = it }); Text("개인정보 수집·이용 동의 (필수)")
        }
        Text("계정, 복약자 정보, 보호자 연락처와 기기 상태를 복약관리 목적으로 저장합니다.", style = MaterialTheme.typography.bodySmall)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(notification, { notification = it }); Text("복약 및 기기 알림 수신 동의 (필수)")
        }
        Button(onComplete, enabled = privacy && notification, modifier = Modifier.fillMaxWidth()) { Text("다음") }
    }
}

@Composable
fun LoginScreen(
    message: String,
    onLogin: (String, String) -> Unit,
    onSignup: () -> Unit,
    onBack: () -> Unit
) {
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    Box(Modifier.fillMaxSize()) {
        IconButton(onClick = onBack, modifier = Modifier.padding(12.dp).align(Alignment.TopStart)) {
            Icon(Icons.Rounded.ArrowBack, "이전")
        }
        Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center) {
            Text("B-OMM", style = MaterialTheme.typography.headlineLarge)
            Text("복약 기록과 기기 상태를 확인하세요.")
            Spacer(Modifier.height(24.dp))
            OutlinedTextField(email, { email = it }, label = { Text("이메일") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(password, { password = it }, label = { Text("비밀번호") },
                visualTransformation = PasswordVisualTransformation(), singleLine = true, modifier = Modifier.fillMaxWidth())
            if (message.isNotBlank()) Text(message, color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.bodySmall)
            Spacer(Modifier.height(14.dp))
            Button({ onLogin(email.trim(), password) }, enabled = email.isNotBlank() && password.isNotBlank(), modifier = Modifier.fillMaxWidth()) { Text("로그인") }
            OutlinedButton(onSignup, modifier = Modifier.fillMaxWidth()) { Text("회원가입") }
        }
    }
}

@Composable
fun SignupScreen(message: String, onBack: () -> Unit, onSignup: (String, String) -> Unit) {
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var confirmation by remember { mutableStateOf("") }
    val valid = email.contains("@") && password.length >= 6 && password == confirmation
    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center) {
        Text("회원가입", style = MaterialTheme.typography.headlineLarge)
        Spacer(Modifier.height(20.dp))
        OutlinedTextField(email, { email = it }, label = { Text("이메일") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(password, { password = it }, label = { Text("비밀번호(6자 이상)") },
            visualTransformation = PasswordVisualTransformation(), singleLine = true, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(confirmation, { confirmation = it }, label = { Text("비밀번호 확인") },
            visualTransformation = PasswordVisualTransformation(), singleLine = true, modifier = Modifier.fillMaxWidth())
        if (message.isNotBlank()) {
            Text(
                text = message,
                color = MaterialTheme.colorScheme.primary,
                style = MaterialTheme.typography.bodySmall
            )
        }
        Spacer(Modifier.height(8.dp))
        Button({ onSignup(email.trim(), password) }, enabled = valid, modifier = Modifier.fillMaxWidth()) { Text("가입 완료") }
        TextButton(onBack, modifier = Modifier.align(Alignment.CenterHorizontally)) { Text("로그인으로 돌아가기") }
    }
}
