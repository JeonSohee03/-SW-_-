@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
package com.example.smartmedicationcare.ui.screen

import android.Manifest
import android.content.Intent
import android.content.Context
import android.content.pm.PackageManager
import android.net.wifi.WifiManager
import android.os.Build
import android.provider.Settings
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.example.smartmedicationcare.model.AppUiState

@Composable
fun WifiSetupScreen(
    state: AppUiState,
    onBack: (() -> Unit)? = null,
    onRegister: (String) -> Unit,
    onComplete: () -> Unit
) {
    val context = LocalContext.current
    val deviceId = state.profile.deviceId.ifBlank { "BOMM-001" }
    var step by rememberSaveable { mutableIntStateOf(0) }
    var showWebView by rememberSaveable { mutableStateOf(false) }
    var wifiSetupComplete by rememberSaveable { mutableStateOf(false) }
    var connectedSsid by remember { mutableStateOf<String?>(null) }
    val bommConnected = connectedSsid.equals("B-OMM", ignoreCase = true)
    val lifecycleOwner = LocalLifecycleOwner.current

    fun refreshWifiConnection() {
        connectedSsid = currentWifiSsid(context)
    }

    fun openWifiSettings() {
        val action = if (Build.VERSION.SDK_INT >= 29) Settings.Panel.ACTION_WIFI else Settings.ACTION_WIFI_SETTINGS
        context.startActivity(Intent(action))
    }

    val wifiPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) {
        refreshWifiConnection()
        openWifiSettings()
    }

    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) refreshWifiConnection()
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        refreshWifiConnection()
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    if (showWebView) {
        BommPortalWebView(
            onBack = { showWebView = false },
            onComplete = {
                showWebView = false
                wifiSetupComplete = true
                step = 2
                onRegister(deviceId)
            }
        )
        return
    }

    Scaffold(topBar = {
        TopAppBar(title = { Text("Wi-Fi 설정") }, navigationIcon = {
            if (onBack != null) IconButton({ if (step > 0) step-- else onBack.invoke() }) {
                Icon(Icons.Rounded.ArrowBack, "뒤로")
            }
        })
    }, bottomBar = {
        Surface(shadowElevation = 8.dp) {
            Button(
                onClick = {
                    when (step) {
                        0 -> step = 1
                        1 -> showWebView = true
                        else -> onComplete()
                    }
                },
                enabled = when (step) {
                    0 -> bommConnected
                    1 -> true
                    else -> wifiSetupComplete
                },
                modifier = Modifier.fillMaxWidth().padding(16.dp)
            ) { Text("다음") }
        }
    }) { padding ->
        Column(
            Modifier.padding(padding).padding(20.dp).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            LinearProgressIndicator(progress = { (step + 1) / 3f }, modifier = Modifier.fillMaxWidth())
            when (step) {
                0 -> {
                    Text("1. B-OMM Wi-Fi 연결", style = MaterialTheme.typography.headlineSmall)
                    InstructionCard(listOf(
                        "기기의 전원을 켜고 B-OMM Wi-Fi가 나타날 때까지 기다려 주세요.",
                        "Wi-Fi 목록에서 B-OMM을 선택해 주세요.",
                        "B-OMM은 비밀번호가 없는 초기 설정용 네트워크입니다.",
                        "인터넷 연결 안내가 나와도 B-OMM 연결을 유지해 주세요."
                    ))
                    OutlinedButton({
                        val permissions = buildList {
                            add(Manifest.permission.ACCESS_FINE_LOCATION)
                            if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.NEARBY_WIFI_DEVICES)
                        }.filter {
                            ContextCompat.checkSelfPermission(context, it) != PackageManager.PERMISSION_GRANTED
                        }
                        if (permissions.isEmpty()) openWifiSettings()
                        else wifiPermissionLauncher.launch(permissions.toTypedArray())
                    }, modifier = Modifier.fillMaxWidth()) { Text("B-OMM 연결") }
                    Text(
                        if (bommConnected) "연결 확인: B-OMM" else "B-OMM 연결을 확인하고 있습니다.",
                        color = if (bommConnected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                1 -> {
                    Text("2. 집 Wi-Fi 설정", style = MaterialTheme.typography.headlineSmall)
                    InstructionCard(listOf(
                        "B-OMM 연결 상태를 유지해 주세요.",
                        "다음을 누르면 앱 안에서 설정 화면이 열립니다.",
                        "집 Wi-Fi를 선택하고 비밀번호를 입력해 주세요.",
                        "정보는 ESP32 내부에만 저장됩니다."
                    ))
                }
                else -> {
                    Text("3. Wi-Fi 설정 완료", style = MaterialTheme.typography.headlineSmall)
                    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("B-OMM Wi-Fi 설정 완료", style = MaterialTheme.typography.titleMedium)
                            Text("기기 ID: $deviceId")
                            Text("연결 상태: ${state.deviceNetworkStatus}")
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun BommPortalWebView(
    onBack: () -> Unit,
    onComplete: () -> Unit
) {
    var webView by remember { mutableStateOf<WebView?>(null) }
    BackHandler {
        val current = webView
        if (current?.canGoBack() == true) current.goBack() else onBack()
    }

    DisposableEffect(Unit) {
        onDispose {
            webView?.stopLoading()
            webView?.destroy()
            webView = null
        }
    }

    Scaffold(topBar = {
        TopAppBar(
            title = { Text("B-OMM Wi-Fi 설정") },
            navigationIcon = { IconButton(onBack) { Icon(Icons.Rounded.ArrowBack, "뒤로") } }
        )
    }) { padding ->
        AndroidView(
            modifier = Modifier.padding(padding).fillMaxSize(),
            factory = { context ->
                WebView(context).apply {
                    webView = this
                    settings.javaScriptEnabled = true
                    settings.domStorageEnabled = true
                    webViewClient = object : WebViewClient() {
                        override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                            val url = request.url.toString()
                            return if (url.startsWith("bomm://close")) {
                                onComplete()
                                true
                            } else {
                                false
                            }
                        }
                    }
                    loadUrl("http://192.168.4.1/")
                }
            }
        )
    }
}

@Suppress("DEPRECATION")
private fun currentWifiSsid(context: Context): String? {
    val fineLocationGranted = ContextCompat.checkSelfPermission(
        context, Manifest.permission.ACCESS_FINE_LOCATION
    ) == PackageManager.PERMISSION_GRANTED
    val nearbyGranted = Build.VERSION.SDK_INT < 33 || ContextCompat.checkSelfPermission(
        context, Manifest.permission.NEARBY_WIFI_DEVICES
    ) == PackageManager.PERMISSION_GRANTED
    if (!fineLocationGranted || !nearbyGranted) return null

    val wifiManager = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
    return wifiManager.connectionInfo?.ssid
        ?.removeSurrounding("\"")
        ?.takeUnless { it.isBlank() || it == WifiManager.UNKNOWN_SSID }
}

@Composable
private fun InstructionCard(lines: List<String>) {
    Card { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        lines.forEach { Text("• $it") }
    } }
}

@Composable
fun WifiDetailScreen(state: AppUiState, onBack: () -> Unit, onReconnect: () -> Unit) {
    SimpleDetailScaffold("Wi-Fi 설정", onBack) {
        Text("연결 상태", style = MaterialTheme.typography.titleMedium)
        Text(state.deviceNetworkStatus)
        Text("기기 ID: ${state.profile.deviceId.ifBlank { "미등록" }}")
        Button(onReconnect, modifier = Modifier.fillMaxWidth()) { Text("Wi-Fi 재연결") }
    }
}

@Composable
fun DeviceDetailScreen(state: AppUiState, onBack: () -> Unit) {
    SimpleDetailScaffold("기기 상태", onBack) {
        Text("기기 상태", style = MaterialTheme.typography.titleMedium)
        Text(state.deviceStatus, style = MaterialTheme.typography.headlineMedium)
        Text("ESP32가 내부 로직으로 판단해 Firebase에 전달한 기기 상태를 표시합니다.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text("네트워크: ${state.deviceNetworkStatus}")
        Text("기기 ID: ${state.profile.deviceId.ifBlank { "미등록" }}")
    }
}

@Composable
private fun SimpleDetailScaffold(title: String, onBack: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    Scaffold(topBar = { TopAppBar(title = { Text(title) }, navigationIcon = { IconButton(onBack) { Icon(Icons.Rounded.ArrowBack, "뒤로") } }) }) {
        Column(Modifier.padding(it).padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp), content = content)
    }
}
