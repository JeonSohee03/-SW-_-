package com.example.smartmedicationcare.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ChevronLeft
import androidx.compose.material.icons.rounded.ChevronRight
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import java.time.LocalDate
import java.time.YearMonth

@Composable
fun MonthCalendar(
    selectedDate: LocalDate,
    onDateSelected: (LocalDate) -> Unit,
    dayProgress: (LocalDate) -> Float? = { null },
    dayProgressColor: (LocalDate) -> Color = { Color(0xFF34C759) },
    dayMarker: @Composable (LocalDate) -> Unit = {}
) {
    var month by remember(selectedDate) { mutableStateOf(YearMonth.from(selectedDate)) }
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            IconButton({ month = month.minusMonths(1) }) { Icon(Icons.Rounded.ChevronLeft, "이전 달") }
            Text("${month.year}년 ${month.monthValue}월", style = MaterialTheme.typography.titleMedium)
            IconButton({ month = month.plusMonths(1) }) { Icon(Icons.Rounded.ChevronRight, "다음 달") }
        }
        Row(Modifier.fillMaxWidth()) {
            listOf("일", "월", "화", "수", "목", "금", "토").forEach { Text(it, modifier = Modifier.weight(1f), color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall, textAlign = androidx.compose.ui.text.style.TextAlign.Center) }
        }
        val offset = month.atDay(1).dayOfWeek.value % 7
        val cells = offset + month.lengthOfMonth()
        repeat((cells + 6) / 7) { week ->
            Row(Modifier.fillMaxWidth()) {
                repeat(7) { column ->
                    val day = week * 7 + column - offset + 1
                    if (day !in 1..month.lengthOfMonth()) Spacer(Modifier.weight(1f).height(54.dp))
                    else {
                        val date = month.atDay(day)
                        val selected = date == selectedDate
                        Column(
                            Modifier.weight(1f).height(54.dp).clickable { onDateSelected(date) },
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Box(Modifier.size(38.dp), contentAlignment = Alignment.Center) {
                                dayProgress(date)?.let { progress ->
                                    CircularProgressIndicator(
                                        progress = { progress.coerceIn(0f, 1f) },
                                        modifier = Modifier.fillMaxSize(),
                                        color = dayProgressColor(date),
                                        trackColor = MaterialTheme.colorScheme.surfaceVariant,
                                        strokeWidth = 4.dp
                                    )
                                }
                                Box(Modifier.size(30.dp).background(if (selected) MaterialTheme.colorScheme.primary else Color.Transparent, CircleShape), contentAlignment = Alignment.Center) {
                                Text(day.toString(), color = if (selected) Color.White else MaterialTheme.colorScheme.onSurface, fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal)
                                }
                            }
                            dayMarker(date)
                        }
                    }
                }
            }
        }
    }
}
