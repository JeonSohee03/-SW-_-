@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
package com.example.smartmedicationcare.ui.screen

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.smartmedicationcare.model.*
import com.example.smartmedicationcare.ui.components.SelectionDropdown
import java.time.LocalDate
import java.time.LocalTime
import java.time.Period
import java.time.ZoneOffset
import java.time.temporal.ChronoUnit

@Composable
fun PatientInfoScreen(initial: UserProfile = UserProfile(), onBack: (() -> Unit)? = null, onSave: (UserProfile) -> Unit) {
    val today = LocalDate.now()
    val initialBirthDate = remember(initial.dateOfBirth) {
        runCatching { LocalDate.parse(initial.dateOfBirth) }.getOrNull()
    }
    val oldestSelectYear = today.year - 100
    val yearOptions = remember(today.year) { (today.year downTo oldestSelectYear).map(Int::toString) + "직접 입력" }
    var selectedYearOption by remember {
        mutableStateOf(initialBirthDate?.year?.takeIf { it >= oldestSelectYear }?.toString()
            ?: if (initialBirthDate != null) "직접 입력" else "")
    }
    var directYear by remember { mutableStateOf(initialBirthDate?.year?.takeIf { it < oldestSelectYear }?.toString().orEmpty()) }
    var birthDate by remember { mutableStateOf(initialBirthDate) }
    var showBirthCalendar by remember { mutableStateOf(false) }
    var gender by remember { mutableStateOf(initial.gender) }
    var height by remember { mutableStateOf(initial.heightCm.takeIf { it > 0 }?.toString().orEmpty()) }
    var weight by remember { mutableStateOf(initial.weightKg.takeIf { it > 0 }?.toString().orEmpty()) }
    var caregiver by remember { mutableStateOf(initial.caregiverPhoneNumber) }
    Scaffold(topBar = { TopAppBar(title = { Text("약 복용자 정보") }, navigationIcon = {
        if (onBack != null) IconButton(onBack) { Icon(Icons.Rounded.ArrowBack, "뒤로") }
    }) }) { padding ->
        Column(Modifier.padding(padding).padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            SelectionDropdown(
                label = "출생연도",
                selected = selectedYearOption.takeIf { it.isNotBlank() },
                options = yearOptions,
                onSelected = { option ->
                    selectedYearOption = option
                    val year = option.toIntOrNull()
                    if (year != null && birthDate != null) {
                        birthDate = runCatching { birthDate!!.withYear(year) }
                            .getOrElse { LocalDate.of(year, 2, 28) }
                    }
                }
            )
            if (selectedYearOption == "직접 입력") {
                FormField("출생연도 직접 입력", directYear) { directYear = it.filter(Char::isDigit).take(4) }
            }
            val selectedYear = selectedYearOption.toIntOrNull()
                ?: directYear.toIntOrNull()?.takeIf { selectedYearOption == "직접 입력" }
            OutlinedButton(
                onClick = { showBirthCalendar = true },
                enabled = selectedYear != null && selectedYear in 1900..today.year,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(birthDate?.let { "${it.monthValue}월 ${it.dayOfMonth}일" } ?: "월·일 선택")
            }
            val validBirthDate = birthDate?.takeIf { it.year == selectedYear && !it.isAfter(today) }
            val calculatedAge = validBirthDate?.let { Period.between(it, today).years }
            calculatedAge?.let { Text("만 ${it}세", style = MaterialTheme.typography.titleMedium) }
            SelectionDropdown(
                label = "성별",
                selected = gender.takeIf { it.isNotBlank() },
                options = listOf("여성", "남성", "선택 안 함"),
                onSelected = { gender = it }
            )
            FormField("신장(cm)", height) { height = it }
            FormField("체중(kg)", weight) { weight = it }
            FormField("보호자 연락처", caregiver) { caregiver = it }
            Text("긴급 상황에 연락할 수 있는 사람의 연락처를 입력해 주세요.", style = MaterialTheme.typography.bodySmall)
            Button({
                val dob = requireNotNull(validBirthDate)
                onSave(initial.copy(age = Period.between(dob, today).years, dateOfBirth = dob.toString(), gender = gender,
                    heightCm = height.toDoubleOrNull() ?: 0.0, weightKg = weight.toDoubleOrNull() ?: 0.0,
                    caregiverPhoneNumber = caregiver))
            }, enabled = validBirthDate != null && gender.isNotBlank() && caregiver.isNotBlank(), modifier = Modifier.fillMaxWidth()) { Text("다음") }
        }
    }

    if (showBirthCalendar) {
        val calendarYear = selectedYearOption.toIntOrNull()
            ?: directYear.toIntOrNull()?.takeIf { selectedYearOption == "직접 입력" }
        if (calendarYear != null) {
            val initialDate = birthDate?.takeIf { it.year == calendarYear }
                ?: LocalDate.of(calendarYear, 1, 1)
            val pickerState = rememberDatePickerState(
                initialSelectedDateMillis = initialDate.atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli(),
                yearRange = calendarYear..calendarYear
            )
            DatePickerDialog(
                onDismissRequest = { showBirthCalendar = false },
                confirmButton = {
                    TextButton(onClick = {
                        pickerState.selectedDateMillis?.let { millis ->
                            birthDate = LocalDate.ofEpochDay(millis / 86_400_000L)
                        }
                        showBirthCalendar = false
                    }) { Text("확인") }
                },
                dismissButton = { TextButton(onClick = { showBirthCalendar = false }) { Text("취소") } }
            ) {
                DatePicker(state = pickerState, showModeToggle = false)
            }
        }
    }
}

private data class MedicationDraft(
    val name: String = "", val strength: String = "", val strengthUnit: String = "mg",
    val dose: String = "1", val doseUnit: String = "정", val times: String = "2", val days: String = "30"
)

@Composable
fun MedicationSetupScreen(
    initial: List<MedicationInfo> = emptyList(),
    onBack: (() -> Unit)? = null,
    onSave: (List<MedicationInfo>, Int) -> Unit
) {
    var drafts by remember {
        mutableStateOf(if (initial.isEmpty()) listOf(MedicationDraft()) else initial.map {
            MedicationDraft(it.name, it.strengthValue.toString(), it.strengthUnit, it.dosageValue.toString(), it.dosageUnit, it.timesPerDay.toString(), it.totalDays.toString())
        })
    }
    var loadedDays by remember { mutableIntStateOf(initial.maxOfOrNull { it.totalDays }?.coerceIn(1, 90) ?: 30) }
    Scaffold(topBar = { TopAppBar(title = { Text("약 정보 등록") }, navigationIcon = {
        if (onBack != null) IconButton(onBack) { Icon(Icons.Rounded.ArrowBack, "뒤로") }
    }) }) { padding ->
        LazyColumn(Modifier.padding(padding).fillMaxSize(), contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item { Text("본 프로젝트의 기본 복용 횟수는 아침·저녁 하루 2회입니다.") }
            drafts.forEachIndexed { index, d ->
                item {
                    Card(shape = RoundedCornerShape(18.dp)) { Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("약 ${index + 1}", style = MaterialTheme.typography.titleMedium)
                        FormField("복용하는 약 이름", d.name) { drafts = drafts.update(index, d.copy(name = it)) }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Box(Modifier.weight(1f)) { FormField("1정 함량", d.strength) { drafts = drafts.update(index, d.copy(strength = it)) } }
                            Box(Modifier.weight(1f)) { FormField("함량 단위", d.strengthUnit) { drafts = drafts.update(index, d.copy(strengthUnit = it)) } }
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Box(Modifier.weight(1f)) { FormField("1회 복용량", d.dose) { drafts = drafts.update(index, d.copy(dose = it)) } }
                            Box(Modifier.weight(1f)) { FormField("복용 단위", d.doseUnit) { drafts = drafts.update(index, d.copy(doseUnit = it)) } }
                        }
                        FormField("하루 투약 횟수", d.times) { drafts = drafts.update(index, d.copy(times = it)) }
                        FormField("총 복용 일수", d.days) { drafts = drafts.update(index, d.copy(days = it)) }
                        if (drafts.size > 1) TextButton({ drafts = drafts.filterIndexed { i, _ -> i != index } }) { Text("이 약 삭제") }
                    } }
                }
            }
            item {
                SelectionDropdown(
                    label = "기기에 처음 투입하는 약 일수",
                    selected = loadedDays,
                    options = (1..90).toList(),
                    optionText = { "${it}일분" },
                    onSelected = { loadedDays = it }
                )
                Text(
                    "실제로 기기에 넣는 약 봉투 기준 일수입니다. 이 값으로 초기 잔량을 생성합니다.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            item { OutlinedButton({ drafts = drafts + MedicationDraft() }, modifier = Modifier.fillMaxWidth()) { Text("+ 약 종류 추가") } }
            item {
                Button({
                    onSave(
                        drafts.filter { it.name.isNotBlank() }.mapIndexed { i, d ->
                            MedicationInfo(
                                id = "med-${i + 1}", name = d.name,
                                strengthValue = d.strength.toDoubleOrNull() ?: 0.0, strengthUnit = d.strengthUnit,
                                doseAmount = "${d.dose}${d.doseUnit}", dosageValue = d.dose.toDoubleOrNull() ?: 1.0,
                                dosageUnit = d.doseUnit, timesPerDay = d.times.toIntOrNull() ?: 2,
                                totalDays = d.days.toIntOrNull() ?: 1, startDate = LocalDate.now().toString()
                            )
                        },
                        loadedDays
                    )
                }, enabled = drafts.any { it.name.isNotBlank() }, modifier = Modifier.fillMaxWidth()) { Text("다음") }
            }
        }
    }
}

@Composable
fun ScheduleSetupScreen(
    initial: MedicationSchedule = MedicationSchedule(),
    onBack: (() -> Unit)? = null,
    onSave: (MedicationSchedule) -> Unit
) {
    var intervalNumber by remember { mutableIntStateOf(initial.intervalHours.coerceIn(1, 24)) }
    val timeOptions = remember {
        (0 until 24).flatMap { hour -> listOf("%02d:00".format(hour), "%02d:30".format(hour)) }
    }
    var morning by remember { mutableStateOf(initial.morningTime.takeIf { it in timeOptions } ?: "08:00") }
    var evening by remember { mutableStateOf(initial.eveningTime.takeIf { it in timeOptions } ?: "20:00") }
    val actualGapMinutes = runCatching { ChronoUnit.MINUTES.between(LocalTime.parse(morning), LocalTime.parse(evening)) }.getOrDefault(-1L)
    val valid = actualGapMinutes >= intervalNumber * 60L

    Scaffold(topBar = { TopAppBar(title = { Text("복용 시간 설정") }, navigationIcon = {
        if (onBack != null) IconButton(onBack) { Icon(Icons.Rounded.ArrowBack, "뒤로") }
    }) }) { padding ->
        Column(Modifier.padding(padding).padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("약사 또는 약 봉투에 안내된 복용 간격과 복용 시간을 선택하세요.")
            SelectionDropdown(
                label = "최소 복용 간격",
                selected = intervalNumber,
                options = (1..24).toList(),
                optionText = { "${it}시간" },
                onSelected = { intervalNumber = it }
            )
            SelectionDropdown(
                label = "아침 복용 시간",
                selected = morning,
                options = timeOptions,
                onSelected = { morning = it }
            )
            val allowedEvening = timeOptions.filter { candidate ->
                runCatching { ChronoUnit.MINUTES.between(LocalTime.parse(morning), LocalTime.parse(candidate)) >= intervalNumber * 60L }.getOrDefault(false)
            }
            SelectionDropdown(
                label = "저녁 복용 시간",
                selected = evening.takeIf { it in allowedEvening },
                options = allowedEvening,
                onSelected = { evening = it }
            )
            if (!valid) {
                Text("저녁 시간은 아침 시간으로부터 최소 ${intervalNumber}시간 이후여야 합니다.", color = MaterialTheme.colorScheme.error)
            }
            Text(
                "AI가 복용 시간과 허용 간격을 분석해 다음 복용 시간을 자동으로 조정합니다.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Button(
                onClick = { onSave(MedicationSchedule(intervalNumber, morning, evening)) },
                enabled = valid,
                modifier = Modifier.fillMaxWidth()
            ) { Text("완료") }
        }
    }
}

private fun List<MedicationDraft>.update(index: Int, value: MedicationDraft) = toMutableList().also { it[index] = value }

@Composable
private fun FormField(label: String, value: String, onChange: (String) -> Unit) {
    OutlinedTextField(value, onChange, label = { Text(label) }, singleLine = true, modifier = Modifier.fillMaxWidth())
}
