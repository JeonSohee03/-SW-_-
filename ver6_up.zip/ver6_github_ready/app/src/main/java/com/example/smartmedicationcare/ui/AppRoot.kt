package com.example.smartmedicationcare.ui

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.smartmedicationcare.ui.screen.*
import com.example.smartmedicationcare.viewmodel.AppViewModel

private enum class AuthPage { LOGIN, SIGNUP }
private enum class OnboardingStep { WIFI, PROFILE, MEDICATION, SCHEDULE, DONE }

@Composable
fun AppRoot(vm: AppViewModel) {
    val state by vm.uiState.collectAsStateWithLifecycle()
    val message by vm.operationMessage.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("heybom_consent", 0) }
    var consented by remember { mutableStateOf(prefs.getBoolean("completed", false)) }
    var authPage by remember { mutableStateOf(AuthPage.LOGIN) }
    var onboardingStepName by rememberSaveable { mutableStateOf<String?>(null) }
    val notificationPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }

    LaunchedEffect(state.loggedIn) {
        if (!state.loggedIn) onboardingStepName = null
    }

    LaunchedEffect(
        state.loggedIn,
        state.profile.deviceId,
        state.profileComplete,
        state.medicationComplete,
        state.scheduleComplete
    ) {
        if (state.loggedIn && onboardingStepName == null) {
            onboardingStepName = when {
                state.profile.deviceId.isBlank() -> OnboardingStep.WIFI
                !state.profileComplete -> OnboardingStep.PROFILE
                !state.medicationComplete -> OnboardingStep.MEDICATION
                !state.scheduleComplete -> OnboardingStep.SCHEDULE
                else -> OnboardingStep.DONE
            }.name
        }
    }

    val onboardingStep = onboardingStepName?.let { name -> runCatching { OnboardingStep.valueOf(name) }.getOrNull() }

    LaunchedEffect(onboardingStepName) {
        if (onboardingStepName != null && onboardingStep == null) onboardingStepName = null
    }

    when {
        !consented -> ConsentScreen {
            prefs.edit().putBoolean("completed", true).apply()
            consented = true
            if (Build.VERSION.SDK_INT >= 33 &&
                ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
            ) notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        !state.loggedIn && authPage == AuthPage.SIGNUP -> SignupScreen(
            message = message,
            onBack = { authPage = AuthPage.LOGIN },
            onSignup = { email, password -> vm.signup(email, password) { authPage = AuthPage.LOGIN } }
        )
        !state.loggedIn -> LoginScreen(
            message = message,
            onLogin = vm::login,
            onSignup = { authPage = AuthPage.SIGNUP },
            onBack = { consented = false }
        )
        onboardingStep == null -> Unit
        onboardingStep == OnboardingStep.WIFI -> WifiSetupScreen(
            state = state,
            onBack = { vm.logout() },
            onRegister = vm::registerDevice,
            onComplete = { onboardingStepName = OnboardingStep.PROFILE.name }
        )
        onboardingStep == OnboardingStep.PROFILE -> PatientInfoScreen(
            initial = state.profile,
            onBack = { onboardingStepName = OnboardingStep.WIFI.name },
            onSave = {
                vm.savePatientProfile(it)
                onboardingStepName = OnboardingStep.MEDICATION.name
            }
        )
        onboardingStep == OnboardingStep.MEDICATION -> MedicationSetupScreen(
            initial = state.medications,
            onBack = { onboardingStepName = OnboardingStep.PROFILE.name },
            onSave = { items, loadedDays ->
                vm.saveMedicationSetup(items, loadedDays)
                onboardingStepName = OnboardingStep.SCHEDULE.name
            }
        )
        onboardingStep == OnboardingStep.SCHEDULE -> ScheduleSetupScreen(
            initial = state.schedule,
            onBack = { onboardingStepName = OnboardingStep.MEDICATION.name },
            onSave = {
                vm.saveSchedule(it)
                onboardingStepName = OnboardingStep.DONE.name
            }
        )
        else -> MainNavigation(state, vm)
    }
}
