@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
package com.example.smartmedicationcare.ui.screen

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.example.smartmedicationcare.model.AppUiState
import com.example.smartmedicationcare.ui.components.AppCard
import com.example.smartmedicationcare.ui.components.LabelValue
import com.example.smartmedicationcare.ui.components.SelectionDropdown

@Composable
fun InventoryDetailScreen(
    state: AppUiState,
    onBack: () -> Unit,
    onAddStock: (Int) -> Unit,
    onEditMedication: () -> Unit
) {
    var showSameMedicineQuestion by remember { mutableStateOf(false) }
    var showAddDays by remember { mutableStateOf(false) }
    var showDifferentMedicineNotice by remember { mutableStateOf(false) }
    var days by remember { mutableIntStateOf(7) }

    val inventory = state.inventory
    val lowestPeriodStock = minOf(inventory.morningRemainingCount, inventory.eveningRemainingCount)
    val level = when {
        lowestPeriodStock <= 3 -> "주의"
        lowestPeriodStock <= 7 -> "권장"
        else -> "안정"
    }
    val statusColor = when (level) {
        "주의" -> MaterialTheme.colorScheme.error
        "권장" -> Color(0xFFF59E0B)
        else -> Color(0xFF2EAF62)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("현재 약 보관 현황") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Rounded.ArrowBack, "뒤로") } }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier.padding(padding).padding(18.dp).fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            AppCard("현재 잔량") {
                Text("$level 단계", style = MaterialTheme.typography.headlineMedium, color = statusColor)
                LabelValue("전체 남은 잔량", "${inventory.remainingCount}회분")
                LabelValue("아침", "${inventory.morningRemainingCount}일분")
                LabelValue("저녁", "${inventory.eveningRemainingCount}일분")
                Text(
                    "ESP32가 Firebase에 갱신한 현재 잔량을 실시간으로 표시합니다.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            AppCard("약 추가") {
                Text("추가한 약 일수를 기기에 전달하며, 실제 잔량 계산과 갱신은 ESP32에서 처리합니다.")
                Button(
                    onClick = { showSameMedicineQuestion = true },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("추가하기") }
            }
        }
    }

    if (showSameMedicineQuestion) {
        AlertDialog(
            onDismissRequest = { showSameMedicineQuestion = false },
            title = { Text("약 정보 확인") },
            text = { Text("추가하려는 약이 현재 등록된 약 정보와 동일한 약인가요?") },
            dismissButton = {
                TextButton(onClick = {
                    showSameMedicineQuestion = false
                    showDifferentMedicineNotice = true
                }) { Text("아니오") }
            },
            confirmButton = {
                Button(onClick = {
                    showSameMedicineQuestion = false
                    showAddDays = true
                }) { Text("예") }
            }
        )
    }

    if (showAddDays) {
        AlertDialog(
            onDismissRequest = { showAddDays = false },
            title = { Text("추가할 약 일수") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("실제로 기기에 추가한 약이 몇 일분인지 선택해 주세요.")
                    SelectionDropdown(
                        label = "추가한 약",
                        selected = days,
                        options = (1..90).toList(),
                        optionText = { "${it}일분" },
                        onSelected = { days = it }
                    )
                }
            },
            dismissButton = { TextButton(onClick = { showAddDays = false }) { Text("취소") } },
            confirmButton = {
                Button(onClick = {
                    onAddStock(days)
                    showAddDays = false
                }) { Text("추가") }
            }
        )
    }

    if (showDifferentMedicineNotice) {
        AlertDialog(
            onDismissRequest = { showDifferentMedicineNotice = false },
            title = { Text("약 정보 변경 필요") },
            text = { Text("약 정보에서 새로 투입할 약 정보를 먼저 작성해주시고 다시 돌아와 주세요.") },
            dismissButton = { TextButton(onClick = { showDifferentMedicineNotice = false }) { Text("닫기") } },
            confirmButton = {
                Button(onClick = {
                    showDifferentMedicineNotice = false
                    onEditMedication()
                }) { Text("약 정보로 이동") }
            }
        )
    }
}
