@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
package com.example.smartmedicationcare.ui.screen

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.smartmedicationcare.model.*
import com.example.smartmedicationcare.ui.components.*
import com.example.smartmedicationcare.util.formatTime

@Composable
private fun BackScaffold(
    title: String,
    onBack: () -> Unit,
    content: @Composable (PaddingValues) -> Unit
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(title) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Rounded.ArrowBack, contentDescription = "뒤로")
                    }
                }
            )
        }
    ) { padding ->
        content(padding)
    }
}

@Composable
fun NextAlarmScreen(state:AppUiState,onBack:()->Unit){
    BackScaffold("다음 알림",onBack){padding->
        LazyColumn(Modifier.padding(padding).fillMaxSize(),contentPadding=PaddingValues(18.dp),verticalArrangement=Arrangement.spacedBy(16.dp)){
            item { AppCard("다음 복용 알림") { Text(formatTime(state.nextAlarmMillis), style=MaterialTheme.typography.displayMedium); LabelValue("아침 기준 시간",state.schedule.morningTime); LabelValue("AI 조정 저녁 시간",state.schedule.eveningTime); LabelValue("최소 복용 간격","${state.schedule.intervalHours}시간"); Text("다음 복용 시간은 ESP32/AI가 실제 복용 시각과 최소 허용 간격을 계산한 서버 데이터를 기준으로 표시됩니다.",style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant) } }
        }
    }
}

@Composable
fun WarningScreen(state: AppUiState, onBack: () -> Unit) {
    val warnings = buildWarningItems(state)
    BackScaffold("주의 알림", onBack) { p ->
        LazyColumn(
            Modifier.padding(p).fillMaxSize(),
            contentPadding = PaddingValues(18.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (warnings.isEmpty()) {
                item { AppCard("알림 없음") { Text("현재 확인이 필요한 주의 알림이 없습니다.") } }
            } else {
                items(warnings) { warning ->
                    val color = when (warning.level) {
                        WarningLevel.INFO -> androidx.compose.ui.graphics.Color(0xFF2EAF62)
                        WarningLevel.WARNING -> androidx.compose.ui.graphics.Color(0xFFF59E0B)
                        WarningLevel.CRITICAL -> MaterialTheme.colorScheme.error
                    }
                    AppCard(warning.title) {
                        Text(warning.message)
                        Text(
                            when (warning.level) {
                                WarningLevel.INFO -> "안정"
                                WarningLevel.WARNING -> "확인 필요"
                                WarningLevel.CRITICAL -> "주의"
                            },
                            color = color,
                            style = MaterialTheme.typography.labelLarge
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun DoseDetailScreen(state:AppUiState,period:DosePeriod,onBack:()->Unit){
    val record=state.todayRecords.firstOrNull{it.period==period}?:state.recentRecords.lastOrNull{it.period==period}
    val inventory = state.inventory
    val remaining=if(period==DosePeriod.MORNING) inventory.morningRemainingCount else inventory.eveningRemainingCount
    BackScaffold("복약 기록 상세",onBack){p->LazyColumn(Modifier.padding(p).fillMaxSize(),contentPadding=PaddingValues(18.dp)){item{AppCard("${period.label} 복약 상세"){
        if(period==DosePeriod.MORNING) LabelValue("프로그램 점수",record?.programScore?.let{"${it}점"}?:"-")
        LabelValue("약 배출 시간",formatTime(record?.dispensedAtMillis)); LabelValue("복용 시간",formatTime(record?.takenAtMillis)); LabelValue("남은 잔량","${remaining}일분")
        Text("남은 잔량은 ESP32가 Firebase에 갱신한 아침·저녁 잔량 값을 그대로 표시합니다.",style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)
    }}}}
}
