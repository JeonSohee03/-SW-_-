package com.example.smartmedicationcare.util

import com.example.smartmedicationcare.model.*
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.ZoneId

// 다음 복용 시간 계산
fun resolvedNextDoseMillis(state: AppUiState, nowMillis: Long = System.currentTimeMillis()): Long? {
    state.nextAlarmMillis?.takeIf { it > nowMillis }?.let { return it }
    state.schedule.nextDoseAt?.takeIf { it > nowMillis }?.let { return it }
    return runCatching {
        val now = LocalDateTime.ofInstant(java.time.Instant.ofEpochMilli(nowMillis), ZoneId.systemDefault())
        val morning = LocalTime.parse(state.schedule.morningTime)
        val evening = LocalTime.parse(state.schedule.eveningTime)
        val candidates = listOf(morning, evening).map { LocalDateTime.of(now.toLocalDate(), it) }
        val next = candidates.firstOrNull { it.isAfter(now) }
            ?: LocalDateTime.of(now.toLocalDate().plusDays(1), morning)
        next.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
    }.getOrNull()
}

// 기록이 없으면 설정된 복용 시간을 예정 시간으로 사용
fun scheduledDoseMillis(state: AppUiState, period: DosePeriod, date: LocalDate = LocalDate.now()): Long? {
    val record = state.recentRecords.firstOrNull { it.date == date.toString() && it.period == period }
        ?: state.todayRecords.firstOrNull { it.date == date.toString() && it.period == period }
    if (record != null && record.scheduledAtMillis > 0L) return record.scheduledAtMillis
    val timeText = when (period) {
        DosePeriod.MORNING -> state.schedule.morningTime
        DosePeriod.EVENING -> state.schedule.eveningTime
        DosePeriod.LUNCH -> return null
    }
    return runCatching {
        LocalDateTime.of(date, LocalTime.parse(timeText))
            .atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
    }.getOrNull()
}
