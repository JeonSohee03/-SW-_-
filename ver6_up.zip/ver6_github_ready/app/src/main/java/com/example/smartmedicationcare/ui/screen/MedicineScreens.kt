@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
package com.example.smartmedicationcare.ui.screen

import android.net.Uri
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.CalendarMonth
import androidx.compose.material.icons.rounded.ChevronRight
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.unit.dp
import com.example.smartmedicationcare.model.*
import com.example.smartmedicationcare.ui.components.*
import java.time.LocalDate
import java.time.temporal.ChronoUnit

@Composable
fun MedicationHubScreen(
    state: AppUiState,
    padding: PaddingValues,
    onMedicationDetail: () -> Unit,
    onSideEffect: () -> Unit,
    onAiComment: () -> Unit,
    onInventoryDetail: () -> Unit,
    onWithdraw: (Int, Int) -> Unit
) {
    val inventory = state.inventory
    var showWithdraw by remember { mutableStateOf(false) }
    var showWithdrawConfirm by remember { mutableStateOf(false) }
    var morning by remember { mutableIntStateOf(0) }
    var evening by remember { mutableIntStateOf(0) }

    val start = state.medications.mapNotNull { runCatching { LocalDate.parse(it.startDate) }.getOrNull() }.minOrNull()
    val dayCount = start?.let { ChronoUnit.DAYS.between(it, LocalDate.now()).toInt() + 1 } ?: 1
    val introText = "복용을 시작한 지 ${dayCount.coerceAtLeast(1)}일째예요. 오늘 몸 상태나 신체 변화도 함께 살펴보세요."
    val lowestPeriodStock = minOf(inventory.morningRemainingCount, inventory.eveningRemainingCount)
    val level = when {
        lowestPeriodStock <= 3 -> "주의"
        lowestPeriodStock <= 7 -> "권장"
        else -> "안정"
    }

    LazyColumn(
        modifier = Modifier.padding(padding).fillMaxSize(),
        contentPadding = PaddingValues(18.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item { Text("약", style = MaterialTheme.typography.headlineLarge) }
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        brush = androidx.compose.ui.graphics.Brush.linearGradient(
                            listOf(Color(0xFF4F8CFF), Color(0xFF7DB7FF))
                        ),
                        shape = RoundedCornerShape(24.dp)
                    )
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text("복약 케어", color = Color.White.copy(alpha = 0.82f), style = MaterialTheme.typography.labelLarge)
                Text(introText, color = Color.White, style = MaterialTheme.typography.headlineSmall)
            }
        }

        item {
            AppCard("현재 약 보관 현황", onClick = onInventoryDetail) {
                val statusColor = when (level) {
                    "주의" -> MaterialTheme.colorScheme.error
                    "권장" -> Color(0xFFF59E0B)
                    else -> Color(0xFF2EAF62)
                }
                Text("$level 단계", style = MaterialTheme.typography.headlineMedium, color = statusColor)
                LabelValue("전체 남은 잔량", "${inventory.remainingCount}회분")
                LabelValue("아침", "${inventory.morningRemainingCount}일분")
                LabelValue("저녁", "${inventory.eveningRemainingCount}일분")
                Text(
                    "잔량은 ESP32가 계산해 Firebase에 갱신한 아침·저녁·전체 수량을 그대로 표시합니다.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        item {
            AppCard("외출용 약 꺼내기") {
                Text(
                    "필요한 아침·저녁 약 일수를 선택해 기기로 배출 요청을 보냅니다.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Button(
                    onClick = {
                        morning = 0
                        evening = 0
                        showWithdraw = true
                    },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("약 꺼내기") }
            }
        }

        item {
            AppCard("복용 중인 약 정보", onClick = onMedicationDetail) {
                state.medications.ifEmpty { listOf(state.medication) }
                    .filter { it.name.isNotBlank() }
                    .forEach { med ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(med.name, style = MaterialTheme.typography.titleMedium)
                            StatusBadge("복용 중")
                        }
                    }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    Icon(Icons.Rounded.ChevronRight, null)
                }
            }
        }

        item {
            AppCard("부작용 메모", onClick = onSideEffect) {
                Text(
                    state.sideEffectHistory.lastOrNull()?.memo?.ifBlank { "작성된 메모가 없습니다." }
                        ?: "작성된 메모가 없습니다."
                )
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    Icon(Icons.Rounded.ChevronRight, null)
                }
            }
        }

        item {
            AppCard("복약 정보 & AI 상담", onClick = onAiComment) {
                Text(state.aiComment.ifBlank { "공식 약 정보와 사용자 맞춤 AI 코멘트를 확인해 보세요." })
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    Icon(Icons.Rounded.ChevronRight, null)
                }
            }
        }
    }

    if (showWithdraw) {
        AlertDialog(
            onDismissRequest = { showWithdraw = false },
            title = { Text("외출용 약 꺼내기") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    SelectionDropdown(
                        label = "아침 약",
                        selected = morning,
                        options = (0..inventory.morningRemainingCount).toList(),
                        optionText = { "${it}일분" },
                        onSelected = { morning = it }
                    )
                    SelectionDropdown(
                        label = "저녁 약",
                        selected = evening,
                        options = (0..inventory.eveningRemainingCount).toList(),
                        optionText = { "${it}일분" },
                        onSelected = { evening = it }
                    )
                }
            },
            dismissButton = { TextButton({ showWithdraw = false }) { Text("취소") } },
            confirmButton = {
                Button(
                    onClick = {
                        showWithdraw = false
                        showWithdrawConfirm = true
                    },
                    enabled = morning + evening > 0
                ) { Text("배출 요청") }
            }
        )
    }

    if (showWithdrawConfirm) {
        AlertDialog(
            onDismissRequest = { showWithdrawConfirm = false },
            title = { Text("약 배출 확인") },
            text = {
                Text("아침 ${morning}일분, 저녁 ${evening}일분을 기기에서 꺼낼까요? 배출을 시작하면 취소하기 어려울 수 있습니다.")
            },
            dismissButton = { TextButton(onClick = { showWithdrawConfirm = false }) { Text("아니오") } },
            confirmButton = {
                Button(onClick = {
                    onWithdraw(morning, evening)
                    showWithdrawConfirm = false
                }) { Text("예, 배출할게요") }
            }
        )
    }
}

@Composable
private fun StatusBadge(text: String) {
    Surface(
        color = MaterialTheme.colorScheme.primaryContainer,
        shape = RoundedCornerShape(999.dp)
    ) {
        Text(
            text = text,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.primary
        )
    }
}

@Composable
fun MedicationDetailScreen(state: AppUiState, onBack: () -> Unit, onEdit: () -> Unit) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("복용 중인 약 정보") },
                navigationIcon = { IconButton(onBack) { Icon(Icons.Rounded.ArrowBack, null) } }
            )
        }
    ) { p ->
        LazyColumn(
            modifier = Modifier.padding(p).fillMaxSize(),
            contentPadding = PaddingValues(18.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            state.medications.ifEmpty { listOf(state.medication) }.forEachIndexed { i, m ->
                item {
                    AppCard("약 ${i + 1}") {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(m.name, style = MaterialTheme.typography.titleLarge)
                            StatusBadge("복용 중")
                        }
                        LabelValue("1회 투약량", m.doseAmount)
                        LabelValue("하루 복용", "${m.timesPerDay}회")
                        LabelValue("복용 간격", "${m.intervalHours}시간")
                        LabelValue("총 복용 일수", "${m.totalDays}일")
                        if (m.startDate.isNotBlank()) LabelValue("복용 시작일", m.startDate)
                    }
                }
            }
            item {
                OutlinedButton(onEdit, Modifier.fillMaxWidth()) { Text("약 정보 변경") }
            }
        }
    }
}

@Composable
fun AiCommentScreen(state: AppUiState, onBack: () -> Unit, onRefresh: (String) -> Unit) {
    val meds = state.medications.ifEmpty { listOf(state.medication) }.filter { it.name.isNotBlank() }
    var selected by rememberSaveable { mutableStateOf(meds.firstOrNull()?.id.orEmpty()) }
    val selectedMedication = meds.firstOrNull { it.id == selected } ?: meds.firstOrNull()
    val uriHandler = LocalUriHandler.current
    val context = LocalContext.current
    val profile = state.profile

    val portalUrl = selectedMedication?.let { med ->
        if (med.itemSeq.isNotBlank()) {
            "https://nedrug.mfds.go.kr/pbp/CCBBB01/getItemDetail?itemSeq=${Uri.encode(med.itemSeq)}"
        } else {
            "https://nedrug.mfds.go.kr/searchDrug?itemName=${Uri.encode(med.name)}"
        }
    }

    val geminiPrompt = selectedMedication?.let { med ->
        buildString {
            appendLine("다음 사용자 정보와 복용 약 정보를 바탕으로 복약 시 주의할 점, 생활 속 예방법, 확인하면 좋은 이상 증상을 이해하기 쉽게 설명해줘.")
            appendLine("의학적 진단을 단정하지 말고, 필요한 경우 의료진 상담이 필요한 상황도 구분해서 알려줘.")
            appendLine()
            appendLine("[사용자 정보]")
            appendLine("나이: ${profile.age}세")
            appendLine("키: ${profile.heightCm}cm")
            appendLine("체중: ${profile.weightKg}kg")
            appendLine()
            appendLine("[복용 약]")
            appendLine("약품명: ${med.name}")
            appendLine("1회 복용량: ${med.doseAmount}")
            appendLine("하루 복용 횟수: ${med.timesPerDay}회")
            appendLine("복용 간격: ${med.intervalHours}시간")
            if (med.cautionText.isNotBlank()) appendLine("기존 주의 정보: ${med.cautionText}")
            appendLine()
            append("이 내용을 바탕으로 나와 계속 대화하면서 궁금한 점에 답해줘.")
        }
    }.orEmpty()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("복약 정보 & AI 상담") },
                navigationIcon = { IconButton(onBack) { Icon(Icons.Rounded.ArrowBack, null) } }
            )
        }
    ) { p ->
        LazyColumn(
            modifier = Modifier.padding(p).fillMaxSize(),
            contentPadding = PaddingValues(18.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                SelectionDropdown(
                    label = "약 선택",
                    selected = meds.firstOrNull { it.id == selected },
                    options = meds,
                    optionText = { it.name },
                    onSelected = { selected = it.id }
                )
            }
            item {
                AppCard("API · 의약품관리종합정보포털") {
                    Text("선택한 약의 공식 허가·제품 정보를 의약품관리종합정보포털에서 확인할 수 있습니다.")
                    Button(
                        onClick = { portalUrl?.let(uriHandler::openUri) },
                        enabled = portalUrl != null,
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("선택한 약 공식 정보 보기") }
                    Text(
                        if (selectedMedication?.itemSeq?.isNotBlank() == true)
                            "저장된 품목기준코드(itemSeq)를 이용해 해당 약의 공식 상세 페이지를 엽니다."
                        else
                            "품목기준코드가 없으면 선택한 약 이름으로 포털 검색 결과를 엽니다.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            item {
                AppCard("AI 상담") {
                    Text(
                        "${profile.age}세 · ${profile.heightCm}cm · ${profile.weightKg}kg 사용자 정보와 선택한 약 정보를 기반으로 제공합니다.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    OutlinedButton(
                        onClick = {
                            if (geminiPrompt.isNotBlank()) {
                                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                clipboard.setPrimaryClip(ClipData.newPlainText("B-OMM AI 상담 프롬프트", geminiPrompt))
                                Toast.makeText(context, "맞춤 상담 프롬프트를 복사했습니다. Gemini에서 붙여넣어 대화를 시작하세요.", Toast.LENGTH_LONG).show()
                                uriHandler.openUri("https://gemini.google.com/app")
                            }
                        },
                        enabled = selectedMedication != null,
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("AI 상담하러 가기") }
                    Text(
                        "AI 상담은 복약을 돕는 참고 정보이며 의료진의 진단이나 처방을 대신하지 않습니다.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

@Composable
fun MedicationEditScreen(initial: List<MedicationInfo>, onBack: () -> Unit, onSave: (List<MedicationInfo>) -> Unit) {
    var items by remember { mutableStateOf(initial) }
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("약 정보 변경") },
                navigationIcon = { IconButton(onBack) { Icon(Icons.Rounded.ArrowBack, null) } }
            )
        }
    ) { p ->
        LazyColumn(
            modifier = Modifier.padding(p).fillMaxSize(),
            contentPadding = PaddingValues(18.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items.forEachIndexed { i, m ->
                item {
                    AppCard("약 ${i + 1}") {
                        OutlinedTextField(
                            value = m.name,
                            onValueChange = { v -> items = items.toMutableList().also { it[i] = m.copy(name = v) } },
                            label = { Text("약품명") },
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = m.doseAmount,
                            onValueChange = { v -> items = items.toMutableList().also { it[i] = m.copy(doseAmount = v) } },
                            label = { Text("1회 투약량") },
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = m.totalDays.toString(),
                            onValueChange = { v -> items = items.toMutableList().also { it[i] = m.copy(totalDays = v.toIntOrNull() ?: 0) } },
                            label = { Text("복용 일수") },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }
            item {
                Button(onClick = { onSave(items); onBack() }, modifier = Modifier.fillMaxWidth()) { Text("저장") }
            }
        }
    }
}

@Composable
fun SideEffectMemoScreen(state: AppUiState, onBack: () -> Unit, onSave: (SideEffectEntry) -> Unit) {
    var date by remember { mutableStateOf(LocalDate.now()) }
    var calendar by remember { mutableStateOf(false) }
    val today = LocalDate.now()
    val entry = state.sideEffectHistory.firstOrNull { it.date == date.toString() }
    var memo by remember(date, entry) { mutableStateOf(entry?.memo.orEmpty()) }
    var editing by remember(date, entry) { mutableStateOf(entry == null) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("부작용 메모") },
                navigationIcon = { IconButton(onBack) { Icon(Icons.Rounded.ArrowBack, null) } }
            )
        }
    ) { p ->
        LazyColumn(
            modifier = Modifier.padding(p).fillMaxSize(),
            contentPadding = PaddingValues(18.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
                ) {
                    OutlinedButton(
                        onClick = { date = date.minusDays(1) },
                        modifier = Modifier.height(52.dp)
                    ) { Text("< 이전") }
                    Text("${date.monthValue}월 ${date.dayOfMonth}일", style = MaterialTheme.typography.headlineSmall)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        IconButton(onClick = { calendar = !calendar }) {
                            Icon(Icons.Rounded.CalendarMonth, contentDescription = "전체")
                        }
                        OutlinedButton(
                            onClick = { if (date.isBefore(today)) date = date.plusDays(1) },
                            enabled = date.isBefore(today),
                            modifier = Modifier.height(52.dp)
                        ) { Text("다음 >") }
                    }
                }
            }
            if (calendar) {
                item {
                    AppCard("전체 기록") {
                        MonthCalendar(
                            selectedDate = date,
                            onDateSelected = {
                                date = it
                                calendar = false
                            },
                            dayMarker = { d ->
                                if (state.sideEffectHistory.any { it.date == d.toString() && it.memo.isNotBlank() }) {
                                    Text("•", color = Color(0xFFFF9500))
                                }
                            }
                        )
                    }
                }
            }
            item {
                if (editing) {
                    OutlinedTextField(
                        value = memo,
                        onValueChange = { memo = it },
                        label = { Text("신체 변화·부작용 메모") },
                        modifier = Modifier.fillMaxWidth().height(260.dp)
                    )
                } else {
                    AppCard("기록") {
                        Text(memo.ifBlank { "작성된 메모가 없습니다." })
                    }
                }
            }
            item {
                if (editing) {
                    Button(
                        onClick = {
                            onSave(SideEffectEntry(date.toString(), memo, System.currentTimeMillis()))
                            editing = false
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("메모 저장") }
                } else {
                    OutlinedButton(onClick = { editing = true }, modifier = Modifier.fillMaxWidth()) { Text("수정") }
                }
            }
        }
    }
}
