package com.example.smartmedicationcare.data

import com.example.smartmedicationcare.model.*
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.ZoneId
import java.time.temporal.ChronoUnit

class FirebaseMedicationRepository(
    private val auth: FirebaseAuth = FirebaseAuth.getInstance(),
    private val db: FirebaseDatabase = FirebaseDatabase.getInstance()
) : MedicationRepository {
    private fun uid() = auth.currentUser?.uid ?: error("로그인이 필요합니다.")
    private fun userRoot() = db.reference.child("users").child(uid())

    private fun DataSnapshot.safeString(default: String = ""): String = when (val v = value) {
        is String -> v
        is Number, is Boolean -> v.toString()
        else -> default
    }

    private fun DataSnapshot.safeLong(): Long? = when (val v = value) {
        is Number -> v.toLong()
        is String -> v.toLongOrNull()
        else -> null
    }

    private fun DataSnapshot.safeInt(): Int? = when (val v = value) {
        is Number -> v.toInt()
        is String -> v.toIntOrNull()
        else -> null
    }

    private fun DataSnapshot.safeDouble(): Double? = when (val v = value) {
        is Number -> v.toDouble()
        is String -> v.toDoubleOrNull()
        else -> null
    }

    private fun DataSnapshot.safeBoolean(): Boolean? = when (val v = value) {
        is Boolean -> v
        is String -> v.toBooleanStrictOrNull()
        is Number -> v.toInt() != 0
        else -> null
    }

    private fun parseAlert(snapshot: DataSnapshot): AlertItem? = runCatching {
        val title = snapshot.child("title").safeString()
        val message = snapshot.child("message").safeString()
        if (title.isBlank() && message.isBlank()) return@runCatching null
        val createdRaw = snapshot.child("createdAt")
        AlertItem(
            type = snapshot.child("type").safeString(),
            title = title,
            message = message,
            createdAt = createdRaw.safeString().ifBlank { createdRaw.safeLong()?.toString().orEmpty() },
            critical = snapshot.child("critical").safeBoolean()
                ?: snapshot.child("type").safeString().contains("ERROR", ignoreCase = true),
            read = snapshot.child("read").safeBoolean() ?: false,
            resolved = snapshot.child("resolved").safeBoolean() ?: false,
            active = snapshot.child("active").safeBoolean() ?: true
        )
    }.getOrNull()

    override fun observeState(): Flow<AppUiState> = callbackFlow {
        var userRef: DatabaseReference? = null
        var userListener: ValueEventListener? = null
        var deviceRef: DatabaseReference? = null
        var deviceListener: ValueEventListener? = null
        var state = AppUiState()
        var userAlerts: List<AlertItem> = emptyList()
        var deviceAlerts: List<AlertItem> = emptyList()

        fun detachDevice() {
            deviceRef?.let { ref -> deviceListener?.let(ref::removeEventListener) }
            deviceRef = null; deviceListener = null
        }

        fun parseDeviceSchedule(snapshot: DataSnapshot): MedicationSchedule? {
            val ms = snapshot.child("medicationSchedule")
            if (!ms.exists()) return null
            val morning = ms.child("morningTime").safeString()
            val dinner = ms.child("dinnerTime").safeString()
            val interval = ms.child("intervalHours").safeInt() ?: state.schedule.intervalHours
            val next = ms.child("nextDoseAt").safeLong()
            return state.schedule.copy(
                intervalHours = interval,
                morningTime = morning.ifBlank { state.schedule.morningTime },
                eveningTime = dinner.ifBlank { state.schedule.eveningTime },
                dinnerTime = dinner.ifBlank { state.schedule.dinnerTime },
                nextDoseAt = next,
                updatedAt = ms.child("updatedAt").safeLong() ?: 0L
            )
        }

        fun attachDevice(deviceId: String) {
            detachDevice()
            if (deviceId.isBlank()) { trySend(state); return }
            val ref = db.reference.child("devices").child(deviceId)
            val listener = object : ValueEventListener {
                override fun onDataChange(s: DataSnapshot) {
                    val inv = s.child("inventory")
                    // 잔량은 Firebase inventory 값을 기준으로 사용
                    val total = inv.child("remainingDoseCount").safeInt() ?: 0
                    val morning = inv.child("remainingDoseCountByPeriod/morning").safeInt() ?: 0
                    val evening = inv.child("remainingDoseCountByPeriod/evening").safeInt() ?: 0
                    val last = s.child("commands").children.mapNotNull { c ->
                        runCatching { c.getValue(WithdrawalCommand::class.java) }.getOrNull()?.copy(id = c.key.orEmpty())
                    }.filter { it.type == "WITHDRAW_MEDICATION" }
                        .maxByOrNull { it.requestedAt }
                    val espSchedule = parseDeviceSchedule(s)
                    deviceAlerts = s.child("alerts").children.mapNotNull(::parseAlert)
                    // 다음 복용 시각은 서버의 nextDoseAt 사용
                    val nextAlarm = espSchedule?.nextDoseAt
                    state = state.copy(
                        inventory = InventoryState(
                            remainingCount = total,
                            morningRemainingCount = morning,
                            eveningRemainingCount = evening,
                            updatedAt = inv.child("updatedAt").safeLong() ?: 0L
                        ),
                        lastWithdrawal = last,
                        deviceNetworkStatus = s.child("network/status").safeString("UNKNOWN"),
                        deviceStatus = s.child("deviceStatus/status").safeString().ifBlank {
                            s.child("deviceStatus").safeString().ifBlank { s.child("status").safeString("데이터 없음") }
                        },
                        schedule = espSchedule ?: state.schedule,
                        nextAlarmMillis = nextAlarm,
                        alerts = (userAlerts + deviceAlerts).distinctBy { listOf(it.type, it.title, it.message, it.createdAt) }
                    )
                    trySend(state)
                }
                override fun onCancelled(error: DatabaseError) { close(error.toException()) }
            }
            deviceRef = ref; deviceListener = listener; ref.addValueEventListener(listener)
        }

        val authListener = FirebaseAuth.AuthStateListener { firebaseAuth ->
            userRef?.let { ref -> userListener?.let(ref::removeEventListener) }
            detachDevice()
            val user = firebaseAuth.currentUser
            if (user == null) { state = AppUiState(); trySend(state); return@AuthStateListener }
            val ref = db.reference.child("users").child(user.uid)
            val listener = object : ValueEventListener {
                override fun onDataChange(s: DataSnapshot) {
                    val profile = runCatching { s.child("profile").getValue(UserProfile::class.java) }.getOrNull()
                        ?: UserProfile(email = user.email.orEmpty())
                    val meds = s.child("medications").children.mapNotNull { m ->
                        runCatching { m.getValue(MedicationInfo::class.java) }.getOrNull()?.copy(id = m.key.orEmpty())
                    }
                    val aiComment = s.child("medicineInsights/latest/comment").safeString()
                    val records = s.child("doseRecords").children.flatMap { date ->
                        date.children.mapNotNull record@{ p ->
                            val period = runCatching { DosePeriod.valueOf(p.key.orEmpty().uppercase()) }.getOrNull()
                                ?: return@record null
                            val status = runCatching {
                                DoseStatus.valueOf(p.child("status").safeString().uppercase())
                            }.getOrDefault(DoseStatus.SCHEDULED)
                            DoseRecord(
                                id = "${date.key}-${p.key}", date = date.key.orEmpty(), period = period,
                                scheduledAtMillis = p.child("scheduledAt").safeLong() ?: 0L,
                                programScore = p.child("programScore").safeInt(),
                                dispensedAtMillis = p.child("dispensedAt").safeLong(),
                                takenAtMillis = p.child("estimatedTakenAt").safeLong()
                                    ?: p.child("pouchPickedUpAt").safeLong(),
                                status = status,
                                hasAnomaly = !(p.child("dispenseDetected").safeBoolean() ?: true),
                                anomalyMessage = p.child("anomalyMessage").safeString()
                            )
                        }
                    }
                    val savedSchedule = runCatching { s.child("schedule").getValue(MedicationSchedule::class.java) }.getOrNull() ?: MedicationSchedule()
                    userAlerts = s.child("alerts").children.mapNotNull(::parseAlert)
                    state = state.copy(
                        loggedIn = true,
                        setupComplete = s.child("setupComplete").safeBoolean() ?: false,
                        profileComplete = s.child("onboarding/profileComplete").safeBoolean() ?: (profile.age > 0),
                        medicationComplete = s.child("onboarding/medicationComplete").safeBoolean() ?: meds.isNotEmpty(),
                        scheduleComplete = s.child("onboarding/scheduleComplete").safeBoolean() ?: false,
                        profile = profile, medications = meds,
                        medication = meds.firstOrNull() ?: MedicationInfo(),
                        schedule = savedSchedule,
                        todayRecords = records.filter { it.date == LocalDate.now().toString() },
                        recentRecords = records.sortedBy { it.date },
                        healthHistory = s.child("healthHistory").children.mapNotNull { runCatching { it.getValue(HealthCheck::class.java) }.getOrNull() }.sortedBy { it.date },
                        sideEffectHistory = s.child("sideEffectHistory").children.mapNotNull { runCatching { it.getValue(SideEffectEntry::class.java) }.getOrNull() }.sortedBy { it.date },
                        careMemoHistory = s.child("careMemos").children.mapNotNull { runCatching { it.getValue(CareMemoEntry::class.java) }.getOrNull() }.sortedBy { it.date },
                        alerts = (userAlerts + deviceAlerts).distinctBy { listOf(it.type, it.title, it.message, it.createdAt) },
                        protectorAlarmMillis = s.child("protectorAlarmMillis").safeLong(),
                        aiComment = aiComment
                    )
                    attachDevice(profile.deviceId)
                }
                override fun onCancelled(error: DatabaseError) { close(error.toException()) }
            }
            userRef = ref; userListener = listener; ref.addValueEventListener(listener)
        }
        auth.addAuthStateListener(authListener)
        awaitClose {
            auth.removeAuthStateListener(authListener)
            userRef?.let { ref -> userListener?.let(ref::removeEventListener) }
            detachDevice()
        }
    }

    override suspend fun login(email: String, password: String) { auth.signInWithEmailAndPassword(email, password).await() }
    override suspend fun signup(email: String, password: String) {
        val normalizedEmail = email.trim()
        require(normalizedEmail.isNotBlank() && normalizedEmail.contains("@")) { "올바른 이메일을 입력해 주세요." }
        require(password.length >= 6) { "비밀번호는 6자 이상이어야 합니다." }

        // Firebase 계정 생성
        val result = auth.createUserWithEmailAndPassword(normalizedEmail, password).await()
        val newUid = result.user?.uid ?: error("회원가입 UID를 확인할 수 없습니다.")

        // UID 기준 사용자 데이터 생성
        db.reference.child("users").child(newUid).setValue(
            mapOf(
                "profile" to mapOf(
                    "email" to normalizedEmail,
                    "deviceId" to ""
                ),
                "onboarding" to mapOf(
                    "profileComplete" to false,
                    "medicationComplete" to false,
                    "scheduleComplete" to false
                ),
                "setupComplete" to false
            )
        ).await()

        // 가입 완료 후 로그인 화면으로 복귀
        auth.signOut()
    }
    override suspend fun logout() = auth.signOut()

    override suspend fun savePatientProfile(profile: UserProfile) {
        val current = userRoot().child("profile/deviceId").get().await().safeString()
        val saved = profile.copy(email = auth.currentUser?.email.orEmpty(), deviceId = current)
        db.reference.updateChildren(mapOf(
            "users/${uid()}/profile" to saved,
            "users/${uid()}/onboarding/profileComplete" to true
        )).await()
    }

    override suspend fun saveMedicationSetup(items: List<MedicationInfo>, loadedDays: Int) {
        saveMedications(items)
        val deviceId = userRoot().child("profile/deviceId").get().await().safeString()
        val days = loadedDays.coerceAtLeast(0)

        // 초기 투입량은 기기 처리용 명령으로 전달
        val updates = mutableMapOf<String, Any?>(
            "users/${uid()}/onboarding/medicationComplete" to true
        )
        db.reference.updateChildren(updates).await()

        if (deviceId.isNotBlank() && days > 0) {
            db.reference.child("devices/$deviceId/commands").push().setValue(mapOf(
                "type" to "INITIALIZE_INVENTORY",
                "loadedDays" to days,
                "status" to "PENDING",
                "requestedAt" to ServerValue.TIMESTAMP,
                "requestedByUid" to uid()
            )).await()
        }
    }

    override suspend fun saveSchedule(schedule: MedicationSchedule) {
        require(schedule.intervalHours > 0) { "복용 간격을 확인하세요." }
        val morning = LocalTime.parse(schedule.morningTime)
        val evening = LocalTime.parse(schedule.eveningTime)
        val gap = ChronoUnit.MINUTES.between(morning, evening)
        require(gap >= schedule.intervalHours * 60L) { "저녁 시간은 최소 복용 간격 이후로 설정하세요." }
        val deviceId = userRoot().child("profile/deviceId").get().await().safeString()
        val value = schedule.copy(dinnerTime = schedule.eveningTime, updatedAt = System.currentTimeMillis())
        val updates = mutableMapOf<String, Any?>(
            "users/${uid()}/schedule" to value,
            "users/${uid()}/onboarding/scheduleComplete" to true,
            "users/${uid()}/setupComplete" to true
        )
        if (deviceId.isNotBlank()) {
            updates["devices/$deviceId/medicationSchedule/morningTime"] = value.morningTime
            updates["devices/$deviceId/medicationSchedule/dinnerTime"] = value.eveningTime
            updates["devices/$deviceId/medicationSchedule/intervalHours"] = value.intervalHours
            updates["devices/$deviceId/medicationSchedule/updatedAt"] = ServerValue.TIMESTAMP
        }
        db.reference.updateChildren(updates).await()
    }

    override suspend fun saveMedication(info: MedicationInfo) = saveMedications(listOf(info))
    override suspend fun saveMedications(items: List<MedicationInfo>) {
        val value = items.mapIndexed { i, m -> m.id.ifBlank { "med-${i + 1}" } to m.copy(id = "") }.toMap()
        val deviceId = userRoot().child("profile/deviceId").get().await().safeString()
        val updates = mutableMapOf<String, Any?>("users/${uid()}/medications" to value)
        if (deviceId.isNotBlank()) updates["devices/$deviceId/settings/medications"] = value
        db.reference.updateChildren(updates).await()
    }
    override suspend fun saveSideEffectMemo(memo: String) { userRoot().child("medications/med-1/sideEffectMemo").setValue(memo).await() }
    override suspend fun saveSideEffectEntry(entry: SideEffectEntry) { userRoot().child("sideEffectHistory/${entry.date}").setValue(entry).await() }
    override suspend fun saveHealthCheck(check: HealthCheck) { userRoot().child("healthHistory/${check.date}").setValue(check).await() }
    override suspend fun saveCareMemo(entry: CareMemoEntry) { userRoot().child("careMemos/${entry.date}").setValue(entry).await() }

    override suspend fun refreshMedicineCaution(medicationId: String) {
        require(medicationId.isNotBlank()) { "분석할 약을 선택하세요." }
        val medicineSnap = userRoot().child("medications/$medicationId").get().await()
        val medicine = runCatching { medicineSnap.getValue(MedicationInfo::class.java) }.getOrNull()
            ?: error("선택한 약 정보를 찾을 수 없습니다.")
        val profileSnap = userRoot().child("profile").get().await()
        val profile = runCatching { profileSnap.getValue(UserProfile::class.java) }.getOrNull() ?: UserProfile()
        require(medicine.name.isNotBlank()) { "선택한 약 정보를 찾을 수 없습니다." }

        val prompt = buildString {
            appendLine("사용자 정보와 복용 약을 바탕으로 복약 시 주의할 점, 생활 속 예방법, 확인하면 좋은 이상 증상을 이해하기 쉽게 설명해 주세요.")
            appendLine("의학적 진단을 단정하지 말고 필요한 경우 의료진 상담이 필요한 상황을 구분해 주세요.")
            appendLine("사용자: ${profile.age}세, ${profile.heightCm}cm, ${profile.weightKg}kg")
            appendLine("약품명: ${medicine.name}")
            appendLine("1회 복용량: ${medicine.doseAmount}, 하루 ${medicine.timesPerDay}회, 복용 간격 ${medicine.intervalHours}시간")
            if (medicine.cautionText.isNotBlank()) appendLine("기존 주의 정보: ${medicine.cautionText}")
        }

        userRoot().child("medicineInsightRequests").push().setValue(mapOf(
            "medicationId" to medicationId,
            "medicineName" to medicine.name,
            "medicineNames" to listOf(medicine.name),
            "source" to "MFDS_DRUG_PRODUCT_API+GEMINI",
            "status" to "PENDING",
            "requestedAt" to ServerValue.TIMESTAMP,
            "userContext" to mapOf(
                "age" to profile.age,
                "heightCm" to profile.heightCm,
                "weightKg" to profile.weightKg
            ),
            "medicationContext" to mapOf(
                "name" to medicine.name,
                "doseAmount" to medicine.doseAmount,
                "timesPerDay" to medicine.timesPerDay,
                "intervalHours" to medicine.intervalHours,
                "itemSeq" to medicine.itemSeq,
                "cautionText" to medicine.cautionText
            ),
            "prompt" to prompt
        )).await()
    }

    override suspend fun registerDevice(deviceId: String) {
        require(deviceId.matches(Regex("[A-Za-z0-9_-]{3,64}"))) { "기기 ID 형식을 확인하세요." }
        db.reference.updateChildren(mapOf(
            "users/${uid()}/profile/deviceId" to deviceId,
            "devices/$deviceId/ownerUid" to uid(),
            "devices/$deviceId/network/status" to "PROVISIONING",
            "devices/$deviceId/network/updatedAt" to ServerValue.TIMESTAMP
        )).await()
    }

    override suspend fun requestMedicationWithdrawal(morningDays: Int, eveningDays: Int) {
        require(morningDays >= 0 && eveningDays >= 0 && morningDays + eveningDays > 0) { "1일분 이상 선택하세요." }
        val deviceId = userRoot().child("profile/deviceId").get().await().safeString()
        require(deviceId.isNotBlank()) { "먼저 기기를 등록하세요." }
        val inventory = db.reference.child("devices/$deviceId/inventory").get().await()
        val morningRemaining = inventory.child("remainingDoseCountByPeriod/morning").safeInt() ?: 0
        val eveningRemaining = inventory.child("remainingDoseCountByPeriod/evening").safeInt() ?: 0
        require(morningDays <= morningRemaining) { "아침 약 잔량은 ${morningRemaining}일분입니다." }
        require(eveningDays <= eveningRemaining) { "저녁 약 잔량은 ${eveningRemaining}일분입니다." }
        db.reference.child("devices/$deviceId/commands").push().setValue(mapOf(
            "type" to "WITHDRAW_MEDICATION", "morningDays" to morningDays, "eveningDays" to eveningDays,
            "requestedDoseCount" to morningDays + eveningDays, "status" to "PENDING",
            "requestedAt" to ServerValue.TIMESTAMP, "requestedByUid" to uid()
        )).await()
    }

    override suspend fun addMedicationStock(days: Int) {
        require(days > 0) { "추가할 약 일수를 선택하세요." }
        val deviceId = userRoot().child("profile/deviceId").get().await().safeString()
        require(deviceId.isNotBlank()) { "먼저 기기를 등록하세요." }

        // 약 추가 요청은 기기 명령으로 전달
        db.reference.child("devices/$deviceId/commands").push().setValue(mapOf(
            "type" to "ADD_MEDICATION_STOCK",
            "days" to days,
            "status" to "PENDING",
            "requestedAt" to ServerValue.TIMESTAMP,
            "requestedByUid" to uid()
        )).await()
    }

    private fun calculateNextDoseMillis(schedule: MedicationSchedule): Long? {
        return runCatching {
            val now = LocalDateTime.now()
            val times = listOf(LocalTime.parse(schedule.morningTime), LocalTime.parse(schedule.eveningTime))
            val next = times.map { LocalDateTime.of(now.toLocalDate(), it) }.firstOrNull { it.isAfter(now) }
                ?: LocalDateTime.of(now.toLocalDate().plusDays(1), times.first())
            next.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
        }.getOrNull()
    }
}
