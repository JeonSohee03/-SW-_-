package com.example.smartmedicationcare.ui.screen

import com.example.smartmedicationcare.model.*
import java.time.LocalDate

enum class WarningLevel { INFO, WARNING, CRITICAL }
enum class WarningDestination { DOSE, MEDICATION, WIFI, DEVICE, CARE, WARNINGS }

data class WarningUiItem(
    val title: String,
    val message: String,
    val level: WarningLevel,
    val destination: WarningDestination = WarningDestination.WARNINGS,
    val dosePeriod: DosePeriod? = null
)

fun buildWarningItems(state: AppUiState, nowMillis: Long = System.currentTimeMillis()): List<WarningUiItem> {
    val result = mutableListOf<WarningUiItem>()
    val today = LocalDate.now().toString()
    val hour = 60 * 60 * 1000L

    // 복약 지연 상태 확인
    state.recentRecords
        .filter {
            it.date == today &&
                it.scheduledAtMillis > 0L &&
                it.takenAtMillis == null &&
                it.status != DoseStatus.TAKEN
        }
        .forEach { record ->
            val elapsed = nowMillis - record.scheduledAtMillis
            when {
                elapsed >= 2 * hour -> result += WarningUiItem(
                    title = "${record.period.label} 약을 아직 복용하지 않으셨어요",
                    message = "복용 예정 시간에서 2시간이 지났습니다. 약 봉투 수거 및 복용 여부를 꼭 확인해 주세요.",
                    level = WarningLevel.CRITICAL,
                    destination = WarningDestination.DOSE,
                    dosePeriod = record.period
                )
                elapsed >= hour -> result += WarningUiItem(
                    title = "${record.period.label} 약 복용을 확인해 주세요",
                    message = "복용 예정 시간에서 1시간이 지났지만 아직 복용 기록이 없습니다. 복용 여부를 확인해 주세요.",
                    level = WarningLevel.WARNING,
                    destination = WarningDestination.DOSE,
                    dosePeriod = record.period
                )
            }
        }

    // 네트워크 상태 확인
    val network = state.deviceNetworkStatus.trim().uppercase()
    if (network.isNotBlank() && network !in setOf("ONLINE", "UNREGISTERED", "UNKNOWN", "PROVISIONING")) {
        result += WarningUiItem(
            title = "Wi‑Fi 연결이 끊겼어요",
            message = "현재 기기 네트워크 상태가 '${state.deviceNetworkStatus}'입니다. Wi‑Fi 연결을 확인해 주세요.",
            level = WarningLevel.CRITICAL,
            destination = WarningDestination.WIFI
        )
    }

    // 기기 상태 확인
    val deviceStatus = state.deviceStatus.trim()
    val normalDevice = deviceStatus.equals("정상", true) ||
        deviceStatus.equals("NORMAL", true) ||
        deviceStatus.equals("OK", true)
    val unknownDevice = deviceStatus.isBlank() ||
        deviceStatus.equals("데이터 없음", true) ||
        deviceStatus.equals("확인 중", true)
    if (!normalDevice && !unknownDevice) {
        result += WarningUiItem(
            title = "기기 상태에 이상이 있어요",
            message = "ESP에서 기기 상태를 '$deviceStatus'로 전달했습니다. 기기 상태 화면에서 확인해 주세요.",
            level = WarningLevel.CRITICAL,
            destination = WarningDestination.DEVICE
        )
    }

    // 서버 알림 반영
    state.alerts.filter { it.active && !it.resolved && !it.read }.forEach { alert ->
        val type = alert.type.uppercase()
        val text = "${alert.title} ${alert.message}"
        val destination = when {
            type.contains("MEDICATION") || type.contains("DOSE") || text.contains("복용") -> WarningDestination.DOSE
            type.contains("WIFI") || type.contains("NETWORK") || text.contains("Wi-Fi", true) || text.contains("와이파이") -> WarningDestination.WIFI
            type.contains("DEVICE") || type.contains("ERROR") || text.contains("기기") -> WarningDestination.DEVICE
            type.contains("EMERGENCY") || type.contains("URGENT") || text.contains("응급") -> WarningDestination.WARNINGS
            else -> null
        }
        if (destination != null) {
            val dosePeriod = when {
                text.contains("저녁") -> DosePeriod.EVENING
                text.contains("아침") -> DosePeriod.MORNING
                else -> null
            }
            result += WarningUiItem(
                title = alert.title.ifBlank { if (destination == WarningDestination.WARNINGS) "응급 상황이 감지되었습니다" else "주의 알림" },
                message = alert.message.ifBlank { "기기에서 확인이 필요한 상태가 전달되었습니다." },
                level = if (alert.critical || destination in setOf(WarningDestination.WIFI, WarningDestination.DEVICE, WarningDestination.WARNINGS)) WarningLevel.CRITICAL else WarningLevel.WARNING,
                destination = destination,
                dosePeriod = dosePeriod
            )
        }
    }

    return result.distinctBy { it.title to it.message }
}
