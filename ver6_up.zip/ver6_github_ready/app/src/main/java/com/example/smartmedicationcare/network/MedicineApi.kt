package com.example.smartmedicationcare.network

import retrofit2.http.GET
import retrofit2.http.Query

// 식품의약품안전처 의약품 허가정보 API 규격
interface MedicineApi {
    @GET("getDrugPrdtPrmsnInq05")
    suspend fun searchMedicine(
        @Query("serviceKey") serviceKey: String,
        @Query("item_name") itemName: String,
        @Query("type") responseType: String = "json",
        @Query("pageNo") page: Int = 1,
        @Query("numOfRows") rows: Int = 10
    ): MedicineApiResponse
}

data class MedicineApiResponse(
    val header: MedicineApiHeader = MedicineApiHeader(),
    val body: MedicineApiBody = MedicineApiBody()
)

data class MedicineApiHeader(val resultCode: String = "", val resultMsg: String = "")
data class MedicineApiBody(val items: List<MedicineApiItem> = emptyList(), val totalCount: Int = 0)
data class MedicineApiItem(
    val itemName: String = "", val entpName: String = "", val itemSeq: String = "",
    val mainIngr: String = "", val storageMethod: String = "", val validTerm: String = ""
)
