package com.example.smartmedicationcare.data

import com.example.smartmedicationcare.model.*
import kotlinx.coroutines.flow.Flow

interface MedicationRepository {
    fun observeState(): Flow<AppUiState>
    suspend fun login(email: String, password: String)
    suspend fun signup(email: String, password: String)
    suspend fun logout()
    suspend fun savePatientProfile(profile: UserProfile)
    suspend fun saveMedicationSetup(items: List<MedicationInfo>, loadedDays: Int)
    suspend fun saveSchedule(schedule: MedicationSchedule)
    suspend fun saveMedication(info: MedicationInfo)
    suspend fun saveMedications(items: List<MedicationInfo>)
    suspend fun saveSideEffectMemo(memo: String)
    suspend fun saveSideEffectEntry(entry: SideEffectEntry)
    suspend fun saveHealthCheck(check: HealthCheck)
    suspend fun saveCareMemo(entry: CareMemoEntry)
    suspend fun refreshMedicineCaution(medicationId: String)
    suspend fun registerDevice(deviceId: String)
    suspend fun requestMedicationWithdrawal(morningDays: Int, eveningDays: Int)
    suspend fun addMedicationStock(days: Int)
}
