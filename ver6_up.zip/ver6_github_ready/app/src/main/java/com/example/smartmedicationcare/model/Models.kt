package com.example.smartmedicationcare.model

enum class DosePeriod(val label: String) { MORNING("아침"), LUNCH("점심"), EVENING("저녁") }
enum class DoseStatus { SCHEDULED, DISPENSED, TAKEN, MISSED }

data class UserProfile(
    val email: String = "", val age: Int = 0, val dateOfBirth: String = "",
    val gender: String = "", val heightCm: Double = 0.0, val weightKg: Double = 0.0,
    val phoneNumber: String = "", val caregiverPhoneNumber: String = "",
    val medicalConditions: List<String> = emptyList(), val deviceId: String = ""
) { val guardianPhone: String get() = caregiverPhoneNumber }

data class MedicationInfo(
    val id: String = "", val name: String = "", val strengthValue: Double = 0.0,
    val strengthUnit: String = "mg", val doseAmount: String = "1정",
    val dosageValue: Double = 1.0, val dosageUnit: String = "정",
    val intervalHours: Int = 12, val timesPerDay: Int = 2, val totalDays: Int = 30,
    val startDate: String = "", val itemSeq: String = "", val cautionText: String = "", val sideEffectMemo: String = ""
)

data class MedicationSchedule(
    val intervalHours: Int = 12, val morningTime: String = "08:00",
    val eveningTime: String = "20:00", val dinnerTime: String = "20:00",
    val nextDoseAt: Long? = null, val updatedAt: Long = 0L
)

data class DoseRecord(
    val id: String = "", val date: String = "", val period: DosePeriod = DosePeriod.MORNING,
    val scheduledAtMillis: Long = 0L, val programScore: Int? = null,
    val dispensedAtMillis: Long? = null, val takenAtMillis: Long? = null,
    val status: DoseStatus = DoseStatus.SCHEDULED,
    val hasAnomaly: Boolean = false, val anomalyMessage: String = "",
    val deviceError: Boolean = false, val switchError: Boolean = false
)

data class InventoryState(
    val remainingCount: Int = 0,
    val morningRemainingCount: Int = 0,
    val eveningRemainingCount: Int = 0,
    val updatedAt: Long = 0L
)

data class WithdrawalCommand(
    val id: String = "", val type: String = "WITHDRAW_MEDICATION",
    val requestedDoseCount: Int = 0, val status: String = "", val requestedAt: Long = 0L,
    val morningDays: Int = 0, val eveningDays: Int = 0,
    val completedAt: Long? = null, val errorMessage: String = ""
)

data class HealthCheck(
    val date: String = "", val meal: Int = 3, val sleep: Int = 3,
    val activity: Int = 3, val mood: Int = 3, val memo: String = "",
    val totalScore: Int = 50, val updatedAtMillis: Long = 0L
)

data class SideEffectEntry(val date: String = "", val memo: String = "", val updatedAtMillis: Long = 0L)
data class CareMemoEntry(val date: String = "", val memo: String = "", val updatedAtMillis: Long = 0L)
data class AlertItem(
    val type: String = "",
    val title: String = "",
    val message: String = "",
    val createdAt: String = "",
    val critical: Boolean = false,
    val read: Boolean = false,
    val resolved: Boolean = false,
    val active: Boolean = true
)

data class AppUiState(
    val loggedIn: Boolean = false, val profileComplete: Boolean = false,
    val medicationComplete: Boolean = false, val scheduleComplete: Boolean = false,
    val setupComplete: Boolean = false, val profile: UserProfile = UserProfile(),
    val medication: MedicationInfo = MedicationInfo(), val medications: List<MedicationInfo> = emptyList(),
    val schedule: MedicationSchedule = MedicationSchedule(),
    val todayRecords: List<DoseRecord> = emptyList(), val recentRecords: List<DoseRecord> = emptyList(),
    val inventory: InventoryState = InventoryState(), val lastWithdrawal: WithdrawalCommand? = null,
    val deviceNetworkStatus: String = "UNREGISTERED", val deviceStatus: String = "데이터 없음",
    val healthHistory: List<HealthCheck> = emptyList(), val sideEffectHistory: List<SideEffectEntry> = emptyList(),
    val careMemoHistory: List<CareMemoEntry> = emptyList(),
    val alerts: List<AlertItem> = emptyList(), val nextAlarmMillis: Long? = null,
    val protectorAlarmMillis: Long? = null, val aiComment: String = ""
)
