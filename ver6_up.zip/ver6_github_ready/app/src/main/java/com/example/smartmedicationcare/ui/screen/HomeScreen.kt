package com.example.smartmedicationcare.ui.screen

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ChevronLeft
import androidx.compose.material.icons.rounded.ChevronRight
import androidx.compose.material.icons.rounded.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.smartmedicationcare.model.*
import com.example.smartmedicationcare.ui.components.*
import com.example.smartmedicationcare.util.*
import java.time.LocalDate
import kotlinx.coroutines.delay

@Composable
fun HomeScreen(
    state: AppUiState,
    padding: PaddingValues,
    onNextAlarm: () -> Unit,
    onWarningSelected: (WarningUiItem) -> Unit,
    onDoseDetail: (DosePeriod) -> Unit,
    onSaveHealth: (HealthCheck) -> Unit
) {
    val today = LocalDate.now()
    val todayHealth = state.healthHistory.firstOrNull { it.date == today.toString() }
    val todayRecords = state.recentRecords.filter { it.date == today.toString() }.ifEmpty { state.todayRecords }
    val periods = listOf(DosePeriod.MORNING, DosePeriod.EVENING)
    val completed = periods.count { p -> todayRecords.any { it.period == p && it.status == DoseStatus.TAKEN } }
    val progress = completed / 2f
    var nowMillis by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(30_000)
            nowMillis = System.currentTimeMillis()
        }
    }
    val warnings = buildWarningItems(state, nowMillis).take(5)
    val nextDoseMillis = resolvedNextDoseMillis(state, nowMillis)

    LazyColumn(
        Modifier.padding(padding).fillMaxSize(),
        contentPadding = PaddingValues(18.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(todayLabel(), color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text("홈", style = MaterialTheme.typography.headlineLarge)
        }
        if (todayHealth == null) item { HomeConditionCheck(onSave = onSaveHealth) }
        item {
            Column(
                Modifier.fillMaxWidth().background(
                    Brush.linearGradient(listOf(Color(0xFF0A84FF), Color(0xFF5AC8FA))),
                    RoundedCornerShape(26.dp)
                ).padding(22.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text("오늘의 현황", color = Color.White.copy(alpha = .85f))
                Text(todayHealth?.let { "상태 점수 ${it.totalScore}점" } ?: "상태 체크 전", color = Color.White, style = MaterialTheme.typography.headlineSmall)
                Text("복약 $completed/2회 완료", color = Color.White.copy(alpha = .92f))
                LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth(), color = Color.White)
            }
        }
        item {
            AppCard("다음 알림", onClick = onNextAlarm) {
                Text(formatTime(nextDoseMillis), style = MaterialTheme.typography.headlineLarge)
                Text(
                    "AI가 실제 복용 시간과 최소 허용 간격을 반영해 다음 복용 시간을 조정합니다.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }
        item { Text("오늘의 복약 기록", style = MaterialTheme.typography.headlineSmall) }
        item {
            AppCard("") {
                periods.forEachIndexed { i, period ->
                    if (i > 0) HorizontalDivider()
                    val record = todayRecords.firstOrNull { it.period == period }
                    Row(
                        Modifier.fillMaxWidth().clickable { onDoseDetail(period) }.padding(vertical = 7.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(period.label, style = MaterialTheme.typography.titleMedium)
                            Text(
                                "복용 예정 ${formatTime(scheduledDoseMillis(state, period, today))}",
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Text(
                            when (record?.status) {
                                DoseStatus.TAKEN -> "복용 완료"
                                DoseStatus.DISPENSED -> "배출 완료"
                                DoseStatus.MISSED -> "미복용"
                                else -> "복용 예정"
                            }
                        )
                    }
                }
            }
        }
        if (warnings.isNotEmpty()) {
            item { Text("주의 알림", style = MaterialTheme.typography.headlineSmall) }
            item {
                WarningCarousel(
                    warnings = warnings,
                    onSelected = onWarningSelected
                )
            }
        }
    }
}

@Composable
private fun WarningCarousel(
    warnings: List<WarningUiItem>,
    onSelected: (WarningUiItem) -> Unit
) {
    if (warnings.isEmpty()) {
        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(24.dp),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
            color = MaterialTheme.colorScheme.surface
        ) {
            Box(Modifier.fillMaxWidth().height(210.dp), contentAlignment = Alignment.Center) {
                Text("현재 주의 알림이 없습니다.", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        return
    }

    var index by remember(warnings.map { it.title to it.message }) { mutableIntStateOf(0) }
    if (index > warnings.lastIndex) index = 0
    val current = warnings[index]
    val accent = when (current.level) {
        WarningLevel.INFO -> Color(0xFF2EAF62)
        WarningLevel.WARNING -> Color(0xFFF59E0B)
        WarningLevel.CRITICAL -> MaterialTheme.colorScheme.error
    }

    Surface(
        modifier = Modifier.fillMaxWidth().clickable { onSelected(current) },
        shape = RoundedCornerShape(24.dp),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
        color = MaterialTheme.colorScheme.surface
    ) {
        Column(
            modifier = Modifier.fillMaxWidth().heightIn(min = 230.dp).padding(horizontal = 22.dp, vertical = 20.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.Warning, contentDescription = null, tint = accent)
                    Spacer(Modifier.width(10.dp))
                    Text(current.title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = accent)
                }
                Text(current.message, style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text("눌러서 관련 화면으로 이동", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { index = if (index == 0) warnings.lastIndex else index - 1 }) {
                    Icon(Icons.Rounded.ChevronLeft, contentDescription = "이전 알림")
                }
                warnings.forEachIndexed { dotIndex, _ ->
                    Box(
                        Modifier.padding(horizontal = 4.dp).size(if (dotIndex == index) 10.dp else 8.dp)
                            .background(
                                if (dotIndex == index) accent else MaterialTheme.colorScheme.outlineVariant,
                                CircleShape
                            )
                    )
                }
                IconButton(onClick = { index = if (index == warnings.lastIndex) 0 else index + 1 }) {
                    Icon(Icons.Rounded.ChevronRight, contentDescription = "다음 알림")
                }
            }
        }
    }
}

@Composable
private fun HomeConditionCheck(onSave: (HealthCheck) -> Unit) {
    var meal by remember { mutableIntStateOf(2) }
    var sleep by remember { mutableIntStateOf(2) }
    var activity by remember { mutableIntStateOf(2) }
    var mood by remember { mutableIntStateOf(2) }
    val score = (((meal + sleep + activity + mood - 4) / 8f) * 100).toInt()
    AppCard("오늘 상태 체크") {
        Text("오늘의 상태를 간단히 기록해 주세요.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        HomeConditionRow("식사", meal) { meal = it }
        HomeConditionRow("수면", sleep) { sleep = it }
        HomeConditionRow("활동", activity) { activity = it }
        HomeConditionRow("기분", mood) { mood = it }
        Button(
            onClick = { onSave(HealthCheck(LocalDate.now().toString(), meal, sleep, activity, mood, totalScore = score, updatedAtMillis = System.currentTimeMillis())) },
            modifier = Modifier.fillMaxWidth()
        ) { Text("상태 저장") }
    }
}

@Composable
private fun HomeConditionRow(label: String, value: Int, onChange: (Int) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(label, fontWeight = FontWeight.SemiBold)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("나쁨" to 1, "보통" to 2, "좋음" to 3).forEach { (text, v) ->
                Surface(
                    Modifier.weight(1f).clickable { onChange(v) },
                    shape = RoundedCornerShape(10.dp),
                    color = if (value == v) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surface,
                    border = if (value == v) null else BorderStroke(.5.dp, MaterialTheme.colorScheme.outlineVariant)
                ) {
                    Box(Modifier.padding(vertical = 9.dp), contentAlignment = Alignment.Center) {
                        Text(text, color = if (value == v) Color.White else MaterialTheme.colorScheme.onSurface)
                    }
                }
            }
        }
    }
}
