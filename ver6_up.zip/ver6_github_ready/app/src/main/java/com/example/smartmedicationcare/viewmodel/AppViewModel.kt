package com.example.smartmedicationcare.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.smartmedicationcare.data.*
import com.example.smartmedicationcare.model.*
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow

class AppViewModel(
    private val repository: MedicationRepository
) : ViewModel() {

    val uiState = repository.observeState()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), AppUiState())

    private val _operationMessage = MutableStateFlow("")
    val operationMessage = _operationMessage.asStateFlow()

    fun login(email: String, password: String) = run {
        repository.login(email, password)
    }

    fun signup(email: String, password: String, onSuccess: () -> Unit) {
        viewModelScope.launch {
            _operationMessage.value = "회원가입 처리 중..."
            runCatching { repository.signup(email, password) }
                .onSuccess {
                    _operationMessage.value = "회원가입이 완료되었습니다. 로그인해 주세요."
                    onSuccess()
                }
                .onFailure { error ->
                    _operationMessage.value = when {
                        error.message?.contains("email address is already in use", ignoreCase = true) == true ->
                            "이미 가입된 이메일입니다."
                        error.message?.contains("badly formatted", ignoreCase = true) == true ->
                            "이메일 형식을 확인해 주세요."
                        error.message?.contains("network", ignoreCase = true) == true ->
                            "네트워크 연결을 확인해 주세요."
                        else -> error.localizedMessage ?: "회원가입에 실패했습니다."
                    }
                }
        }
    }

    fun logout() = run { repository.logout() }

    fun savePatientProfile(profile: UserProfile) = run { repository.savePatientProfile(profile) }
    fun saveMedicationSetup(items: List<MedicationInfo>, loadedDays: Int) = run { repository.saveMedicationSetup(items, loadedDays) }
    fun saveSchedule(schedule: MedicationSchedule) = run { repository.saveSchedule(schedule) }

    fun saveMedication(info: MedicationInfo) = run {
        repository.saveMedication(info)
    }

    fun saveMedications(items: List<MedicationInfo>) = run {
        repository.saveMedications(items)
    }

    fun saveMemo(memo: String) = run {
        repository.saveSideEffectMemo(memo)
    }

    fun saveSideEffect(entry: SideEffectEntry) = run {
        repository.saveSideEffectEntry(entry)
    }

    fun saveHealth(check: HealthCheck) = run {
        repository.saveHealthCheck(check)
    }

    fun refreshMedicine(medicationId: String) = run {
        repository.refreshMedicineCaution(medicationId)
    }

    fun saveCareMemo(entry: CareMemoEntry) = run { repository.saveCareMemo(entry) }

    fun registerDevice(deviceId: String) = run { repository.registerDevice(deviceId) }
    fun withdrawMedication(morningDays: Int, eveningDays: Int) = run {
        repository.requestMedicationWithdrawal(morningDays, eveningDays)
    }

    fun addMedicationStock(days: Int) = run {
        repository.addMedicationStock(days)
    }

    private fun run(block: suspend () -> Unit) {
        viewModelScope.launch {
            runCatching { block() }
                .onSuccess { _operationMessage.value = "" }
                .onFailure {
                    _operationMessage.value = it.localizedMessage ?: "요청을 처리하지 못했습니다."
                    it.printStackTrace()
                }
        }
    }

    class Factory : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return AppViewModel(FirebaseMedicationRepository()) as T
        }
    }
}
