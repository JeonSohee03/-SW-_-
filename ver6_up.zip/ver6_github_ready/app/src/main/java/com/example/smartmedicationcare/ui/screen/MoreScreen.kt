@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
package com.example.smartmedicationcare.ui.screen

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.smartmedicationcare.model.AppUiState

@Composable
fun MoreScreen(
    state: AppUiState,
    padding: PaddingValues,
    onWifi: () -> Unit,
    onDevice: () -> Unit,
    onPrivacy: () -> Unit
) {
    var guardian by remember { mutableStateOf(false) }

    Column(
        Modifier
            .padding(padding)
            .fillMaxSize()
            .padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("더보기", style = MaterialTheme.typography.headlineLarge)

        Card {
            ListItem(
                headlineContent = { Text("Wi-Fi 설정") },
                modifier = Modifier.clickable(onClick = onWifi),
                supportingContent = { Text("연결 상태 · ${state.deviceNetworkStatus}") }
            )
            HorizontalDivider(Modifier.padding(start = 16.dp))

            ListItem(
                headlineContent = { Text("기기 상태") },
                modifier = Modifier.clickable(onClick = onDevice),
                supportingContent = { Text(state.deviceStatus) }
            )
            HorizontalDivider(Modifier.padding(start = 16.dp))

            ListItem(
                headlineContent = { Text("보호자 정보") },
                modifier = Modifier.clickable { guardian = true },
                supportingContent = {
                    Text(state.profile.caregiverPhoneNumber.ifBlank { "미등록" })
                }
            )
            HorizontalDivider(Modifier.padding(start = 16.dp))

            ListItem(
                headlineContent = { Text("개인정보 및 로그아웃") },
                modifier = Modifier.clickable(onClick = onPrivacy)
            )
        }
    }

    if (guardian) {
        AlertDialog(
            onDismissRequest = { guardian = false },
            confirmButton = {
                TextButton(onClick = { guardian = false }) { Text("확인") }
            },
            title = { Text("보호자 정보") },
            text = {
                Text(
                    state.profile.caregiverPhoneNumber.ifBlank {
                        "등록된 보호자 연락처가 없습니다."
                    }
                )
            }
        )
    }
}

@Composable
fun PrivacyScreen(
    state: AppUiState,
    onBack: () -> Unit,
    onEdit: () -> Unit,
    onLogout: () -> Unit
) {
    var confirm by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("개인정보 및 로그아웃") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Rounded.ArrowBack, contentDescription = "뒤로")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            Modifier.padding(padding).padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text("이메일: ${state.profile.email}")
            Text("나이: ${state.profile.age}세")
            Text("성별: ${state.profile.gender}")
            Text("보호자 연락처: ${state.profile.caregiverPhoneNumber}")
            Button(onClick = onEdit, modifier = Modifier.fillMaxWidth()) {
                Text("변경하기")
            }
            OutlinedButton(
                onClick = { confirm = true },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("로그아웃")
            }
        }
    }

    if (confirm) {
        AlertDialog(
            onDismissRequest = { confirm = false },
            dismissButton = {
                TextButton(onClick = { confirm = false }) { Text("취소") }
            },
            confirmButton = {
                TextButton(onClick = {
                    confirm = false
                    onLogout()
                }) { Text("로그아웃") }
            },
            title = { Text("로그아웃할까요?") }
        )
    }
}
