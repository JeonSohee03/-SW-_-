package com.example.smartmedicationcare.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

@Composable
fun AppCard(
    title: String,
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    val clickModifier = if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier
    ElevatedCard(
        modifier = modifier.fillMaxWidth().then(clickModifier),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.elevatedCardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            Modifier.padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (title.isNotBlank()) Text(title, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
            content()
        }
    }
}

@Composable
fun LabelValue(label: String, value: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun SimpleLineChart(values: List<Float>, modifier: Modifier = Modifier) {
    if (values.isEmpty()) return
    Canvas(modifier.fillMaxWidth().height(150.dp)) {
        val max = values.maxOrNull()?.coerceAtLeast(1f) ?: 1f
        val min = values.minOrNull() ?: 0f
        val range = (max - min).coerceAtLeast(1f)
        val step = if (values.size <= 1) 0f else size.width / (values.size - 1)

        repeat(5) { i ->
            val y = size.height * i / 4f
            drawLine(Color.LightGray, Offset(0f, y), Offset(size.width, y), 1f)
        }

        values.zipWithNext().forEachIndexed { i, pair ->
            val y1 = size.height - ((pair.first - min) / range * size.height)
            val y2 = size.height - ((pair.second - min) / range * size.height)
            drawLine(
                Color(0xFF007AFF),
                Offset(i * step, y1),
                Offset((i + 1) * step, y2),
                5f
            )
        }
    }
}

@Composable
fun SimpleBarChart(values: List<Float>, modifier: Modifier = Modifier) {
    if (values.isEmpty()) return
    Canvas(modifier.fillMaxWidth().height(150.dp)) {
        val max = values.maxOrNull()?.coerceAtLeast(1f) ?: 1f
        val barSpace = size.width / values.size
        val barWidth = barSpace * 0.45f

        values.forEachIndexed { index, value ->
            val h = value / max * size.height
            val left = index * barSpace + (barSpace - barWidth) / 2
            drawRoundRect(
                color = Color(0xFFB9A9FF),
                topLeft = Offset(left, size.height - h),
                size = androidx.compose.ui.geometry.Size(barWidth, h),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(10f, 10f)
            )
        }
    }
}
