@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
package com.example.smartmedicationcare.ui.screen

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.ShowChart
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.smartmedicationcare.model.*
import com.example.smartmedicationcare.ui.components.*
import com.example.smartmedicationcare.util.formatTime
import java.time.LocalDate

@Composable
fun CareRecordScreen(
    state: AppUiState,
    padding: PaddingValues,
    onSaveMemo: (CareMemoEntry) -> Unit,
    onCalendar: () -> Unit
) {
    val today = LocalDate.now()
    val health = state.healthHistory.firstOrNull { it.date == today.toString() }
    val memoEntry = state.careMemoHistory.firstOrNull { it.date == today.toString() }
    var memo by remember(memoEntry) { mutableStateOf(memoEntry?.memo.orEmpty()) }
    var editing by remember(memoEntry) { mutableStateOf(memoEntry == null) }

    LazyColumn(
        modifier = Modifier.padding(padding).fillMaxSize(),
        contentPadding = PaddingValues(18.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item { Text("케어 기록", style = MaterialTheme.typography.headlineLarge) }
        item {
            AppCard("오늘의 상태 점수") {
                Text(health?.let { "${it.totalScore}점" } ?: "기록 없음", style = MaterialTheme.typography.displayMedium)
                Text(
                    "홈에서 입력한 상태 체크를 기준으로 계산됩니다.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
        item {
            AppCard("상태 메모 · ${today.monthValue}월 ${today.dayOfMonth}일") {
                if (editing) {
                    OutlinedTextField(
                        value = memo,
                        onValueChange = { memo = it },
                        label = { Text("오늘의 상태 메모") },
                        modifier = Modifier.fillMaxWidth().height(180.dp)
                    )
                    Button(
                        onClick = {
                            onSaveMemo(CareMemoEntry(today.toString(), memo, System.currentTimeMillis()))
                            editing = false
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("상태 저장") }
                } else {
                    Text(memo.ifBlank { "작성된 상태 메모가 없습니다." })
                    OutlinedButton(onClick = { editing = true }, modifier = Modifier.fillMaxWidth()) { Text("상태 수정") }
                }
            }
        }
        item {
            AppCard("캘린더 기록", onClick = onCalendar) {
                Text("복약 기록, 상태 점수, 프로그램 점수와 메모를 날짜별로 확인합니다.")
                Text("캘린더 보기  ›", color = MaterialTheme.colorScheme.primary)
            }
        }
    }
}

private enum class CalendarMetric(val label: String) {
    DOSE("복약 기록"), HEALTH("상태 점수"), PROGRAM("프로그램 점수"), SIDE("부작용 메모"), CARE("상태 메모")
}

@Composable
fun CareCalendarScreen(
    state: AppUiState,
    onBack: () -> Unit,
    onSaveSide: (SideEffectEntry) -> Unit,
    onSaveCare: (CareMemoEntry) -> Unit
) {
    var selectedDate by remember { mutableStateOf(LocalDate.now()) }
    var metric by remember { mutableStateOf(CalendarMetric.DOSE) }
    var graph by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("캘린더 기록") },
                navigationIcon = { IconButton(onBack) { Icon(Icons.Rounded.ArrowBack, null) } },
                actions = {
                    TextButton(onClick = { selectedDate = LocalDate.now() }) { Text("오늘") }
                    IconButton(onClick = { graph = !graph }) { Icon(Icons.Rounded.ShowChart, "그래프") }
                }
            )
        }
    ) { p ->
        LazyColumn(
            modifier = Modifier.padding(p).fillMaxSize(),
            contentPadding = PaddingValues(18.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            if (graph) item { MonthlyCareGraph(state) }
            item {
                AppCard("${selectedDate.year}년 ${selectedDate.monthValue}월") {
                    MonthCalendar(
                        selectedDate = selectedDate,
                        onDateSelected = { selectedDate = it },
                        dayProgress = { date -> calendarProgress(state, date) },
                        dayProgressColor = { date -> calendarProgressColor(state, date) },
                        dayMarker = { }
                    )
                }
            }
            item {
                Text(
                    "${selectedDate.monthValue}월 ${selectedDate.dayOfMonth}일 기록",
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold
                )
            }
            item {
                MetricSummaryCard(
                    title = "복약 기록",
                    summary = doseSummaryText(state, selectedDate),
                    selected = metric == CalendarMetric.DOSE,
                    onClick = { metric = CalendarMetric.DOSE }
                )
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    MetricSummaryCard(
                        title = "상태 점수",
                        summary = healthSummaryText(state, selectedDate),
                        selected = metric == CalendarMetric.HEALTH,
                        onClick = { metric = CalendarMetric.HEALTH },
                        modifier = Modifier.weight(1f)
                    )
                    MetricSummaryCard(
                        title = "프로그램 점수",
                        summary = programSummaryText(state, selectedDate),
                        selected = metric == CalendarMetric.PROGRAM,
                        onClick = { metric = CalendarMetric.PROGRAM },
                        modifier = Modifier.weight(1f)
                    )
                }
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    MetricSummaryCard(
                        title = "부작용 메모",
                        summary = memoSummaryText(state.sideEffectHistory.firstOrNull { it.date == selectedDate.toString() }?.memo),
                        selected = metric == CalendarMetric.SIDE,
                        onClick = { metric = CalendarMetric.SIDE },
                        modifier = Modifier.weight(1f)
                    )
                    MetricSummaryCard(
                        title = "상태 메모",
                        summary = memoSummaryText(state.careMemoHistory.firstOrNull { it.date == selectedDate.toString() }?.memo),
                        selected = metric == CalendarMetric.CARE,
                        onClick = { metric = CalendarMetric.CARE },
                        modifier = Modifier.weight(1f)
                    )
                }
            }
            item {
                CalendarMetricDetail(state, selectedDate, metric, onSaveSide, onSaveCare)
            }
        }
    }
}

@Composable
private fun MetricSummaryCard(
    title: String,
    summary: String,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    ElevatedCard(
        modifier = modifier.fillMaxWidth().clickable(onClick = onClick),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.elevatedCardColors(
            containerColor = if (selected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface
        )
    ) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Text(summary, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

private fun doseSummaryText(state: AppUiState, date: LocalDate): String {
    val records = state.recentRecords.filter { it.date == date.toString() }
    val taken = records.count { it.status == DoseStatus.TAKEN }
    return if (records.isEmpty()) "기록 없음" else "${taken}/${records.size}회 복용 완료"
}

private fun healthSummaryText(state: AppUiState, date: LocalDate): String =
    state.healthHistory.firstOrNull { it.date == date.toString() }?.let { "${it.totalScore}점" } ?: "기록 없음"

private fun programSummaryText(state: AppUiState, date: LocalDate): String {
    val score = state.recentRecords.filter { it.date == date.toString() }.mapNotNull { it.programScore }.average()
    return if (score.isNaN()) "기록 없음" else "${score.toInt()}점"
}

private fun memoSummaryText(text: String?): String = when {
    text.isNullOrBlank() -> "작성된 메모 없음"
    text.length <= 20 -> text
    else -> text.take(20) + "…"
}

private fun calendarProgress(state: AppUiState, date: LocalDate): Float? {
    val dateKey = date.toString()
    val records = state.recentRecords.filter {
        it.date == dateKey && it.period in setOf(DosePeriod.MORNING, DosePeriod.EVENING)
    }
    if (records.isEmpty()) return null

    val morningTaken = records.any { it.period == DosePeriod.MORNING && it.status == DoseStatus.TAKEN }
    val eveningTaken = records.any { it.period == DosePeriod.EVENING && it.status == DoseStatus.TAKEN }
    return ((if (morningTaken) 0.5f else 0f) + (if (eveningTaken) 0.5f else 0f))
}

private fun calendarProgressColor(state: AppUiState, date: LocalDate): Color {
    val progress = calendarProgress(state, date) ?: return Color(0xFFE6E6E6)
    return when {
        progress >= 0.8f -> Color(0xFF34C759)
        progress >= 0.5f -> Color(0xFFFF9500)
        else -> Color(0xFFFF6B6B)
    }
}

@Composable
private fun CalendarMetricDetail(
    state: AppUiState,
    date: LocalDate,
    metric: CalendarMetric,
    onSaveSide: (SideEffectEntry) -> Unit,
    onSaveCare: (CareMemoEntry) -> Unit
) {
    val dateKey = date.toString()
    val records = state.recentRecords.filter { it.date == dateKey }
    val health = state.healthHistory.firstOrNull { it.date == dateKey }
    val side = state.sideEffectHistory.firstOrNull { it.date == dateKey }
    val care = state.careMemoHistory.firstOrNull { it.date == dateKey }

    AppCard(metric.label) {
        when (metric) {
            CalendarMetric.DOSE -> {
                if (records.isEmpty()) {
                    Text("복약 기록이 없습니다.")
                } else {
                    listOf(DosePeriod.MORNING, DosePeriod.EVENING).forEach { p ->
                        records.firstOrNull { it.period == p }?.let { r ->
                            LabelValue("${p.label} 배출 시간", formatTime(r.dispensedAtMillis))
                            LabelValue("${p.label} 복용 시간", formatTime(r.takenAtMillis))
                        } ?: run {
                            LabelValue("${p.label} 배출 시간", "-")
                            LabelValue("${p.label} 복용 시간", "-")
                        }
                    }
                }
                Text(
                    "복용 시간은 초음파 센서로 약 봉투를 가져간 시점을 감지한 서버 기록을 기준으로 산정합니다.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            CalendarMetric.HEALTH -> {
                Text(
                    health?.let { "${it.totalScore}점" } ?: "상태 점수 기록이 없습니다.",
                    style = MaterialTheme.typography.headlineMedium
                )
            }
            CalendarMetric.PROGRAM -> {
                val score = records.mapNotNull { it.programScore }.average().takeIf { !it.isNaN() }
                Text(
                    score?.let { "${it.toInt()}점" } ?: "프로그램 점수 기록이 없습니다.",
                    style = MaterialTheme.typography.headlineMedium
                )
            }
            CalendarMetric.SIDE -> {
                EditableCalendarMemo(
                    initial = side?.memo.orEmpty(),
                    label = "부작용 메모",
                    onSave = { onSaveSide(SideEffectEntry(dateKey, it, System.currentTimeMillis())) }
                )
            }
            CalendarMetric.CARE -> {
                EditableCalendarMemo(
                    initial = care?.memo.orEmpty(),
                    label = "상태 메모",
                    onSave = { onSaveCare(CareMemoEntry(dateKey, it, System.currentTimeMillis())) }
                )
            }
        }
    }
}

@Composable
private fun EditableCalendarMemo(initial: String, label: String, onSave: (String) -> Unit) {
    var editing by remember(initial) { mutableStateOf(false) }
    var memo by remember(initial) { mutableStateOf(initial) }
    if (editing) {
        OutlinedTextField(
            value = memo,
            onValueChange = { memo = it },
            label = { Text(label) },
            modifier = Modifier.fillMaxWidth().height(180.dp)
        )
        Button(onClick = { onSave(memo); editing = false }, modifier = Modifier.fillMaxWidth()) { Text("저장") }
    } else {
        Text(initial.ifBlank { "작성된 메모가 없습니다." })
        OutlinedButton(onClick = { editing = true }, modifier = Modifier.fillMaxWidth()) { Text("수정") }
    }
}

@Composable
private fun MonthlyCareGraph(state: AppUiState) {
    val end = LocalDate.now()
    val dates = (29 downTo 0).map { end.minusDays(it.toLong()) }
    val health = dates.map { d -> state.healthHistory.firstOrNull { it.date == d.toString() }?.totalScore?.toFloat() }
    val program = dates.map { d -> state.recentRecords.filter { it.date == d.toString() }.mapNotNull { it.programScore }.average().takeIf { !it.isNaN() }?.toFloat() }
    val dose = dates.map { d ->
        val rs = state.recentRecords.filter { it.date == d.toString() }
        if (rs.isEmpty()) null else rs.count { it.status == DoseStatus.TAKEN } / rs.size.toFloat() * 100f
    }
    AppCard("최근 한 달 그래프") {
        SimpleLineGraph(listOf(health, program, dose))
        Text(
            "최근 30일의 상태 점수, 프로그램 점수, 복약 완료율을 0~100 기준으로 함께 표시합니다. 기록이 없는 날짜는 선에서 제외됩니다.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
private fun SimpleLineGraph(series: List<List<Float?>>) {
    Canvas(Modifier.fillMaxWidth().height(210.dp)) {
        val w = size.width
        val h = size.height
        val colors = listOf(Color(0xFF0A84FF), Color(0xFFFF9500), Color(0xFF34C759))
        series.forEachIndexed { si, data ->
            val path = Path()
            var started = false
            data.forEachIndexed { i, v ->
                if (v != null) {
                    val x = i / (data.size - 1f) * w
                    val y = h - (v.coerceIn(0f, 100f) / 100f * h)
                    if (!started) {
                        path.moveTo(x, y)
                        started = true
                    } else {
                        path.lineTo(x, y)
                    }
                }
            }
            drawPath(path, colors[si], style = androidx.compose.ui.graphics.drawscope.Stroke(width = 4f))
        }
        drawLine(Color.LightGray, Offset(0f, h), Offset(w, h), 2f)
    }
}
