package com.example.smartmedicationcare.util

import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

private val ko = Locale.KOREA

fun todayAt(hour: Int, minute: Int = 0): Long =
    Calendar.getInstance().apply {
        set(Calendar.HOUR_OF_DAY, hour)
        set(Calendar.MINUTE, minute)
        set(Calendar.SECOND, 0)
        set(Calendar.MILLISECOND, 0)
    }.timeInMillis

fun formatTime(millis: Long?): String =
    if (millis == null) "-" else SimpleDateFormat("HH:mm", ko).format(Date(millis))

fun formatDateTime(millis: Long?): String =
    if (millis == null) "-" else SimpleDateFormat("MM월 dd일 HH:mm", ko).format(Date(millis))

fun todayLabel(): String =
    SimpleDateFormat("yyyy년 MM월 dd일 (E)", ko).format(Date())
