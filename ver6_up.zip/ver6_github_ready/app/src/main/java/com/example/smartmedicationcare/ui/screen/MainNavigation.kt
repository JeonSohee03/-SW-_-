package com.example.smartmedicationcare.ui.screen

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.navigation.compose.*
import com.example.smartmedicationcare.model.*
import com.example.smartmedicationcare.viewmodel.AppViewModel

private data class BottomItem(val route:String,val label:String,val icon:ImageVector)

@Composable
fun MainNavigation(state:AppUiState,vm:AppViewModel){
    val nav=rememberNavController(); var selectedDose by remember{mutableStateOf(DosePeriod.MORNING)}
    val items=listOf(
        BottomItem("home","홈",Icons.Rounded.Home),
        BottomItem("medication","약",Icons.Rounded.Medication),
        BottomItem("care","케어 기록",Icons.Rounded.Favorite),
        BottomItem("more","더보기",Icons.Rounded.MoreHoriz)
    )
    Scaffold(bottomBar={val current=nav.currentBackStackEntryAsState().value?.destination?.route;if(current in items.map{it.route}) NavigationBar(tonalElevation=0.dp){items.forEach{item->NavigationBarItem(selected=current==item.route,onClick={nav.navigate(item.route){popUpTo("home");launchSingleTop=true}},icon={Icon(item.icon,item.label)},label={Text(item.label)})}}}){padding->
        NavHost(nav,startDestination="home"){
            composable("home"){
                HomeScreen(
                    state = state,
                    padding = padding,
                    onNextAlarm = { nav.navigate("next_alarm") },
                    onWarningSelected = { warning ->
                        when (warning.destination) {
                            WarningDestination.DOSE -> {
                                selectedDose = warning.dosePeriod ?: DosePeriod.MORNING
                                nav.navigate("dose_detail")
                            }
                            WarningDestination.MEDICATION -> nav.navigate("medication")
                            WarningDestination.WIFI -> nav.navigate("wifi_detail")
                            WarningDestination.DEVICE -> nav.navigate("device_detail")
                            WarningDestination.CARE -> nav.navigate("care")
                            WarningDestination.WARNINGS -> nav.navigate("warnings")
                        }
                    },
                    onDoseDetail = { selectedDose = it; nav.navigate("dose_detail") },
                    onSaveHealth = vm::saveHealth
                )
            }
            composable("next_alarm"){NextAlarmScreen(state,nav::popBackStack)}
            composable("warnings"){WarningScreen(state,nav::popBackStack)}
            composable("dose_detail"){DoseDetailScreen(state,selectedDose,nav::popBackStack)}
            composable("medication") {
                MedicationHubScreen(
                    state = state,
                    padding = padding,
                    onMedicationDetail = { nav.navigate("med_detail") },
                    onSideEffect = { nav.navigate("side_effect") },
                    onAiComment = { nav.navigate("ai_comment") },
                    onInventoryDetail = { nav.navigate("inventory_detail") },
                    onWithdraw = vm::withdrawMedication
                )
            }
            composable("inventory_detail") {
                InventoryDetailScreen(
                    state = state,
                    onBack = nav::popBackStack,
                    onAddStock = vm::addMedicationStock,
                    onEditMedication = { nav.navigate("medicine_edit") }
                )
            }
            composable("med_detail"){MedicationDetailScreen(state,nav::popBackStack){nav.navigate("medicine_edit")}}
            composable("medicine_edit"){MedicationEditScreen(state.medications.ifEmpty{listOf(state.medication)},nav::popBackStack,vm::saveMedications)}
            composable("side_effect"){SideEffectMemoScreen(state,nav::popBackStack,vm::saveSideEffect)}
            composable("ai_comment"){AiCommentScreen(state,nav::popBackStack,vm::refreshMedicine)}
            composable("care"){CareRecordScreen(state,padding,vm::saveCareMemo){nav.navigate("care_calendar")}}
            composable("care_calendar"){CareCalendarScreen(state,nav::popBackStack,vm::saveSideEffect,vm::saveCareMemo)}
            composable("more"){MoreScreen(state,padding,{nav.navigate("wifi_detail")},{nav.navigate("device_detail")},{nav.navigate("privacy")})}
            composable("wifi_detail"){WifiDetailScreen(state,nav::popBackStack){nav.navigate("wifi_reconnect")}}
            composable("wifi_reconnect"){WifiSetupScreen(state,nav::popBackStack,vm::registerDevice){nav.popBackStack("wifi_detail",false)}}
            composable("device_detail"){DeviceDetailScreen(state,nav::popBackStack)}
            composable("privacy"){PrivacyScreen(state,nav::popBackStack,{nav.navigate("profile_edit")},vm::logout)}
            composable("profile_edit"){PatientInfoScreen(state.profile,nav::popBackStack,vm::savePatientProfile)}
        }
    }
}
