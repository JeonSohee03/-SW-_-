package com.example.smartmedicationcare

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.smartmedicationcare.ui.AppRoot
import com.example.smartmedicationcare.ui.theme.SmartMedicationCareTheme
import com.example.smartmedicationcare.viewmodel.AppViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            SmartMedicationCareTheme {
                val vm: AppViewModel = viewModel(factory = AppViewModel.Factory())
                AppRoot(vm)
            }
        }
    }
}
