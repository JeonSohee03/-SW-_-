# ESP32 앱 연동 구현 요청

## Wi-Fi 설정

- AP SSID: `B-OMM`
- 보안: 오픈
- 설정 페이지: `GET http://192.168.4.1/`
- 사용자가 `B-OMM`에 연결하면 캡티브 포털을 통해 설정 페이지를 자동으로 연다.
- 자동 실행되지 않는 휴대폰을 위해 앱에서 `http://192.168.4.1/`을 직접 열 수 있다.
- 설정 페이지에서 주변 Wi-Fi 목록을 표시하고 사용자가 집 Wi-Fi를 선택하도록 한다.
- 집 Wi-Fi 비밀번호 입력과 저장은 앱이 아니라 ESP32 설정 페이지에서 처리한다.
- 설정 페이지는 Android 앱 내부 WebView에 표시된다.
- Wi-Fi 저장 성공 화면의 `앱으로 돌아가기` 버튼 URL은 `bomm://close`로 통일한다.

설정 페이지의 저장 동작:

1. 사용자가 주변 Wi-Fi 목록에서 집 Wi-Fi를 선택한다.
2. 집 Wi-Fi 비밀번호를 입력한다.
3. 기존 `/save` 처리에서 SSID와 비밀번호를 검증한다.
4. 정상 값이면 NVS에 저장한다.
5. 성공 안내 페이지를 응답한 뒤 ESP32를 재부팅한다.
6. ESP32는 AP 모드를 종료하고 저장된 집 Wi-Fi에 연결한다.
7. 집 Wi-Fi 연결 후 Firebase 인증 및 상태 업데이트를 시작한다.

성공 페이지에는 다음 버튼을 포함한다.

```html
<a href="bomm://close">
  <button type="button">앱으로 돌아가기</button>
</a>
```

Android WebView는 `bomm://close` 이동을 가로채 실제 페이지 이동을 막고, WebView를 닫은 뒤
앱의 Wi-Fi 설정 완료 상태를 표시한다. 따라서 성공한 경우에만 이 URL을 제공한다.

캡티브 포털 구현 시 DNS 요청을 `192.168.4.1`로 안내한다. 휴대폰에서 자동 로그인 화면이
열리지 않을 수 있으므로 `GET /` 직접 접속 방식은 반드시 유지한다.

Wi-Fi 비밀번호는 Firebase에 저장하거나 앱으로 다시 전송하지 않는다. B-OMM AP는 최초 설정,
Wi-Fi 재설정 또는 저장된 Wi-Fi 연결 실패 시에만 활성화하고 연결 성공 후 종료한다.

## 센서 명령

ESP32는 `devices/{deviceId}/setup/command`를 구독하고 새로운 `commandId`만 한 번 실행한다.

앱이 최초 설정 또는 재설정 명령을 보낼 때는 기존 완료값을 먼저 아래처럼 초기화한다.

```text
devices/{deviceId}/setup/result/setupComplete = false
devices/{deviceId}/setup/result/loadCell/success = false
devices/{deviceId}/setup/status/state = "PENDING"
```

ESP32는 새 `commandId`를 처리해 영점 측정과 NVS 저장까지 모두 성공한 뒤에만
`setup/result/setupComplete=true`를 기록한다. 앱은 이 값이 다시 `true`가 될 때까지
측정 버튼과 다음 버튼을 비활성화한다.

### 로드셀

`type = CALIBRATE_LOAD_CELL_ZERO`

1. 상태를 `LOAD_CELL / IN_PROGRESS`로 변경한다.
2. 모터 정지를 확인한다.
3. 빈 약통 상태에서 여러 원시값을 읽고 이상치를 제거한다.
4. 안정 범위 안이면 평균을 `zeroOffset`으로 NVS에 저장한다.
5. 성공 시 `LOAD_CELL / SUCCESS`, 실패 시 `FAILED`와 오류 코드를 기록한다.
6. `calibrationFactor`는 제작 단계 고정값이며 영점 설정으로 변경하지 않는다.
7. 성공 시 `setup/result/setupComplete=true`를 기록한다.

앱의 초기 설정에서는 초음파센서를 보정하지 않는다.

### 로드셀 성공 시 Firebase 기록

```text
devices/{deviceId}/setup/status/stage = "LOAD_CELL"
devices/{deviceId}/setup/status/state = "SUCCESS"
devices/{deviceId}/setup/status/progress = 100
devices/{deviceId}/setup/status/activeCommandId = 수신한 commandId
devices/{deviceId}/setup/result/loadCell/zeroOffset = 측정값
devices/{deviceId}/setup/result/loadCell/success = true
devices/{deviceId}/setup/result/setupComplete = true
```

## 앱에 보고할 예시

```json
{
  "stage": "LOAD_CELL",
  "state": "IN_PROGRESS",
  "message": "로드셀 영점을 측정하고 있습니다.",
  "progress": 25,
  "activeCommandId": "-commandKey",
  "errorCode": "",
  "updatedAt": 0
}
```

## 기간별 잔량과 외출용 배출 명령

ESP32는 아침·저녁 약의 남은 수량을 각각 기록한다.

```text
devices/{deviceId}/inventory/remainingDoseCountByPeriod/morning
devices/{deviceId}/inventory/remainingDoseCountByPeriod/evening
```

앱은 각 값을 최대 선택 일수로 사용한다. 외출용 약 배출 명령 형식은 다음과 같다.

```json
{
  "type": "WITHDRAW_MEDICATION",
  "morningDays": 3,
  "eveningDays": 2,
  "requestedDoseCount": 5,
  "status": "PENDING"
}
```

ESP32는 `morningDays`와 `eveningDays`를 구분해 배출하고, 완료된 배출량만 각 기간의
잔량에서 차감한 뒤 Firebase에 갱신한다. 요청값이 실제 잔량보다 크면 실행하지 않고
명령 상태를 `FAILED`로 기록한다.

## 인증

공개 데이터베이스 규칙을 사용하지 않는다. ESP32는 백엔드가 발급한 Firebase Custom Token으로 로그인하고 토큰에 `deviceId` 클레임을 포함해야 한다. 앱 사용자는 Firebase Authentication UID와 `ownerUid`가 일치할 때만 기기 데이터에 접근한다.
