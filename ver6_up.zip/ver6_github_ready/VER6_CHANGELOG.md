# ver6 주요 변경
1. 로드셀 초기 설정 및 중량 UI/모델 제거
2. 초기 온보딩: Wi-Fi/기기 연결 → 사용자 정보 → 약 정보 → 복용 시간
3. 하단 메뉴: 홈 / 약 / 케어 기록 / 더보기
4. 홈 첫 화면 상태 체크, 저장 후 오늘의 현황으로 통합
5. 다음 알림 직접 설정 제거, 서버/AI 계산 결과 표시 전용
6. 복약 상세의 반응 시간/배출 중량 제거, 서버 잔량 표시
7. 약 현황+약 정보 통합, 외출용 배출/잔량/약 상세/부작용/AI 코멘트 구성
8. 케어 기록: 상태 점수, 상태 메모, 캘린더 기록
9. 캘린더: 오늘 이동, 최근 30일 그래프, 복약/상태/프로그램/부작용/상태메모 상세
10. 기기 등록 메뉴를 기기 상태로 변경하고 센서별 상태 UI 제거

## 2026-09-01 Firebase live-data/Web sync update
- Android `FakeMedicationRepository` 삭제.
- `AppViewModel.Factory`는 항상 `FirebaseMedicationRepository`를 사용.
- 프로그램 점수/복약 시간/잔량/기기 상태/다음 알림은 Firebase 실데이터만 표시.
- 다음 알림은 ESP/AI가 `devices/{deviceId}/medicationSchedule/nextDoseAt`에 저장한 값만 사용하고 앱에서 임의 계산하지 않음.
- Web 앱을 Android와 동일한 `홈 / 약 / 케어 기록 / 더보기` 구조로 재작성.
- Web도 `users/{uid}` + `devices/{deviceId}`를 실시간 구독.
- Web 데모 모드 및 임의 점수/중량/복약 데이터 제거.
- `MedicationInfo.itemSeq` 추가. 값이 있으면 의약품관리종합정보포털 상세 페이지로, 없으면 약 이름 검색 결과로 이동.

## 2026-09-01 - Medication / AI consultation / warning UI update
- 약 화면 첫 문구를 배너 UI로 변경.
- inventory.remainingDays 기준 안정/권장/주의 상태 글자색 적용.
- `복용 코멘트 · API/AI`를 `복약 정보 & AI 상담`으로 변경.
- 의약품관리종합정보포털 공식 정보 버튼 유지(itemSeq 상세 / 약명 검색 fallback).
- AI 코멘트 요청 시 profile(age, heightCm, weightKg) + 선택 약 정보를 `medicineInsightRequests`에 함께 저장.
- `prompt`, `userContext`, `medicationContext` 추가. 서버/Gemini 처리 후 `medicineInsights/latest/comment`에 결과 저장하도록 사용.
- AI 상담 버튼은 동일한 개인화 프롬프트를 클립보드에 복사하고 Gemini 웹 채팅을 연다.
- 홈 주의 알림에 복약 미수거, 재고 상태, Wi-Fi, 기기 상태, 상태점수 50점 미만을 Firebase 실데이터로 계산해 표시.
- 웹앱에도 동일한 배너/상태색/AI 상담/주의 알림 규칙 반영.
