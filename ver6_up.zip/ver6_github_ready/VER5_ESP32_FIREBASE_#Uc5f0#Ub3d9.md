# Ver 5 ESP32/Firebase 연동 규격

## 1. 기기 Wi-Fi 등록

ESP32는 설정 전 `B-OMM` 오픈 AP와 `192.168.4.1` 웹 서버를 엽니다.
Android 앱은 집 Wi-Fi 정보를 직접 입력받거나 전송하지 않습니다. 앱은 사용자가 휴대폰의
Wi-Fi 설정에서 `B-OMM`을 선택하도록 안내하고 ESP32 설정 페이지를 엽니다.

```http
GET http://192.168.4.1/
```

사용자는 ESP32 설정 페이지에서 주변 Wi-Fi 목록 중 집 Wi-Fi를 선택하고 비밀번호를 입력합니다.
ESP32는 기존 `/save` 처리에서 정보를 NVS에 저장하고 성공 페이지를 표시한 뒤 재부팅합니다.
재부팅 후 저장된 집 Wi-Fi와 Firebase에 연결합니다.

ESP32는 가능하면 DNS 리디렉션 기반 캡티브 포털을 제공해 `B-OMM` 연결 직후 설정 페이지를
자동 표시할 수 있지만, B-OMM 앱은 일관된 초기 설정 흐름을 위해 앱 내부 WebView에서
`http://192.168.4.1/`을 직접 엽니다. 성공 페이지의 `앱으로 돌아가기` 버튼은
`bomm://close`를 사용하며 앱이 이 URL을 가로채 WebView를 닫습니다. Wi-Fi 비밀번호는
Firebase나 앱에 저장하지 않습니다.
현재 앱의 `usesCleartextTraffic=true`는 로컬 ESP32 설정 페이지 접속용 개발 설정입니다.

## 2. 약 꺼내기 명령

앱은 다음 경로에 명령을 추가합니다.

`devices/{deviceId}/commands/{commandId}`

```json
{
  "type": "WITHDRAW_MEDICATION",
  "requestedDoseCount": 3,
  "requestedAt": 1787270400000,
  "requestedByUid": "uid",
  "status": "PENDING"
}
```

ESP32는 PENDING 명령을 한 번만 처리하고 실제 로드셀 측정 후 같은 명령에
`status=COMPLETED`, `withdrawnWeightGram`, `remainingWeightGram`, `completedAt`을
기록합니다. 실패 시 `status=FAILED`, `errorMessage`를 기록합니다. 동시에 다음 값을
실측값으로 갱신합니다.

`devices/{deviceId}/inventory/currentWeightGram`

`devices/{deviceId}/inventory/estimatedRemainingDoseCount`

`devices/{deviceId}/inventory/estimatedRemainingDays`

앱은 명령을 생성할 뿐 잔량을 미리 차감하지 않습니다.

## 3. 복약 기록

`users/{uid}/doseRecords/{yyyy-MM-dd}/{morning|lunch|evening}` 아래에
`scheduledAt`, `programScore`, `reactionTimeMillis`, `buttonPressedAt`,
`dispenseDetected`, `dispensedAt`, `dispensedWeightGram`, `remainingWeightGram`,
`pouchPickedUpAt`, `estimatedTakenAt`, `status`를 저장합니다.

## 4. 기기 상태

ESP32는 연결 중 `devices/{deviceId}/network/lastSeenAt`을 주기적으로 서버 타임스탬프로
갱신하고 `status=ONLINE`을 기록합니다. OFFLINE 판정은 ESP32가 아니라 서버에서
`lastSeenAt` 만료를 기준으로 처리하는 것이 안전합니다.
