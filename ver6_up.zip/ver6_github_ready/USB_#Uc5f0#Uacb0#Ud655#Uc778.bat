@echo off
chcp 65001 > nul
setlocal
set "ADB=%LOCALAPPDATA%\Android\Sdk\platform-tools\adb.exe"

if not exist "%ADB%" (
  echo [오류] ADB를 찾을 수 없습니다.
  echo Android Studio에서 SDK Manager를 열고 Android SDK Platform-Tools를 설치하세요.
  pause
  exit /b 1
)

"%ADB%" kill-server > nul 2>&1
"%ADB%" start-server
 echo.
"%ADB%" devices
 echo.
echo device로 표시되면 USB 연결이 정상입니다.
echo unauthorized로 표시되면 휴대폰 화면에서 USB 디버깅을 허용하세요.
echo 아무 기기도 표시되지 않으면 데이터 케이블과 USB 드라이버를 확인하세요.
pause
