# ver6 build fix

2026-09-01 build log 기준 Kotlin/Compose 컴파일 오류 수정.

- DetailScreens.kt: BackScaffold의 @Composable 함수 타입 문법 수정
- MedicineScreens.kt: SelectionDropdown의 onSelected를 명명 인자로 전달하도록 수정
- MoreScreen.kt: Material3 ListItem 인자 순서를 명명 인자로 수정 및 caregiverPhoneNumber 사용 통일

이 실행 환경에서는 Gradle 9.3 배포본을 services.gradle.org에서 내려받을 수 없어 assembleDebug 재실행 검증은 수행하지 못함.
