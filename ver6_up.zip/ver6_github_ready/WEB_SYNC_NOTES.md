# ver6 Android/Web Firebase 동기화

- Android 앱의 Repository는 `FirebaseMedicationRepository`만 사용합니다. `FakeMedicationRepository`는 제거했습니다.
- ESP가 `devices/{deviceId}` 및 `users/{uid}/doseRecords`를 변경하면 Android와 Web이 Firebase 실시간 리스너로 즉시 갱신합니다.
- Web은 `users/{uid}`와 `devices/{deviceId}` 두 경로를 동시에 구독합니다.
- 프로그램 점수는 `users/{uid}/doseRecords/{date}/{morning|evening}/programScore`에서만 표시합니다.
- 다음 알림은 `devices/{deviceId}/medicationSchedule/nextDoseAt` 값만 표시하며 Web/Android가 임의로 계산하지 않습니다.
- 잔량은 `devices/{deviceId}/inventory`에서만 읽습니다.
- 기기 상태는 `devices/{deviceId}/deviceStatus`에서만 읽습니다.
- 의약품관리종합정보포털 링크:
  - `medications/{medicationId}/itemSeq`가 있으면 공식 상세 페이지로 바로 이동합니다.
  - 없으면 약 이름으로 공식 포털 검색 결과를 엽니다.

## Web Firebase 설정
`web/firebase-config.js`는 Firebase 콘솔 > 프로젝트 설정 > 내 앱 > 웹 앱에서 발급한 설정으로 교체해야 합니다.
