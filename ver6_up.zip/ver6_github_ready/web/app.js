import { firebaseConfig } from './firebase-config.js';

const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
const todayKey=()=>new Date().toLocaleDateString('sv-SE');
const fmtTime=v=>{if(!v)return '—';const n=Number(v);if(!Number.isFinite(n))return '—';return new Date(n).toLocaleTimeString('ko-KR',{hour:'2-digit',minute:'2-digit'});};
const values=o=>o&&typeof o==='object'?Object.entries(o).map(([id,v])=>({...v,id:v?.id||id})):[];
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const configured=()=>firebaseConfig.apiKey&&!firebaseConfig.apiKey.includes('PASTE_')&&firebaseConfig.projectId&&!firebaseConfig.projectId.includes('PASTE_');
let fb=null,userData={},deviceData={},uid=null,deviceId='',unsubUser=null,unsubDevice=null,metric='dose',alertIndex=0;

async function firebase(){
  if(fb)return fb;
  const [app,auth,db]=await Promise.all([
    import('https://www.gstatic.com/firebasejs/10.14.1/firebase-app.js'),
    import('https://www.gstatic.com/firebasejs/10.14.1/firebase-auth.js'),
    import('https://www.gstatic.com/firebasejs/10.14.1/firebase-database.js')
  ]);
  const instance=app.initializeApp(firebaseConfig);
  fb={...auth,...db,auth:auth.getAuth(instance),db:db.getDatabase(instance)};
  return fb;
}

function doseRecords(){
  const out=[];
  const root=userData.doseRecords||{};
  Object.entries(root).forEach(([date,slots])=>Object.entries(slots||{}).forEach(([slot,r])=>out.push({date,period:slot.toUpperCase(),...r})));
  return out;
}
function meds(){return values(userData.medications).filter(m=>m.name);}
function todayRecords(){return doseRecords().filter(r=>r.date===todayKey());}
function health(date=todayKey()){return userData.healthHistory?.[date]||null;}
function side(date){return userData.sideEffectHistory?.[date]||null;}
function care(date=todayKey()){return userData.careMemos?.[date]||null;}
function takenAt(r){return r?.estimatedTakenAt||r?.pouchPickedUpAt||null;}
function statusKo(s){return ({SCHEDULED:'복용 예정',DISPENSED:'배출 완료',TAKEN:'복용 완료',MISSED:'미복용'})[s]||s||'기록 없음';}
function warningItems(){
  const out=[],now=Date.now(),rec=todayRecords();
  rec.filter(r=>r.dispensedAt&&!takenAt(r)&&r.status!=='TAKEN').forEach(r=>{
    const elapsed=now-Number(r.dispensedAt);
    if(elapsed>=0&&elapsed<2*60*60*1000)out.push({level:'warn',target:'dose',period:r.period,title:`${r.period==='MORNING'?'아침':'저녁'} 약을 아직 복용하지 않으셨어요`,message:'약이 배출되었지만 아직 수거 기록이 없습니다. 배출 후 2시간 이내 복용 여부를 확인해 주세요.'});
    else if(elapsed>=2*60*60*1000)out.push({level:'critical',target:'dose',period:r.period,title:`${r.period==='MORNING'?'아침':'저녁'} 약 복용 확인이 필요해요`,message:'약이 배출된 지 2시간 이상 지났지만 수거 기록이 없습니다. 약 봉투와 복용 여부를 확인해 주세요.'});
  });
  const inv=deviceData.inventory||{},hasInv=Object.keys(inv).length>0,rd=Number(inv.remainingDays);
  if(hasInv&&Number.isFinite(rd)){
    if(rd<=3)out.push({level:'critical',target:'medication',title:'약 보관 현황 · 주의',message:`남은 약이 약 ${Math.max(0,Math.floor(rd))}일분입니다. 약을 미리 준비해 주세요.`});
    else if(rd<=7)out.push({level:'warn',target:'medication',title:'약 보관 현황 · 확인 필요',message:`남은 약이 약 ${Math.floor(rd)}일분입니다. 다음 약 준비 일정을 확인해 주세요.`});
    else out.push({level:'info',target:'medication',title:'약 보관 현황 · 안정',message:`현재 약은 약 ${Math.floor(rd)}일분 남아 있습니다.`});
  }
  const network=String(deviceData.network?.status||'').toUpperCase();
  if(network&&!["ONLINE","UNREGISTERED","UNKNOWN"].includes(network))out.push({level:'critical',target:'wifi',title:'Wi‑Fi 연결을 확인해 주세요',message:`B-OMM 기기의 네트워크 상태가 ${deviceData.network?.status}입니다. Wi‑Fi 연결을 확인해 주세요.`});
  const rawStatus=typeof deviceData.deviceStatus==='string'?deviceData.deviceStatus:deviceData.deviceStatus?.status;
  const ds=String(rawStatus||'').trim(),normal=['정상','NORMAL','OK'].includes(ds.toUpperCase()==='정상'?'정상':ds.toUpperCase()),unknown=!ds||['데이터 없음','확인 중'].includes(ds);
  if(ds&&!normal&&!unknown)out.push({level:'critical',target:'device',title:'기기 상태를 확인해 주세요',message:`현재 기기 상태가 '${ds}'로 전달되었습니다. 기기를 확인해 주세요.`});
  const h=health();if(h&&Number(h.totalScore)<50)out.push({level:'warn',target:'care',title:'오늘 상태 점수가 낮아요',message:`오늘 상태 점수는 ${h.totalScore}점입니다. 평소와 다른 상태가 지속되면 보호자나 의료진에게 연락해 상태를 확인해 주세요.`});
  values(userData.alerts).forEach(a=>out.push({level:a.critical?'critical':'warn',target:'home',title:a.title||'기기 알림',message:a.message||''}));
  return out.filter((x,i,a)=>a.findIndex(y=>y.title===x.title&&y.message===x.message)===i);
}
function aiPrompt(m){
  const p=userData.profile||{};if(!m)return '';
  return `다음 사용자 정보와 복용 약 정보를 바탕으로 복약 시 주의할 점, 생활 속 예방법, 확인하면 좋은 이상 증상을 이해하기 쉽게 설명해줘.\n의학적 진단을 단정하지 말고, 필요한 경우 의료진 상담이 필요한 상황도 구분해서 알려줘.\n\n[사용자 정보]\n나이: ${p.age??'미입력'}세\n키: ${p.heightCm??'미입력'}cm\n체중: ${p.weightKg??'미입력'}kg\n\n[복용 약]\n약품명: ${m.name}\n1회 복용량: ${m.doseAmount||'미입력'}\n하루 복용 횟수: ${m.timesPerDay??'미입력'}회\n복용 간격: ${m.intervalHours??'미입력'}시간${m.cautionText?`\n기존 주의 정보: ${m.cautionText}`:''}\n\n이 내용을 바탕으로 나와 계속 대화하면서 궁금한 점에 답해줘.`;
}

function bindDevice(id){
  if(unsubDevice){unsubDevice();unsubDevice=null;}
  deviceData={};deviceId=id||'';
  if(!deviceId){render();return;}
  unsubDevice=fb.onValue(fb.ref(fb.db,`devices/${deviceId}`),snap=>{deviceData=snap.val()||{};render();});
}
function bindUser(id){
  if(unsubUser)unsubUser();uid=id;
  unsubUser=fb.onValue(fb.ref(fb.db,`users/${uid}`),snap=>{
    userData=snap.val()||{};
    const next=userData.profile?.deviceId||'';
    if(next!==deviceId)bindDevice(next); else render();
  });
}

function render(){
  $('#auth').classList.add('hidden');$('#app').classList.remove('hidden');
  $('#syncBadge').textContent=deviceId?'Firebase 실시간 연결':'기기 미등록';
  $('#dateLabel').textContent=new Date().toLocaleDateString('ko-KR',{year:'numeric',month:'long',day:'numeric',weekday:'short'});
  renderHome();renderMedication();renderCare();renderMore();
}
function renderHome(){
  const h=health();
  $('#healthCheckCard').classList.toggle('hidden',!!h);
  $('#todayHealthScore').textContent=h?`${h.totalScore??'—'}점`:'기록 없음';
  const rec=todayRecords();
  $('#todayDoseRows').innerHTML=['MORNING','EVENING'].map(p=>{
    const r=rec.find(x=>x.period===p);return `<div class="row"><div class="row-title">${p==='MORNING'?'아침':'저녁'}</div><div class="row-sub">배출 ${fmtTime(r?.dispensedAt)} · 복용 ${fmtTime(takenAt(r))}</div><span class="status ${r?.status==='MISSED'?'warn':''}">${statusKo(r?.status)}</span></div>`;
  }).join('');
  $('#nextDose').textContent=fmtTime(deviceData.medicationSchedule?.nextDoseAt);
  const alerts=warningItems().slice(0,5);
  if(alertIndex>=alerts.length)alertIndex=0;
  if(!alerts.length){
    $('#alerts').innerHTML='<section class="warning-carousel empty"><div class="warning-body"><div class="alert-title">현재 주의 알림이 없습니다.</div></div></section>';
  }else{
    const a=alerts[alertIndex];
    const dots=alerts.map((_,i)=>`<button class="warning-dot ${i===alertIndex?'active':''}" data-alert-dot="${i}" aria-label="${i+1}번째 알림"></button>`).join('');
    $('#alerts').innerHTML=`<section class="warning-carousel ${a.level}" data-alert-open="1"><div class="warning-body"><div class="alert-title">${esc(a.title)}</div><div class="warning-message">${esc(a.message)}</div><div class="warning-link">눌러서 관련 화면으로 이동</div></div><div class="warning-controls"><button class="warning-arrow" data-alert-prev="1">‹</button><div class="warning-dots">${dots}</div><button class="warning-arrow" data-alert-next="1">›</button></div></section>`;
    const card=$('[data-alert-open]');
    card.onclick=e=>{if(e.target.closest('.warning-controls'))return;navigateWarning(a)};
    $('[data-alert-prev]').onclick=e=>{e.stopPropagation();alertIndex=(alertIndex-1+alerts.length)%alerts.length;renderHome()};
    $('[data-alert-next]').onclick=e=>{e.stopPropagation();alertIndex=(alertIndex+1)%alerts.length;renderHome()};
    $$('[data-alert-dot]').forEach(b=>b.onclick=e=>{e.stopPropagation();alertIndex=Number(b.dataset.alertDot);renderHome()});
  }
}
function renderMedication(){
  const ms=meds();
  const starts=ms.map(m=>new Date(m.startDate)).filter(d=>!Number.isNaN(d.getTime()));
  if(starts.length){const start=new Date(Math.min(...starts));const days=Math.floor((new Date(todayKey())-start)/86400000)+1;$('#medDayText').textContent=`복용을 시작한 지 ${Math.max(1,days)}일째예요. 오늘 몸 상태나 신체 변화도 함께 살펴보세요.`}else $('#medDayText').textContent='복용 중인 약 정보를 확인해 보세요.';
  const inv=deviceData.inventory||{}, by=inv.remainingDoseCountByPeriod||{};
  const hasInv=Object.keys(inv).length>0;
  const rd=Number(inv.remainingDays);
  $('#stockLevel').textContent=!hasInv?'데이터 없음':rd<=3?'주의 단계':rd<=7?'권장 단계':'안정 단계';
  $('#stockLevel').className='score-big stock-level '+(!hasInv?'':rd<=3?'danger':rd<=7?'warn':'stable');
  $('#remainingTotal').textContent=hasInv?`${inv.remainingDoseCount??'—'}회분`:'—';
  $('#remainingMorning').textContent=hasInv?`${by.morning??'—'}일분`:'—';
  $('#remainingEvening').textContent=hasInv?`${by.evening??'—'}일분`:'—';
  $('#withdrawMorning').max=by.morning??0;$('#withdrawEvening').max=by.evening??0;
  $('#medicineList').innerHTML=ms.length?ms.map(m=>`<div class="medicine"><div class="medicine-head"><b>${esc(m.name)}</b><span class="status">복용 중</span></div><div class="row-sub">1회 ${esc(m.doseAmount||'—')} · 하루 ${m.timesPerDay??'—'}회 · ${m.intervalHours??'—'}시간 간격</div></div>`).join(''):'<p class="help">등록된 약 정보가 없습니다.</p>';
  const selected=$('#apiMedicine').value;
  $('#apiMedicine').innerHTML=ms.map(m=>`<option value="${esc(m.id)}">${esc(m.name)}</option>`).join('');
  if(ms.some(m=>m.id===selected))$('#apiMedicine').value=selected;
  renderApi();
  const d=$('#sideDate').value||todayKey();$('#sideDate').value=d;$('#sideMemo').value=side(d)?.memo||'';
  const profile=userData.profile||{};
  $('#aiProfileContext').textContent=`${profile.age??'—'}세 · ${profile.heightCm??'—'}cm · ${profile.weightKg??'—'}kg 사용자 정보와 선택한 약 정보를 기반으로 제공합니다.`;
  $('#aiComment').textContent=userData.medicineInsights?.latest?.comment||'아직 생성된 AI 코멘트가 없습니다. 아래 버튼을 눌러 맞춤 코멘트를 요청해 주세요.';
}
function renderApi(){
  const m=meds().find(x=>x.id===$('#apiMedicine').value)||meds()[0];
  if(!m){$('#apiInfo').textContent='등록된 약이 없습니다.';return;}
  $('#apiInfo').textContent=`약품명: ${m.name}\n1회 투약량: ${m.doseAmount||'—'}\n복용 간격: ${m.intervalHours??'—'}시간\n하루 복용: ${m.timesPerDay??'—'}회${m.cautionText?'\n\n'+m.cautionText:''}`;
}
function renderCare(){
  const h=health();$('#careScore').textContent=h?`${h.totalScore??'—'}점`:'기록 없음';$('#careMemo').value=care()?.memo||'';
  const date=$('#calendarDate').value||todayKey();$('#calendarDate').value=date;renderCalendarDetail(date);drawGraph();
}
function renderCalendarDetail(date){
  const rs=doseRecords().filter(r=>r.date===date),h=health(date),s=side(date),c=care(date);
  if(metric==='dose'){
    $('#calendarDetail').innerHTML=['MORNING','EVENING'].map(p=>{const r=rs.find(x=>x.period===p);return `<div class="row"><b>${p==='MORNING'?'아침':'저녁'}</b><div class="row-sub">배출 시간 ${fmtTime(r?.dispensedAt)}<br>복용 시간 ${fmtTime(takenAt(r))}</div></div>`}).join('')+'<p class="help">복용 시간은 초음파 센서가 약 봉투 수거를 감지한 서버 기록을 기준으로 산정합니다.</p>';
  } else if(metric==='health') $('#calendarDetail').innerHTML=`<div class="score-big">${h?`${h.totalScore??'—'}점`:'기록 없음'}</div>`;
  else if(metric==='program'){const v=rs.map(r=>Number(r.programScore)).filter(Number.isFinite);$('#calendarDetail').innerHTML=`<div class="score-big">${v.length?`${Math.round(v.reduce((a,b)=>a+b,0)/v.length)}점`:'기록 없음'}</div>`;}
  else if(metric==='side') $('#calendarDetail').innerHTML=`<p>${esc(s?.memo||'작성된 메모가 없습니다.')}</p>`;
  else $('#calendarDetail').innerHTML=`<p>${esc(c?.memo||'작성된 메모가 없습니다.')}</p>`;
}
function renderMore(){
  $('#networkStatus').textContent=deviceData.network?.status||'데이터 없음';$('#deviceId').textContent=deviceId||'기기 미등록';
  const ds=typeof deviceData.deviceStatus==='string'?deviceData.deviceStatus:deviceData.deviceStatus?.status;
  $('#deviceStatus').textContent=ds||'데이터 없음';
}

function activateTab(tab){
  $$('.tab').forEach(x=>x.classList.toggle('active',x.dataset.tab===tab));
  $$('.screen').forEach(x=>x.classList.toggle('active',x.id===`screen-${tab}`));
  $('#screenTitle').textContent={home:'홈',medication:'약',care:'케어 기록',more:'더보기'}[tab]||'B-OMM';
}
function navigateWarning(a){
  let tab='home',selector=null;
  if(a.target==='medication'){tab='medication';selector='#stockCard'}
  else if(a.target==='wifi'){tab='more';selector='#wifiCard'}
  else if(a.target==='device'){tab='more';selector='#deviceCard'}
  else if(a.target==='care'){tab='care';selector='#careScoreCard'}
  else if(a.target==='dose'){tab='home';selector='#todayDoseRows'}
  activateTab(tab);
  requestAnimationFrame(()=>{if(selector)$(selector)?.scrollIntoView({behavior:'smooth',block:'center'})});
}

function drawGraph(){
  const canvas=$('#monthGraph'),ctx=canvas.getContext('2d'),w=canvas.width,h=canvas.height;ctx.clearRect(0,0,w,h);ctx.strokeStyle='#e3e7ec';for(let i=0;i<5;i++){const y=20+(h-40)*i/4;ctx.beginPath();ctx.moveTo(30,y);ctx.lineTo(w-15,y);ctx.stroke()}
  const dates=[...Array(30)].map((_,i)=>{const d=new Date();d.setDate(d.getDate()-(29-i));return d.toLocaleDateString('sv-SE')});
  const series=[
    dates.map(d=>health(d)?.totalScore??null),
    dates.map(d=>{const v=doseRecords().filter(r=>r.date===d).map(r=>Number(r.programScore)).filter(Number.isFinite);return v.length?v.reduce((a,b)=>a+b,0)/v.length:null}),
    dates.map(d=>{const r=doseRecords().filter(x=>x.date===d);return r.length?r.filter(x=>x.status==='TAKEN').length/r.length*100:null})
  ];
  ['#1677ff','#f59e0b','#2eaf62'].forEach((color,si)=>{ctx.strokeStyle=color;ctx.lineWidth=3;ctx.beginPath();let started=false;series[si].forEach((v,i)=>{if(v==null)return;const x=30+i*(w-45)/29,y=h-20-Math.max(0,Math.min(100,v))*(h-40)/100;if(!started){ctx.moveTo(x,y);started=true}else ctx.lineTo(x,y)});ctx.stroke()});
}

async function writeUser(path,value){await fb.set(fb.ref(fb.db,`users/${uid}/${path}`),value)}
async function pushDevice(path,value){if(!deviceId)throw new Error('기기를 먼저 등록하세요.');return fb.push(fb.ref(fb.db,`devices/${deviceId}/${path}`),value)}

const checkDefs=[['meal','식사'],['sleep','수면'],['activity','활동'],['mood','기분']];
$('#healthChecks').innerHTML=checkDefs.map(([k,l])=>`<label class="check-item">${l}<select data-health="${k}"><option value="1">매우 나쁨</option><option value="2">나쁨</option><option value="3" selected>보통</option><option value="4">좋음</option><option value="5">매우 좋음</option></select></label>`).join('');
$('#saveHealth').onclick=async()=>{const obj={date:todayKey(),updatedAtMillis:Date.now()};let sum=0;$$('[data-health]').forEach(x=>{obj[x.dataset.health]=Number(x.value);sum+=Number(x.value)});obj.totalScore=Math.round(sum/20*100);obj.memo='';await writeUser(`healthHistory/${todayKey()}`,obj)};
$('#withdraw').onclick=async()=>{try{const morning=Number($('#withdrawMorning').value)||0,evening=Number($('#withdrawEvening').value)||0;if(morning+evening<=0)throw new Error('1일분 이상 선택하세요.');await pushDevice('commands',{type:'WITHDRAW_MEDICATION',morningDays:morning,eveningDays:evening,requestedDoseCount:morning+evening,status:'PENDING',requestedAt:Date.now(),requestedByUid:uid});$('#withdrawMsg').textContent='배출 요청을 전송했습니다.'}catch(e){$('#withdrawMsg').textContent=e.message}};
$('#sideDate').onchange=()=>{$('#sideMemo').value=side($('#sideDate').value)?.memo||''};
$('#saveSide').onclick=async()=>{const date=$('#sideDate').value||todayKey();await writeUser(`sideEffectHistory/${date}`,{date,memo:$('#sideMemo').value,updatedAtMillis:Date.now()})};
$('#saveCare').onclick=async()=>{const date=todayKey();await writeUser(`careMemos/${date}`,{date,memo:$('#careMemo').value,updatedAtMillis:Date.now()})};
$('#apiMedicine').onchange=renderApi;
$('#openDrugPortal').onclick=()=>{const m=meds().find(x=>x.id===$('#apiMedicine').value)||meds()[0];if(!m)return;const url=m.itemSeq?`https://nedrug.mfds.go.kr/pbp/CCBBB01/getItemDetail?itemSeq=${encodeURIComponent(m.itemSeq)}`:`https://nedrug.mfds.go.kr/searchDrug?itemName=${encodeURIComponent(m.name)}`;window.open(url,'_blank','noopener')};
$('#requestAi').onclick=async()=>{const m=meds().find(x=>x.id===$('#apiMedicine').value)||meds()[0];if(!m)return;const p=userData.profile||{};await fb.push(fb.ref(fb.db,`users/${uid}/medicineInsightRequests`),{medicationId:m.id,medicineName:m.name,medicineNames:[m.name],source:'MFDS_DRUG_PRODUCT_API+GEMINI',status:'PENDING',requestedAt:Date.now(),userContext:{age:p.age??0,heightCm:p.heightCm??0,weightKg:p.weightKg??0},medicationContext:{name:m.name,doseAmount:m.doseAmount||'',timesPerDay:m.timesPerDay??0,intervalHours:m.intervalHours??0,itemSeq:m.itemSeq||'',cautionText:m.cautionText||''},prompt:aiPrompt(m)})};
$('#openGemini').onclick=async()=>{const m=meds().find(x=>x.id===$('#apiMedicine').value)||meds()[0];if(!m)return;const prompt=aiPrompt(m);try{await navigator.clipboard.writeText(prompt);$('#geminiHelp').textContent='맞춤 상담 프롬프트를 복사했습니다. Gemini에서 붙여넣어 대화를 시작하세요.';}catch(e){$('#geminiHelp').textContent='프롬프트 자동 복사에 실패했습니다. 브라우저의 클립보드 권한을 확인해 주세요.';}window.open('https://gemini.google.com/app','_blank','noopener')};
$('#calendarDate').onchange=()=>renderCalendarDetail($('#calendarDate').value);$('#todayBtn').onclick=()=>{$('#calendarDate').value=todayKey();renderCalendarDetail(todayKey())};
$$('.metric-tab').forEach(b=>b.onclick=()=>{$$('.metric-tab').forEach(x=>x.classList.remove('active'));b.classList.add('active');metric=b.dataset.metric;renderCalendarDetail($('#calendarDate').value)});
$('#graphToggle').onclick=()=>{$('#graphWrap').classList.toggle('hidden');drawGraph()};
$$('.tab').forEach(b=>b.onclick=()=>activateTab(b.dataset.tab));

$('#login').onclick=async()=>{const err=$('#auth-error');err.textContent='';if(!configured()){err.textContent='firebase-config.js에 웹 Firebase 설정값을 입력하세요.';return}try{const f=await firebase();const result=await f.signInWithEmailAndPassword(f.auth,$('#email').value,$('#password').value);bindUser(result.user.uid)}catch(e){err.textContent='로그인에 실패했습니다. 계정 또는 Firebase 설정을 확인하세요.'}};
$('#logout').onclick=async()=>{if(unsubUser)unsubUser();if(unsubDevice)unsubDevice();await fb.signOut(fb.auth);location.reload()};

$('#sideDate').value=todayKey();$('#calendarDate').value=todayKey();
if(configured())firebase().then(f=>f.onAuthStateChanged(f.auth,u=>{if(u)bindUser(u.uid)}));
if('serviceWorker'in navigator)navigator.serviceWorker.register('./sw.js');
