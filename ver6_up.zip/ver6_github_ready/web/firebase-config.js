// Firebase 콘솔 > 프로젝트 설정 > 내 앱 > 웹 앱에서 받은 값을 붙여 넣으세요.
// apiKey는 사용자를 식별하는 비밀번호가 아니며, 실제 접근 권한은
// Firebase Authentication과 Realtime Database Rules로 제한합니다.
export const firebaseConfig = {
  apiKey: "PASTE_YOUR_API_KEY",
  authDomain: "PASTE_YOUR_PROJECT.firebaseapp.com",
  databaseURL: "https://PASTE_YOUR_PROJECT-default-rtdb.asia-southeast1.firebasedatabase.app",
  projectId: "PASTE_YOUR_PROJECT",
  appId: "PASTE_YOUR_APP_ID"
};
