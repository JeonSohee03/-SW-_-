# Warning banner update

- Home warning notifications changed to a large single-card carousel.
- Supports previous/next arrows and dynamic page dots (up to 5 alerts).
- Tapping a banner routes to the related screen:
  - dose alert -> dose detail
  - inventory -> medication
  - Wi-Fi -> Wi-Fi detail
  - device error -> device status
  - low health score -> care record
- Web app uses the same warning carousel and scrolls to the related section.
