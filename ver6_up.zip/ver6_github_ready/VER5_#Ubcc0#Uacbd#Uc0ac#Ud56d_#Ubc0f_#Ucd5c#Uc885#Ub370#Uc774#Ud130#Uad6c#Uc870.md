# B-OMM v5 변경사항 및 최종 데이터 구조

## 사용자 화면 흐름

```mermaid
flowchart TD
    A[동의 화면] --> B[로그인]
    B --> C{기존 계정?}
    C -->|기기 연결됨| H[메인 화면]
    C -->|신규 계정| D[Wi-Fi 설정]
    D --> E[로드셀 영점 설정]
    E --> G[복용자 정보 → 약 정보 → 복용 시간]
    G --> H
```

회원가입 성공 후에는 자동 로그인하지 않고 로그인 화면으로 돌아간다.

## 앱과 ESP32의 역할

- 앱은 센서 설정 명령만 Firebase에 기록한다.
- ESP32는 명령을 읽고 실제 측정·NVS 저장을 수행한다.
- ESP32는 진행 상태와 성공/실패 결과를 Firebase에 기록한다.
- Wi-Fi 비밀번호는 Firebase에 저장하지 않는다.
- 사용자 보호자 연락처는 ESP32에 보내지 않는다. ESP32에 필요한 나이·성별·신장·체중과 복약 설정만 동기화한다.
- 사용자는 생년월일을 입력하고 앱은 만 나이를 계산한다. `dateOfBirth`와 계산된 `age`를 함께 저장한다.
- 외출용 배출 잔량은 `inventory/remainingDoseCountByPeriod/morning`, `evening`으로 구분한다.
- 의약품 API 요청은 사용자가 선택한 `medicationId`와 `medicineName` 한 건을 대상으로 한다.

## 최종 Realtime Database 구조

```text
users/{uid}
├─ profile
│  ├─ email
│  ├─ age
│  ├─ gender
│  ├─ heightCm
│  ├─ weightKg
│  ├─ caregiverPhoneNumber
│  └─ deviceId
├─ onboarding
│  ├─ profileComplete
│  ├─ medicationComplete
│  └─ scheduleComplete
├─ medications/{medicationId}
│  ├─ name
│  ├─ strengthValue
│  ├─ strengthUnit
│  ├─ dosageValue
│  ├─ dosageUnit
│  ├─ timesPerDay
│  └─ totalDays
├─ schedule
│  ├─ intervalHours
│  ├─ morningTime
│  ├─ eveningTime
│  └─ updatedAt
├─ medicineInsightRequests/{requestId}
│  ├─ medicineNames
│  ├─ source
│  ├─ status
│  └─ requestedAt
├─ medicineInsights/latest
│  └─ comment
├─ doseRecords/{date}/{period}
├─ healthHistory/{date}
├─ sideEffectHistory/{date}
├─ nextAlarmMillis
└─ setupComplete

devices/{deviceId}
├─ ownerUid
├─ network
│  ├─ status
│  └─ updatedAt
├─ setup
│  ├─ command
│  │  ├─ commandId
│  │  ├─ type
│  │  ├─ requestedAt
│  │  └─ requestedByUid
│  ├─ status
│  │  ├─ stage
│  │  ├─ state
│  │  ├─ message
│  │  ├─ progress
│  │  ├─ activeCommandId
│  │  └─ errorCode
│  └─ result
│     ├─ loadCell
│     ├─ ultrasonic
│     └─ setupComplete
├─ settings
│  ├─ patient
│  ├─ medications
│  ├─ schedule
│  └─ nextAlarmMillis
├─ status/sensors
│  ├─ loadCell
│  ├─ ultrasonic
│  ├─ infrared
│  ├─ switch
│  ├─ servo
│  └─ microphone
├─ inventory
└─ commands/{commandId}
```

## 상태값

- 초기 설정 센서 단계: `IDLE`, `LOAD_CELL`, `COMPLETE`
- 실행 상태: `PENDING`, `IN_PROGRESS`, `SUCCESS`, `FAILED`, `TIMEOUT`
- 센서 건강 상태: `NORMAL`, `CHECK_REQUIRED`, `ERROR`, `UNKNOWN`

## 의약품 API/AI 처리

앱은 사용자가 드롭다운에서 선택한 약 한 건의 `medicationId`, `medicineName`으로
`medicineInsightRequests`를 생성한다. 공공데이터 서비스 키와 AI 키를 APK에 포함하면
추출될 수 있으므로, 실제 API 호출과 AI 요약은 Cloud Functions 또는 별도 서버에서 처리한다.
서버는 선택한 약을 식약처 의약품 제품 허가정보 API에서 검색한 뒤 결과를 저장한다.

앱에는 등록한 약 이름을 의약품안전나라 검색 조건으로 전달하는 버튼도 포함했다.

## 기존 계정 호환

기존 v5 사용자의 `onboarding` 값이 없더라도 기존 프로필·약·알림 데이터가 있으면 완료된 단계로 간주한다. 기존에 연결된 기기는 새 센서 완료 필드가 없어도 메인 화면을 유지하며, 더보기의 기기 재등록에서 센서 설정을 다시 실행할 수 있다.
