# ver6 약 입출고/초기설정/주의알림 업데이트

## 추가/변경 사항
- 외출용 약 배출 요청 전 최종 확인 다이얼로그 추가
- 현재 약 보관 현황 카드 탭 시 상세 화면 이동
- 보관 현황 상세에서 동일 약 여부 확인 후 1~90일분 추가 가능
- 다른 약이면 약 정보 변경 화면으로 안내
- 약 추가 시 devices/{deviceId}/inventory 실시간 갱신 및 MEDICATION_REFILL event 기록
- 초기 설정 성별을 SelectionDropdown으로 변경
- 초기 복용 시간 및 최소 간격을 SelectionDropdown으로 변경
- 초기 설정에서 실제 기기에 투입한 약 일수(1~90일분) 별도 입력
- 초기 inventory는 처방 총 일수가 아니라 실제 투입 일수로 생성
- devices/{deviceId}/alerts를 Android 앱이 실시간으로 읽도록 추가
- 홈 주의 알림 조건: 1시간 미복용, 2시간 미복용, Wi-Fi 끊김, 기기 이상, 응급 상황
