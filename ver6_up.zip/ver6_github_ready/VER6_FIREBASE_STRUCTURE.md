# B-OMM ver6 Firebase 구조

## ESP32가 주로 쓰고 앱이 읽는 경로
- `devices/{deviceId}/network`: `status`, `lastSeenAt`, `updatedAt`
- `devices/{deviceId}/sensors/ultrasonic`: 초음파 상태/감지 값
- `devices/{deviceId}/events/{eventId}`: 기기 이벤트
- `devices/{deviceId}/scores/{scoreId}`: 프로그램 점수
- `devices/{deviceId}/componentErrors`: 기기 오류
- `devices/{deviceId}/commands/{commandId}`: 외출용 약 원격 배출 명령 및 완료 상태
- `devices/{deviceId}/medicationSchedule`: `morningTime`, `dinnerTime`, `intervalHours`, `nextDoseAt`, `updatedAt`
- `devices/{deviceId}/deviceStatus`: ESP32가 최종 판정한 `정상/비정상` 상태. 문자열 또는 `deviceStatus/status` 형태 모두 앱이 읽음.
- `users/{uid}/doseRecords/{yyyy-MM-dd}/{morning|evening}`: `scheduledAt`, `programScore`, `dispensedAt`, `pouchPickedUpAt`, `estimatedTakenAt`, `status`, `dispenseDetected`
- `users/{uid}/alerts/{alertId}`: 사용자 알림

## ver6에서 추가/정리한 잔량 구조
로드셀 중량을 사용하지 않습니다.
- `devices/{deviceId}/inventory/initialDays`: 초기 입력 복용 일수
- `devices/{deviceId}/inventory/remainingDays`: ESP32가 계산한 남은 일수
- `devices/{deviceId}/inventory/remainingDoseCount`: 남은 총 회분
- `devices/{deviceId}/inventory/remainingDoseCountByPeriod/morning`: 아침 잔량(일분)
- `devices/{deviceId}/inventory/remainingDoseCountByPeriod/evening`: 저녁 잔량(일분)
- `devices/{deviceId}/inventory/updatedAt`: 마지막 갱신 시각

초기 약 정보 저장 시 앱이 초기 값을 Firebase에 기록하고, 이후 ESP32가 실제 배출/외출용 배출 시 차감한 값을 갱신하는 구조입니다.

## 앱이 쓰고 다시 읽는 사용자 기록
- `users/{uid}/profile`
- `users/{uid}/medications/{medicationId}`
- `users/{uid}/schedule`
- `users/{uid}/healthHistory/{yyyy-MM-dd}`: 홈 상태 체크 및 상태 점수
- `users/{uid}/sideEffectHistory/{yyyy-MM-dd}`: 부작용 메모
- `users/{uid}/careMemos/{yyyy-MM-dd}`: 케어 기록의 상태 메모
- `users/{uid}/medicineInsightRequests/{requestId}`: API/AI 코멘트 생성 요청
- `users/{uid}/medicineInsights/latest/comment`: 생성된 AI 코멘트

## 복용 시간 설정
앱 초기 설정에서 `intervalHours`, `morningTime`, `eveningTime`을 저장하며 동시에 `devices/{deviceId}/medicationSchedule`에 전달합니다.
저녁 시간은 아침 시간에서 최소 `intervalHours` 이상 떨어져 있어야 저장할 수 있습니다.
ESP32/AI가 아침 실제 복용 시간을 기준으로 저녁 시간을 조정하면 `dinnerTime` 또는 `nextDoseAt`을 갱신하고 앱은 실시간으로 해당 값을 반영합니다.

### 의약품 공식 포털 연결용 필드
`users/{uid}/medications/{medicationId}/itemSeq`
- 식품의약품안전처 품목기준코드.
- API 조회 결과에서 ITEM_SEQ를 받으면 저장하는 것을 권장.
- Android/Web의 "선택한 약 공식 정보 보기"가 이 값이 있으면 의약품관리종합정보포털 상세 페이지로 바로 이동.
- itemSeq가 없으면 약품명으로 공식 포털 검색 페이지를 연다.

### 실시간 표시 원칙
- 프로그램 점수: `users/{uid}/doseRecords/{date}/{slot}/programScore`
- 배출 시간: `.../dispensedAt`
- 복용 시간: `.../estimatedTakenAt` 또는 `.../pouchPickedUpAt`
- 잔량: `devices/{deviceId}/inventory`
- 종합 기기 상태: `devices/{deviceId}/deviceStatus`
- 네트워크 상태: `devices/{deviceId}/network/status`
- AI 조정 다음 알림: `devices/{deviceId}/medicationSchedule/nextDoseAt`

앱/Web에는 위 값에 대한 데모 fallback을 두지 않는다. 과거 Firebase DB에 테스트 값이 저장되어 있다면 해당 값은 실제 서버 데이터로 간주되어 그대로 보이므로 Firebase 콘솔에서 테스트 레코드를 삭제해야 한다.

### AI 맞춤 코멘트 요청 추가 구조
`users/{uid}/medicineInsightRequests/{requestId}`
- `userContext.age`: 사용자 나이
- `userContext.heightCm`: 사용자 키
- `userContext.weightKg`: 사용자 체중
- `medicationContext`: 선택한 약의 name/doseAmount/timesPerDay/intervalHours/itemSeq/cautionText
- `prompt`: 위 사용자/약 정보를 기반으로 생성한 AI 분석용 프롬프트
- `source`: `MFDS_DRUG_PRODUCT_API+GEMINI`
- `status`: `PENDING` 등 서버 처리 상태

AI 서버 처리 결과는 기존대로 `users/{uid}/medicineInsights/latest/comment`에 저장하면 Android/Web 화면에 실시간 반영된다.
