# QR 웹앱 배포 안내

## 전체 흐름

ESP32 → Firebase Realtime Database → 웹앱 → 휴대폰 화면

QR코드는 웹앱 주소를 여는 입구입니다. 데이터는 QR이나 휴대폰 안이 아니라
Firebase의 `users/{로그인 UID}` 아래에 계속 저장됩니다.

## 1. Firebase 웹 앱 등록

Firebase Console에서 현재 Android 앱과 같은 프로젝트를 선택하고
`프로젝트 설정 > 내 앱 > 앱 추가 > 웹(</>)`을 선택합니다.
표시되는 `firebaseConfig` 값을 `web/firebase-config.js`에 옮깁니다.

## 2. 이메일 로그인 활성화

`Authentication > Sign-in method`에서 이메일/비밀번호 로그인을 활성화합니다.
Android 앱에서 사용하던 계정과 같은 계정으로 로그인해야 동일한 UID 데이터가
표시됩니다.

## 3. 웹앱 배포

터미널에서 프로젝트 최상위 폴더로 이동한 다음 실행합니다.

```bash
npm install -g firebase-tools
firebase login
firebase use --add
firebase deploy --only hosting
```

배포가 끝나면 `https://프로젝트ID.web.app` 형태의 주소가 출력됩니다.

## 4. QR 생성

위 주소만 QR코드에 넣습니다. 휴대폰 기본 카메라로 QR을 촬영하면 Safari,
Chrome 또는 삼성 인터넷에서 웹앱이 열립니다. 배포 주소가 정해지기 전에는
최종 QR코드를 만들 수 없습니다.

## 5. 앱처럼 설치

- iPhone: Safari 공유 버튼 → `홈 화면에 추가`
- Android: 브라우저 메뉴 → `홈 화면에 추가`

설치하지 않아도 브라우저에서 모든 기능을 사용할 수 있습니다.

## 보안 주의

- QR에 이메일, 비밀번호, Database Secret을 넣지 않습니다.
- Firebase Database Rules는 로그인 사용자가 자신의 `users/{uid}`만 읽고
  쓰도록 유지해야 합니다.
