// 복약관리기 펌웨어 v2
//
// 하드웨어 구성
//   MAX98357A + 스피커 - 알림음/음성
//   서보 x2 (연속회전) - 아침/저녁 배출
//   아케이드 버튼 x1 - 게임 입력 겸 상태확인, 초음파 죽었을 때 복약확인용
//   HC-SR04 초음파 - 트레이 끝에서 배출/픽업 감지
//   TFT(ILI9341, SPI) - 시계/상태/게임 화면
//   WiFi + Firebase RTDB
//   MLP(TFLite) - 저녁 복약시각 보정
//
// 로드셀은 뗐음
//
// 라이브러리: ESP32Servo(madhephaestus), TFT_eSPI(Bodmer), ESP8266Audio,
//            ArduTFLite/Chirale_TensorFlowLite, Arduino_JSON
//
// 보드 바뀌면 이 값들부터 다시 잡을 것: ULTRASONIC_CLOSE_THRESHOLD_CM,
// SERVO_RUN_SPEED_VALUE/SERVO_DISPENSE_DURATION_MS, MEAL_TIME_DINNER, dynamicMorningSchedule

#include <Arduino.h>
#include <WiFi.h>
#include <WiFiClientSecure.h>
#include <HTTPClient.h>
#include <WebServer.h>
#include <Preferences.h>
#include <time.h>

// HX711 로드셀은 뺐음
#include <ESP32Servo.h>
#include <SPI.h>
#include <TFT_eSPI.h>

#include <LittleFS.h>
#include <AudioFileSourceLittleFS.h>
// AudioFileSourceHTTPStream은 나중에 라즈베리파이 붙일 때 다시 (지금은 안 씀)
#include <AudioGeneratorWAV.h>
#include <AudioOutputI2S.h>

// Arduino_JSON은 꼭 제일 마지막에 include. JSON.typeof(...)를 쓰려고 typeof를
// typeof_로 매크로 치환하는데 앞에 두면 TFT_eSPI/ESP32 코어 헤더의 typeof랑 충돌남
#include <Arduino_JSON.h>

// 저녁약 시각 AI 조정용 MLP 모델
#include <ArduTFLite.h>
#include "medication_model.h"

// 자동 프로토타입 생성 때문에 위로 올림 - MealTime 쓰는 함수 프로토타입이
// 이 정의보다 먼저 삽입돼서 "MealTime not declared" 나는 걸 방지
struct MealTime { uint8_t hour; uint8_t minute; };

// 같은 이유로 enum들도 위쪽에 몰아둠
enum SystemState {
  STATE_STANDBY,
  STATE_MED_STATUS,   // 복약 상태 화면 (2단계: 상태표시 -> 잔여일수)
  STATE_REFLEX_TEST,
  STATE_DISPENSE
};
enum MealSlot { MEAL_NONE, MEAL_MORNING, MEAL_DINNER };
enum GameType { GAME_RED_GREEN, GAME_MOVING_CIRCLE, GAME_SHRINKING_CIRCLE };

// WiFi
// 하드코딩된 기본 WiFi는 없음. 저장된 정보가 없으면 항상 설정 모드(AP)로 진입.

// AP 이름은 앱 규격에 맞춰 고정: "B-OMM" (기기 ID와 별개)
constexpr const char* WIFI_SETUP_AP_SSID = "B-OMM";
constexpr unsigned long WIFI_CONNECT_TIMEOUT_MS = 15000;

Preferences wifiPrefs;
WebServer setupWebServer(80);
// voiceServer는 라즈베리파이 붙기 전까진 보류
bool inWifiSetupMode = false;

// Firebase
constexpr const char* FIREBASE_HOST = "https://fir-ver6-default-rtdb.firebaseio.com";
constexpr const char* DEVICE_ID     = "BOMM-001"; // Firebase 콘솔에서 실제 확인된 값
constexpr const char* FIREBASE_AUTH = "eOmbPdK0zVdoV0yb8DAeGGhSUKWDj4pudX1nhVCF";

const char* FIREBASE_ROOT_CA = R"EOF(
-----BEGIN CERTIFICATE-----
MIIFWjCCA0KgAwIBAgIQbkepxUtHDA3sM9CJuRz04TANBgkqhkiG9w0BAQwFADBH
MQswCQYDVQQGEwJVUzEiMCAGA1UEChMZR29vZ2xlIFRydXN0IFNlcnZpY2VzIExM
QzEUMBIGA1UEAxMLR1RTIFJvb3QgUjEwHhcNMTYwNjIyMDAwMDAwWhcNMzYwNjIy
MDAwMDAwWjBHMQswCQYDVQQGEwJVUzEiMCAGA1UEChMZR29vZ2xlIFRydXN0IFNl
cnZpY2VzIExMQzEUMBIGA1UEAxMLR1RTIFJvb3QgUjEwggIiMA0GCSqGSIb3DQEB
AQUAA4ICDwAwggIKAoICAQC2EQKLHuOhd5s73L+UPreVp0A8of2C+X0yBoJx9vaM
f/vo27xqLpeXo4xL+Sv2sfnOhB2x+cWX3u+58qPpvBKJXqeqUqv4IyfLpLGcY9vX
mX7wCl7raKb0xlpHDU0QM+NOsROjyBhsS+z8CZDfnWQpJSMHobTSPS5g4M/SCYe7
zUjwTcLCeoiKu7rPWRnWr4+wB7CeMfGCwcDfLqZtbBkOtdh+JhpFAz2weaSUKK0P
fyblqAj+lug8aJRT7oM6iCsVlgmy4HqMLnXWnOunVmSPlk9orj2XwoSPwLxAwAtc
vfaHszVsrBhQf4TgTM2S0yDpM7xSma8ytSmzJSq0SPly4cpk9+aCEI3oncKKiPo4
Zor8Y/kB+Xj9e1x3+naH+uzfsQ55lVe0vSbv1gHR6xYKu44LtcXFilWr06zqkUsp
zBmkMiVOKvFlRNACzqrOSbTqn3yDsEB750Orp2yjj32JgfpMpf/VjsPOS+C12LOO
Rc92wO1AK/1TD7Cn1TsNsYqiA94xrcx36m97PtbfkSIS5r762DL8EGMUUXLeXdYW
k70paDPvOmbsB4om3xPXV2V4J95eSRQAogB/mqghtqmxlbCluQ0WEdrHbEg8QOB+
DVrNVjzRlwW5y0vtOUucxD/SVRNuJLDWcfr0wbrM7Rv1/oFB2ACYPTrIrnqYNxgF
lQIDAQABo0IwQDAOBgNVHQ8BAf8EBAMCAQYwDwYDVR0TAQH/BAUwAwEB/zAdBgNV
HQ4EFgQU5K8rJnEaK0gnhS9SZizv8IkTcT4wDQYJKoZIhvcNAQEMBQADggIBADiW
Cu49tJYeX++dnAsznyvgyv3SjgofQXSlfKqE1OXyHuY3UjKcC9FhHb8owbZEKTV1
d5iyfNm9dKyKaOOpMQkpAWBz40d8U6iQSifvS9efk+eCNs6aaAyC58/UEBZvXw6Z
XPYfcX3v73svfuo21pdwCxXu11xWajOl40k4DLh9+42FpLFZXvRq4d2h9mREruZR
gyFmxhE+885H7pwoHyXa/6xmld01D1zvICxi/ZG6qcz8WpyTgYMpl0p8WnK0OdC3
d8t5/Wk6kjftbjhlRn7pYL15iJdfOBL07q9bgsiG1eGZbYwE8na6SfZu6W0eX6Dv
J4J2QPim01hcDyxC2kLGe4g0x8HYRZvBPsVhHdljUEn2NIVq4BjFbkerQUIpm/Zg
DdIx02OYI5NaAIFItO/Nis3Jz5nu2Z6qNuFoS3FJFDYoOj0dzpqPJeaAcWErtXvM
+SUWgeExX6GjfhaknBZqlxi9dnKlC54dNuYvoS++cJEPqOba+MSSQGwlfnuzCdyy
F62ARPBopY+Udf90WuioAnwMCeKpSwughQtiue+hMZL77/ZRBIls6Kl0obsXs7X9
SQ98POyDGCBDTtWTurQ0sR8WNh8M5mQ5Fkzc4P4dyKliPUDqysU0ArSuiYgzNdws
E3PYJ/HQcu51OyLemGhmW/HGY0dVHLqlCFF1pkgl
-----END CERTIFICATE-----
)EOF";

// 핀 배정
constexpr uint8_t I2S_BCLK_PIN = 26;
constexpr uint8_t I2S_LRC_PIN  = 13;
constexpr uint8_t I2S_DOUT_PIN = 25;

// HX711_SCK_PIN/DT_PIN도 로드셀 뺐으니 삭제

constexpr uint8_t SERVO_MORNING_PIN = 15;
constexpr uint8_t SERVO_DINNER_PIN  = 14;

constexpr uint8_t BUTTON_PIN = 4;

bool forceClockRedraw = true; // 다른 화면에서 대기모드로 돌아올 때 강제로 한 번 다시 그리기 위한 플래그
// (triggerEmergencyAlert 등에서 바로 아래에 쓰이기 때문에 여기 위치해야 함)

// 비상 버튼 (5초 이상 길게 누르면 긴급알림 전송)
void sendNotification(const String &type, const String &message); // 프로토타입 선언 (아래 1025줄쯤에 실제 정의 있음)
constexpr unsigned long EMERGENCY_HOLD_MS = 5000;
bool emergencyButtonHeld = false;
unsigned long emergencyButtonDownStartMs = 0;
bool emergencyAlreadyTriggeredThisHold = false;

void triggerEmergencyAlert() {
  Serial.println("[EMERGENCY] 버튼 5초 이상 눌림 - 비상 알림 전송");
  sendNotification("EMERGENCY", "버튼 5초 이상 눌림 - 비상 알림");
  sendUserAlert("EMERGENCY", "응급 알림",
                "복약기기에서 응급 버튼이 눌렸습니다. 확인해주세요.");
  // 화면/음성 피드백
  tftMessage("긴급 알림이\n전송되었습니다");
  delayWithAudioTick(2000);
  forceClockRedraw = true;
}

// 상태(currentState)와 무관하게 항상 체크 - 게임 중이든 배출 중이든 5초 누르면 작동
void checkEmergencyButtonHold() {
  bool isDown = (digitalRead(BUTTON_PIN) == LOW); // 풀업 기준, 눌려있는 동안 계속 LOW

  if (isDown) {
    if (!emergencyButtonHeld) {
      emergencyButtonHeld = true;
      emergencyButtonDownStartMs = millis();
      emergencyAlreadyTriggeredThisHold = false;
    } else if (!emergencyAlreadyTriggeredThisHold &&
               millis() - emergencyButtonDownStartMs >= EMERGENCY_HOLD_MS) {
      emergencyAlreadyTriggeredThisHold = true;
      triggerEmergencyAlert();
    }
  } else {
    emergencyButtonHeld = false;
  }
}
constexpr uint8_t ULTRASONIC_TRIG_PIN = 12;
constexpr uint8_t ULTRASONIC_ECHO_PIN = 35;
// 실측 기준: 빈 경사로 ≈3.7cm, 약 있을 때 ≈3.1~3.4cm (차이 0.3~0.6cm로 매우 작음)
constexpr float ULTRASONIC_CLOSE_THRESHOLD_CM = 3.55f; // 기준선을 아직 못 구했을 때만 쓰는 폴백값(빈/찬 상태 중간값)
constexpr float ULTRASONIC_ARRIVAL_DELTA_CM = 0.2f;   // 기준선보다 이만큼 이상 가까워지면 "도착 감지" (실측 최소차이 0.3cm보다 여유있게 낮춤)
float lastUltrasonicDistanceCm = -1; // 마지막 실측 거리 (-1이면 응답 없음)
bool ultrasonicOnline = false;       // pulseIn 응답이 있었는지(센서 살아있는지)
bool lastUltrasonicOkState = true;   // 직전 하트비트 때 정상이었는지 (OFFLINE 전환 알림용, 정상이라고 가정하고 시작)
constexpr uint8_t MED_LED_PIN = 2; // 복약 가능 시간 점멸 LED (점심 서보 빠지면서 비워진 자리)

// TFT_eSPI 사용 시 SCK/MOSI/MISO/CS/DC/RST는 User_setup.h에서 설정
constexpr uint8_t TFT_LED_PIN  = 21;

// 서보모터 배출 동작 — 360도 연속회전 서보(MG90S) 기준
//   테스트하면서 이 값들만 조정하면 됨
constexpr int SERVO_STOP_VALUE      = 90; // 정지 값 (서보마다 미세하게 다를 수 있어 실측 후 조정 필요)
constexpr int SERVO_RUN_SPEED_VALUE = 60; // 회전 속도 (90에서 멀수록 빠름, 0~180 사이로 테스트하며 조정)
constexpr unsigned long SERVO_DISPENSE_DURATION_MS = 1500; // 배출 1회당 회전 유지 시간(ms), 테스트하며 조정

// 복약 시간표 (24시간제) 및 마진
// MealTime은 위에 include 바로 뒤로 옮겨둠 (프로토타입 순서 문제)
// 아침 배출 스케줄은 이제 고정값이 아니라 앱(devices/{id}/medicationSchedule/morningTime)에서
//   읽어오는 값으로 바뀜. 아래는 아직 못 읽어왔을 때 쓰는 기본값일 뿐.
MealTime dynamicMorningSchedule = { 8, 0 };
constexpr MealTime MEAL_TIME_DINNER  = { 19, 0 }; // 저녁은 AI가 매일 새로 계산하므로 이 값은 최초 fallback 용도로만 씀

// 저녁약 시각 AI 조정 (MLP 모델)
constexpr int BASE_MORNING_MIN = 540;  // 09:00 (학습 데이터 기준 아침 시각)
constexpr int BASE_EVENING_MIN = 1080; // 18:00 (학습 데이터 기준 저녁 시각)
constexpr float MORNING_NORM_DIVISOR = 240.0f;      // 입력 정규화: 아침변화량 / 240
constexpr float EVENING_DENORM_MULTIPLIER = 360.0f; // 출력 역정규화: 모델출력 * 360
constexpr int MIN_GAP_MINUTES = 360;   // 최소 6시간 안전 규칙 (아침 실제 배출 후)
constexpr int MORNING_SHIFT_MIN_TRAINED = -180; // 학습 범위 하한(분)
constexpr int MORNING_SHIFT_MAX_TRAINED = 240;  // 학습 범위 상한(분)

constexpr int MLP_TENSOR_ARENA_SIZE = 4 * 1024; // 모델이 매우 작아서(177개 파라미터) 이 정도면 충분
alignas(16) uint8_t mlpTensorArena[MLP_TENSOR_ARENA_SIZE];
bool mlpModelReady = false;

// 오늘 계산된 AI 저녁 목표 시각(자정 이후 분). -1이면 아직 계산 안 됨(기본 시각 사용).
int dynamicEveningTargetMin = -1;
bool pendingEveningCalcForMorning = false;   // 픽업 모니터링 끝나면 저녁시각 계산해야 하는지
int pendingEveningCalcActualMorningMin = -1; // 그때 쓸 실제 아침 배출시각(분)
constexpr int DISPENSE_MARGIN_MIN = 120; // 앞뒤 2시간 마진

// 로드셀 / 남은 약 계산
// (LOADCELL_CALIBRATION_FACTOR 제거됨)
// totalDoseCountAtFill/perDoseWeightGram도 로드셀이랑 같이 삭제됨

bool takenMorning = false;
bool takenDinner = false;
bool morningWindowMissedReported = false; // 오늘 아침 미복용을 이미 서버에 보고했는지
bool dinnerWindowMissedReported = false;
bool morningReminder1hrSent = false; // 1시간 경과 리마인더 이미 보냈는지
bool dinnerReminder1hrSent = false;
int lastResetDay = -1;

// 비정상 버튼 입력 감지
constexpr int ABNORMAL_PRESS_THRESHOLD = 5;
constexpr unsigned long ABNORMAL_WINDOW_MS = 60000;

// 점수 산정 기준
// 반응속도 게임: 100ms=100점, 3000ms=0점, 1점당 29ms
constexpr float REACTION_BEST_MS   = 100.0f;
constexpr float REACTION_WORST_MS  = 3000.0f;
// 거리/반지름 오차 게임: 오차0=100점, maxError=0점 (호출부에서 maxError 전달)

// 전역 객체
// (HX711 scale 객체 제거됨)
Servo servoMorning, servoDinner;
// 연속회전 서보(MG90S 360도)로 변경됨: 각도(위치) 개념이 없어서
//   이전에 있던 lastAngle* 추적 변수는 더 이상 필요 없음
TFT_eSPI tft = TFT_eSPI();

AudioFileSourceLittleFS *audioFile = nullptr;
// audioHttpStream도 보류 목록
AudioGeneratorWAV *audioWav = nullptr;
AudioOutputI2S *audioOut = nullptr;

// 상태 머신 정의
// enum들도 같은 이유로 위쪽에
SystemState currentState = STATE_STANDBY;

unsigned long medStatusEnterTime = 0;
constexpr unsigned long MED_STATUS_AUTO_RETURN_MS = 4000; // 이 시간 지나면 대기화면으로 자동 복귀

MealSlot pendingMealSlot = MEAL_NONE;
// forceClockRedraw도 위로 옮김, 비상버튼 함수가 이걸 먼저 씀

int abnormalPressCount = 0;
unsigned long abnormalWindowStart = 0;

// ---------------------- WiFi / 시간 / Firebase ----------------------
// ----------------------------------------------------
// WiFi 설정 웹페이지 (AP 모드에서 핸드폰이 접속했을 때 보여줄 페이지)
// ----------------------------------------------------
const char* WIFI_SETUP_HTML = R"HTML(
<!DOCTYPE html><html><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>WiFi 설정</title>
<style>
body{font-family:sans-serif;padding:24px;max-width:400px;margin:0 auto;}
h2{font-size:22px;} input,select{width:100%;padding:12px;font-size:16px;margin:6px 0 16px;box-sizing:border-box;}
button{width:100%;padding:14px;font-size:18px;background:#2b7cff;color:#fff;border:none;border-radius:8px;}
</style></head><body>
<h2>복약 관리기 WiFi 설정</h2>
<form action="/save" method="POST">
  <label>WiFi 이름 (SSID)</label>
  <select name="ssid" id="ssidSelect" required>
    <option value="">불러오는 중...</option>
  </select>
  <label>WiFi 비밀번호</label>
  <input name="password" type="password">
  <button type="submit">저장하고 연결</button>
</form>
<script>
fetch('/api/networks').then(r => r.json()).then(list => {
  const sel = document.getElementById('ssidSelect');
  sel.innerHTML = '<option value="">-- 선택하세요 --</option>';
  list.forEach(net => {
    const opt = document.createElement('option');
    opt.value = net.ssid;
    opt.textContent = net.ssid + ' (' + net.rssi + 'dBm)';
    sel.appendChild(opt);
  });
}).catch(() => {
  document.getElementById('ssidSelect').innerHTML = '<option value="">목록을 못 불러왔어요</option>';
});
</script>
</body></html>
)HTML";

void handleSetupRoot() {
  setupWebServer.send(200, "text/html; charset=utf-8", WIFI_SETUP_HTML);
}

// 주변 WiFi 스캔 결과를 JSON 배열로 만들어 반환: [{"ssid":"...", "rssi":-45}, ...]
void handleApiNetworks() {
  int n = WiFi.scanNetworks();

  String json = "[";
  for (int i = 0; i < n; i++) {
    if (i > 0) json += ",";
    String ssid = WiFi.SSID(i);
    ssid.replace("\"", "'"); // 혹시 모를 따옴표 방지
    json += "{\"ssid\":\"" + ssid + "\",\"rssi\":" + String(WiFi.RSSI(i)) + "}";
  }
  json += "]";

  WiFi.scanDelete();
  setupWebServer.send(200, "application/json", json);
}

// SSID/비밀번호를 저장하고 재시작 (HTML 폼, JSON API 공용)
void saveWifiCredentialsAndRestart(const String &ssid, const String &password) {
  wifiPrefs.begin("wifi", false);
  wifiPrefs.putString("ssid", ssid);
  wifiPrefs.putString("password", password);
  wifiPrefs.end();

  Serial.println("[INFO] 새 WiFi 정보 저장, 재시작합니다: " + ssid);
  delay(1000);
  ESP.restart();
}

void handleSetupSave() {
  String ssid = setupWebServer.arg("ssid");
  String password = setupWebServer.arg("password");

  // bomm://close 로 이동시키면 앱 WebView의 shouldOverrideUrlLoading에서 잡아서 닫아줌
  setupWebServer.send(200, "text/html; charset=utf-8",
    "<html><body style='font-family:sans-serif;padding:24px;text-align:center;'>"
    "<h3>저장 완료! 기기가 재시작됩니다.</h3>"
    "<a href='bomm://close' style='display:inline-block;margin-top:20px;padding:14px 28px;"
    "background:#2b7cff;color:#fff;border-radius:8px;text-decoration:none;font-size:16px;'>"
    "앱으로 돌아가기</a>"
    "</body></html>");

  saveWifiCredentialsAndRestart(ssid, password);
}

// 앱에서 호출하는 JSON API: POST /api/wifi  Body: {"ssid": "...", "password": "..."}
// ArduinoJson 없이 간단한 문자열 파싱으로 처리 (형식이 단순해서 충분함)
String extractJsonStringValue(const String &json, const String &key) {
  String pattern = "\"" + key + "\"";
  int keyIdx = json.indexOf(pattern);
  if (keyIdx == -1) return "";

  int colonIdx = json.indexOf(':', keyIdx);
  if (colonIdx == -1) return "";

  int firstQuote = json.indexOf('"', colonIdx + 1);
  if (firstQuote == -1) return "";

  int secondQuote = json.indexOf('"', firstQuote + 1);
  if (secondQuote == -1) return "";

  return json.substring(firstQuote + 1, secondQuote);
}

// 앱 규격: POST /provision  Body: {"deviceId":"...", "ssid":"...", "password":"..."}
void handleProvision() {
  if (setupWebServer.method() != HTTP_POST) {
    setupWebServer.send(405, "application/json", "{\"error\":\"POST only\"}");
    return;
  }

  String body = setupWebServer.arg("plain");
  String deviceIdFromApp = extractJsonStringValue(body, "deviceId");
  String ssid = extractJsonStringValue(body, "ssid");
  String password = extractJsonStringValue(body, "password");

  if (ssid.length() == 0) {
    setupWebServer.send(400, "application/json", "{\"error\":\"ssid required\"}");
    return;
  }

  if (deviceIdFromApp.length() > 0 && deviceIdFromApp != String(DEVICE_ID)) {
    Serial.println("[WARN] 앱이 보낸 deviceId(" + deviceIdFromApp + ")가 보드의 DEVICE_ID(" + String(DEVICE_ID) + ")와 다릅니다");
  }

  setupWebServer.send(200, "application/json", "{\"result\":\"ok\"}");

  saveWifiCredentialsAndRestart(ssid, password);
}

// AP+웹서버로 설정 모드 진입 (저장된 정보 없거나 연결 실패시)
// 캡티브 포털은 일부러 안 켬 - 폰이 로그인 팝업 브라우저 띄워버리면 앱 API 호출이랑 꼬임
void startWifiSetupMode() {
  inWifiSetupMode = true;
  Serial.println("[INFO] WiFi 설정 모드 진입: " + String(WIFI_SETUP_AP_SSID));

  WiFi.mode(WIFI_AP_STA); // AP 켠 상태에서도 주변 WiFi 스캔 가능하게 하려면 STA도 같이 필요
  WiFi.softAP(WIFI_SETUP_AP_SSID);

  setupWebServer.on("/", handleSetupRoot);
  setupWebServer.on("/save", HTTP_POST, handleSetupSave);       // 사람이 브라우저로 테스트할 때용
  setupWebServer.on("/provision", HTTP_POST, handleProvision);  // 앱 규격 JSON API
  setupWebServer.on("/api/networks", HTTP_GET, handleApiNetworks); // 주변 WiFi 목록 조회 API

  // OS가 인터넷 연결 확인용으로 던지는 요청들. 정상 응답 안 해주면
  // 로그인 팝업 브라우저가 자동으로 떠서 여기다 그냥 기대하는 응답 그대로 줌
  setupWebServer.on("/generate_204", HTTP_GET, []() {           // 안드로이드
    setupWebServer.send(204, "text/plain", "");
  });
  setupWebServer.on("/gen_204", HTTP_GET, []() {                 // 안드로이드(구형)
    setupWebServer.send(204, "text/plain", "");
  });
  setupWebServer.on("/hotspot-detect.html", HTTP_GET, []() {     // iOS/macOS
    setupWebServer.send(200, "text/html", "<HTML><HEAD><TITLE>Success</TITLE></HEAD><BODY>Success</BODY></HTML>");
  });
  setupWebServer.on("/ncsi.txt", HTTP_GET, []() {                // Windows
    setupWebServer.send(200, "text/plain", "Microsoft NCSI");
  });

  // 그 외 알 수 없는 경로는 리다이렉트 대신 그냥 404 (자동 팝업 유발 안 함)
  setupWebServer.onNotFound([]() {
    setupWebServer.send(404, "text/plain", "Not found");
  });
  setupWebServer.begin();

  tftMessage("\xec\x99\x80\xec\x9d\xb4\xed\x8c\x8c\xec\x9d\xb4 \xec\x97\xb0\xea\xb2\xb0 \xed\x95\x84\xec\x9a\x94\n\xec\x95\xb1\xec\x97\x90\xec\x84\x9c B-OMM \xec\x84\xa0\xed\x83\x9d"); // "와이파이 연결 필요\n앱에서 B-OMM 선택"

  // 설정 페이지에서 저장할 때까지 여기서 대기 (웹서버 요청 계속 처리)
  while (true) {
    setupWebServer.handleClient();

    // 설정모드에서도 시리얼로 "reset" 입력 가능하게 (사실 이미 초기화된 상태지만,
    // 상태가 꼬였을 때 강제로 다시 시도할 수 있도록)
    if (Serial.available()) {
      String cmd = Serial.readStringUntil('\n');
      cmd.trim();
      if (cmd == "reset") resetWifiCredentials();
    }

    delay(2);
  }
}

// 저장된 WiFi 정보로 접속 시도. 없거나 실패하면 설정 모드(AP)로 전환.
void connectWiFi() {
  wifiPrefs.begin("wifi", true); // 읽기 전용으로 열기
  String savedSsid = wifiPrefs.getString("ssid", "");
  String savedPassword = wifiPrefs.getString("password", "");
  wifiPrefs.end();

  if (savedSsid.length() == 0) {
    Serial.println("[INFO] 저장된 WiFi 정보 없음, 바로 설정 모드로 진입합니다");
    startWifiSetupMode(); // 저장 후 재부팅될 때까지 리턴하지 않음
    return;
  }

  Serial.println("[INFO] 저장된 WiFi 정보 사용: " + savedSsid);
  Serial.printf("[INFO] WiFi 연결 중: %s\n", savedSsid.c_str());
  WiFi.mode(WIFI_STA);
  WiFi.setSleep(false); // WiFi 절전(모뎀 슬립) 끄기 - 핫스팟류에서 주기적 끊김 방지
  WiFi.begin(savedSsid.c_str(), savedPassword.c_str());
  unsigned long start = millis();
  while (WiFi.status() != WL_CONNECTED && millis() - start < WIFI_CONNECT_TIMEOUT_MS) {
    delay(300);
    Serial.print(".");

    // 연결 대기 중에도 시리얼로 "reset" 입력 가능하게 (loop()가 아직 실행 전이라 여기서 확인해야 함)
    if (Serial.available()) {
      String cmd = Serial.readStringUntil('\n');
      cmd.trim();
      if (cmd == "reset") resetWifiCredentials(); // 내부에서 재부팅되므로 여기로 안 돌아옴
    }
  }
  Serial.println();

  if (WiFi.status() == WL_CONNECTED) {
    Serial.print("[INFO] WiFi 연결 완료, IP: ");
    Serial.println(WiFi.localIP());
  } else {
    Serial.println("[WARN] WiFi 연결 실패, 설정 모드로 전환합니다");
    startWifiSetupMode(); // 이 함수는 저장 후 재부팅될 때까지 리턴하지 않음
  }
}

bool isWiFiConnected() {
  return WiFi.status() == WL_CONNECTED;
}

void setupTime() {
  configTime(9 * 3600, 0, "pool.ntp.org", "time.google.com");
  time_t now = time(nullptr);
  Serial.print("[INFO] 시간 동기화 중");
  unsigned long start = millis();
  while (now < 100000 && millis() - start < 15000) {
    delay(300);
    Serial.print(".");
    now = time(nullptr);
  }
  Serial.println();
  Serial.println("[INFO] 시간 동기화 완료");
}

String getISOTimestamp() {
  time_t now = time(nullptr);
  struct tm timeinfo;
  localtime_r(&now, &timeinfo);
  char buf[32];
  strftime(buf, sizeof(buf), "%Y-%m-%dT%H:%M:%S", &timeinfo);
  return String(buf);
}

// 앱은 시간을 대부분 Long(epoch millis)로 다루므로 변환 헬퍼 제공
unsigned long long nowEpochMillis() {
  return (unsigned long long)time(nullptr) * 1000ULL;
}

// 이번 부팅 세션이 시작된 시각 (setupTime() 직후 setup()에서 기록됨).
// setup/command의 requestedAt이 이 시각보다 이전이면 "재부팅 전 남아있던 오래된 명령"으로 보고 무시함.
unsigned long long deviceBootEpochMs = 0;

// 오늘 날짜에 해당 MealTime(시:분)을 적용한 epoch millis (scheduledAt 계산용)
unsigned long long mealTimeToEpochMillisToday(MealTime mt) {
  time_t now = time(nullptr);
  struct tm timeinfo;
  localtime_r(&now, &timeinfo);
  timeinfo.tm_hour = mt.hour;
  timeinfo.tm_min = mt.minute;
  timeinfo.tm_sec = 0;
  time_t scheduled = mktime(&timeinfo);
  return (unsigned long long)scheduled * 1000ULL;
}

// 오늘 날짜 문자열 "yyyy-MM-dd" (doseRecords 경로용)
String getTodayDateString() {
  time_t now = time(nullptr);
  struct tm timeinfo;
  localtime_r(&now, &timeinfo);
  char buf[11];
  strftime(buf, sizeof(buf), "%Y-%m-%d", &timeinfo);
  return String(buf);
}

bool firebaseGet(const String &path, String &responseOut) {
  if (!isWiFiConnected()) return false;
  WiFiClientSecure client;
  client.setCACert(FIREBASE_ROOT_CA);
  HTTPClient http;

  String url = String(FIREBASE_HOST) + "/devices/" + DEVICE_ID + "/" + path + ".json";
  if (strlen(FIREBASE_AUTH) > 0) {
    url += "?auth=" + String(FIREBASE_AUTH);
  }
  if (!http.begin(client, url)) return false;

  int httpCode = http.GET();
  bool ok = (httpCode == 200);
  if (ok) {
    responseOut = http.getString();
  } else {
    Serial.printf("[ERROR] Firebase GET 실패(%s): %d\n", path.c_str(), httpCode);
  }
  http.end();
  return ok;
}

bool firebasePush(const String &path, const String &jsonPayload) {
  if (!isWiFiConnected()) return false;
  WiFiClientSecure client;
  client.setCACert(FIREBASE_ROOT_CA);
  HTTPClient http;

  String url = String(FIREBASE_HOST) + "/devices/" + DEVICE_ID + "/" + path + ".json";
  if (strlen(FIREBASE_AUTH) > 0) {
    url += "?auth=" + String(FIREBASE_AUTH);
  }
  if (!http.begin(client, url)) return false;
  http.addHeader("Content-Type", "application/json");
  int httpCode = http.POST(jsonPayload);
  bool ok = (httpCode == 200);
  http.end();
  return ok;
}

// ---------------------------------------------------------
// 전체 경로 기반 Firebase 통신 (devices/, users/ 등 어디든 접근 가능)
// ---------------------------------------------------------
bool firebaseGetFull(const String &fullPath, String &responseOut) {
  if (!isWiFiConnected()) return false;
  WiFiClientSecure client;
  client.setCACert(FIREBASE_ROOT_CA);
  HTTPClient http;

  String url = String(FIREBASE_HOST) + "/" + fullPath + ".json";
  if (strlen(FIREBASE_AUTH) > 0) url += "?auth=" + String(FIREBASE_AUTH);
  if (!http.begin(client, url)) return false;

  int httpCode = http.GET();
  bool ok = (httpCode == 200);
  if (ok) responseOut = http.getString();
  else Serial.printf("[ERROR] Firebase GET(전체경로) 실패(%s): %d\n", fullPath.c_str(), httpCode);
  http.end();
  return ok;
}

bool firebasePutFull(const String &fullPath, const String &jsonPayload) {
  if (!isWiFiConnected()) return false;
  WiFiClientSecure client;
  client.setCACert(FIREBASE_ROOT_CA);
  HTTPClient http;

  String url = String(FIREBASE_HOST) + "/" + fullPath + ".json";
  if (strlen(FIREBASE_AUTH) > 0) url += "?auth=" + String(FIREBASE_AUTH);
  if (!http.begin(client, url)) return false;
  http.addHeader("Content-Type", "application/json");
  int httpCode = http.PUT(jsonPayload);
  bool ok = (httpCode == 200);
  if (!ok) Serial.printf("[ERROR] Firebase PUT(전체경로) 실패(%s): %d\n", fullPath.c_str(), httpCode);
  http.end();
  return ok;
}

// POST: 전체경로 어디든 자동생성 ID로 새 항목을 추가 (users/{uid}/alerts 같은 곳에 씀)
bool firebasePushFull(const String &fullPath, const String &jsonPayload) {
  if (!isWiFiConnected()) return false;
  WiFiClientSecure client;
  client.setCACert(FIREBASE_ROOT_CA);
  HTTPClient http;

  String url = String(FIREBASE_HOST) + "/" + fullPath + ".json";
  if (strlen(FIREBASE_AUTH) > 0) url += "?auth=" + String(FIREBASE_AUTH);
  if (!http.begin(client, url)) return false;
  http.addHeader("Content-Type", "application/json");
  int httpCode = http.POST(jsonPayload);
  bool ok = (httpCode == 200);
  if (!ok) Serial.printf("[ERROR] Firebase POST(전체경로) 실패(%s): %d\n", fullPath.c_str(), httpCode);
  http.end();
  return ok;
}

// PATCH: 지정한 필드만 갱신 (다른 기존 필드는 그대로 보존됨) - 앱이 미리 만들어둔
// commands/{id}의 type/requestedDoseCount 등을 안 지우려면 PUT 대신 이걸 써야 함
bool firebasePatchFull(const String &fullPath, const String &jsonPayload) {
  if (!isWiFiConnected()) return false;
  WiFiClientSecure client;
  client.setCACert(FIREBASE_ROOT_CA);
  HTTPClient http;

  String url = String(FIREBASE_HOST) + "/" + fullPath + ".json";
  if (strlen(FIREBASE_AUTH) > 0) url += "?auth=" + String(FIREBASE_AUTH);
  if (!http.begin(client, url)) return false;
  http.addHeader("Content-Type", "application/json");
  int httpCode = http.PATCH(jsonPayload);
  bool ok = (httpCode == 200);
  if (!ok) Serial.printf("[ERROR] Firebase PATCH 실패(%s): %d\n", fullPath.c_str(), httpCode);
  http.end();
  return ok;
}

// 64비트 epoch millis 값을 문자열로 (String 클래스의 unsigned long은 32비트라 오버플로우 방지용)
String llToString(unsigned long long v) {
  char buf[24];
  snprintf(buf, sizeof(buf), "%llu", v);
  return String(buf);
}

// ---------------------------------------------------------
// ownerUid 캐시 (앱이 devices/{DEVICE_ID}/ownerUid 에 등록해둔 값)
// ---------------------------------------------------------
String cachedOwnerUid = "";
unsigned long lastOwnerUidFetchMs = 0;
constexpr unsigned long OWNER_UID_RETRY_MS = 15000;

// ---------------------------------------------------------
// 아침 배출 스케줄 시각 동기화 (devices/{id}/medicationSchedule/morningTime)
//   이건 "기기가 아침약을 배출하는 시간대"일 뿐, MLP 모델의 계산 기준값(BASE_MORNING_MIN=540)과는
//     별개임. 모델 기준값은 학습 당시 고정된 수학적 상수라 앱 설정과 무관하게 항상 540을 씀.
// ---------------------------------------------------------
unsigned long lastMorningScheduleFetchMs = 0;
constexpr unsigned long MORNING_SCHEDULE_FETCH_INTERVAL_MS = 60000; // 1분마다 확인 (앱에서 바꿀 수 있으니)

// "HH:MM" 문자열을 MealTime으로 파싱. 실패하면 false 반환.
bool parseHHMM(const String &s, MealTime &out) {
  int colonIdx = s.indexOf(':');
  if (colonIdx < 1 || colonIdx >= (int)s.length() - 1) return false;
  int h = s.substring(0, colonIdx).toInt();
  int m = s.substring(colonIdx + 1).toInt();
  if (h < 0 || h > 23 || m < 0 || m > 59) return false;
  out.hour = (uint8_t)h;
  out.minute = (uint8_t)m;
  return true;
}

void fetchMorningScheduleIfDue() {
  if (millis() - lastMorningScheduleFetchMs < MORNING_SCHEDULE_FETCH_INTERVAL_MS) return;
  lastMorningScheduleFetchMs = millis();

  String resp;
  if (!firebaseGetFull("devices/" + String(DEVICE_ID) + "/medicationSchedule/morningTime", resp)) return;
  resp.trim();
  if (resp == "null" || resp.length() < 3) return;
  if (resp.startsWith("\"") && resp.endsWith("\"")) resp = resp.substring(1, resp.length() - 1);

  MealTime parsed;
  if (parseHHMM(resp, parsed)) {
    if (parsed.hour != dynamicMorningSchedule.hour || parsed.minute != dynamicMorningSchedule.minute) {
      dynamicMorningSchedule = parsed;
      Serial.printf("[INFO] 아침 배출 스케줄 갱신됨: %02d:%02d\n", parsed.hour, parsed.minute);
    }
  } else {
    Serial.println("[WARN] morningTime 형식 파싱 실패: " + resp);
  }
}

// ---------------------------------------------------------
// 약 잔량 관리 - devices/{id}/inventory
//   remainingDoseCount               : 전체 잔여 개수 (앱/기기 공용, 기기가 배출 시 차감)
//   remainingDoseCountByPeriod.morning / .evening : 슬롯별 잔여 개수 (기기가 배출 시 차감)
//   initialDays / remainingDays      : 기기는 건드리지 않음 (앱 쪽 관리 영역)
// ---------------------------------------------------------
int cachedRemainingDoseCount = -1;    // 전체 잔여 개수 (-1 = 아직 파악 안 됨)
int cachedRemainingMorningCount = -1; // 아침 슬롯 잔여 개수
int cachedRemainingEveningCount = -1; // 저녁 슬롯 잔여 개수

unsigned long lastInventoryFetchMs = 0;
constexpr unsigned long INVENTORY_FETCH_INTERVAL_MS = 60000; // 1분마다 확인

void fetchInventoryIfDue() {
  if (millis() - lastInventoryFetchMs < INVENTORY_FETCH_INTERVAL_MS) return;
  lastInventoryFetchMs = millis();

  String resp;
  if (!firebaseGetFull("devices/" + String(DEVICE_ID) + "/inventory", resp)) return;
  resp.trim();
  if (resp == "null" || resp.length() < 3) return;

  JSONVar inv = JSON.parse(resp);
  if (JSON.typeof(inv) == "undefined") return;

  // 서버 값을 그대로 캐시에 동기화(리필/최초설정 등 앱 쪽 변경도 여기서 함께 반영됨)
  if (JSON.typeof(inv["remainingDoseCount"]) == "number") {
    cachedRemainingDoseCount = (int)(double)inv["remainingDoseCount"];
  }
  if (JSON.typeof(inv["remainingDoseCountByPeriod"]) == "object") {
    JSONVar byPeriod = inv["remainingDoseCountByPeriod"];
    if (JSON.typeof(byPeriod["morning"]) == "number") {
      cachedRemainingMorningCount = (int)(double)byPeriod["morning"];
    }
    if (JSON.typeof(byPeriod["evening"]) == "number") {
      cachedRemainingEveningCount = (int)(double)byPeriod["evening"];
    }
  }
  Serial.printf("[INV] 동기화: 전체=%d, 아침=%d, 저녁=%d\n",
                cachedRemainingDoseCount, cachedRemainingMorningCount, cachedRemainingEveningCount);
}

// 배출(스케줄이든 원격이든) 1회 성공할 때마다 호출.
// slot == MEAL_MORNING : remainingDoseCountByPeriod.morning + remainingDoseCount 각 -1
// slot == MEAL_DINNER  : remainingDoseCountByPeriod.evening + remainingDoseCount 각 -1
// slot == MEAL_NONE(기본값, 원격 배출 등 슬롯 불명확) : remainingDoseCount만 -1
void decrementInventory(MealSlot slot = MEAL_NONE) {
  if (cachedRemainingDoseCount < 0) return; // 아직 서버 값을 모르면 차감 자체를 스킵

  cachedRemainingDoseCount = max(0, cachedRemainingDoseCount - 1);

  String periodPatch;
  const char* slotLabel = "\xea\xb3\xb5\xed\x86\xb5"; // "공통"(원격 등, 슬롯 특정 안 됨)
  if (slot == MEAL_MORNING && cachedRemainingMorningCount >= 0) {
    cachedRemainingMorningCount = max(0, cachedRemainingMorningCount - 1);
    periodPatch = ",\"remainingDoseCountByPeriod/morning\":" + String(cachedRemainingMorningCount);
    slotLabel = "\xec\x95\x84\xec\xb9\xa8"; // "아침"
  } else if (slot == MEAL_DINNER && cachedRemainingEveningCount >= 0) {
    cachedRemainingEveningCount = max(0, cachedRemainingEveningCount - 1);
    periodPatch = ",\"remainingDoseCountByPeriod/evening\":" + String(cachedRemainingEveningCount);
    slotLabel = "\xec\xa0\x80\xeb\x85\x81"; // "저녁"
  }

  Serial.printf("[INV] %s 1개 차감, 전체 남은 개수 = %d\n", slotLabel, cachedRemainingDoseCount);

  String payload = "{\"remainingDoseCount\":" + String(cachedRemainingDoseCount) +
                    periodPatch +
                    ",\"updatedAt\":{\".sv\":\"timestamp\"}}";
  firebasePatchFull("devices/" + String(DEVICE_ID) + "/inventory", payload);

  if (cachedRemainingDoseCount == 0) {
    sendUserAlert("inventory_empty", "\xec\x95\xbd\x20\xec\x86\x8c\xec\xa7\x84", "\xeb\xb3\xb5\xec\x95\xbd\xea\xb8\xb0\xea\xb8\xb0\xec\x9d\x98\x20\xec\x95\xbd\xec\x9d\xb4\x20\xeb\xaa\xa8\xeb\x91\x90\x20\xec\x86\x8c\xec\xa7\x84\xeb\x90\x98\xec\x97\x88\xec\x8a\xb5\xeb\x8b\x88\xeb\x8b\xa4."); // "약 소진" / "복약기기의 약이 모두 소진되었습니다."
  } else if (cachedRemainingDoseCount <= 10) { // 5일분(아침/저녁 1일 2회 × 5일)
    sendUserAlert("inventory_low", "\xec\x95\xbd\x20\xec\x9e\x94\xeb\x9f\x89\x20\xeb\xb6\x80\xec\xa1\xb1",
                  "\xec\x95\xbd\xec\x9d\xb4\x20" + String(cachedRemainingDoseCount) + "\xea\xb0\x9c\x20\xeb\x82\xa8\xec\x95\x98\xec\x96\xb4\xec\x9a\x94\x2e\x20\xeb\xaf\xb8\xeb\xa6\xac\x20\xec\xb1\x84\xec\x9b\x8c\xec\xa3\xbc\xec\x84\xb8\xec\x9a\x94\x2e"); // "약 잔량 부족" / "약이 N개 남았어요. 미리 채워주세요."
  }
}

void fetchOwnerUidIfNeeded() {
  if (cachedOwnerUid.length() > 0) return;
  if (millis() - lastOwnerUidFetchMs < OWNER_UID_RETRY_MS) return;
  lastOwnerUidFetchMs = millis();

  String resp;
  if (!firebaseGetFull("devices/" + String(DEVICE_ID) + "/ownerUid", resp)) return;
  resp.trim();
  if (resp == "null" || resp.length() < 3) return;
  if (resp.startsWith("\"") && resp.endsWith("\"")) resp = resp.substring(1, resp.length() - 1);

  cachedOwnerUid = resp;
  Serial.println("[INFO] ownerUid 확인됨: " + cachedOwnerUid);
}

// ---------------------------------------------------------
// 기기 상태 하트비트 (devices/{id}/network)
// ---------------------------------------------------------
unsigned long lastHeartbeatMs = 0;
constexpr unsigned long HEARTBEAT_INTERVAL_MS = 30000;

void sendHeartbeatIfDue() {
  if (millis() - lastHeartbeatMs < HEARTBEAT_INTERVAL_MS) return;
  lastHeartbeatMs = millis();

  String netPayload = "{\"status\":\"ONLINE\",\"lastSeenAt\":{\".sv\":\"timestamp\"},\"updatedAt\":{\".sv\":\"timestamp\"}}";
  firebasePatchFull("devices/" + String(DEVICE_ID) + "/network", netPayload);

  // --- 초음파 ONLINE/OFFLINE 상태 ---
  float d = readUltrasonicDistanceCm(); // 이 호출 자체가 ultrasonicOnline도 같이 갱신함
  bool ultrasonicOk = ultrasonicOnline;
  String ultrasonicPayload = "{\"status\":\"" + String(ultrasonicOk ? "ONLINE" : "OFFLINE") + "\"," +
                              "\"distanceCm\":" + (ultrasonicOk ? String(d, 1) : "null") + "," +
                              "\"dispenseDetected\":" + String((ultrasonicOk && d < ULTRASONIC_CLOSE_THRESHOLD_CM) ? "true" : "false") + "," +
                              "\"lastUpdatedAt\":{\".sv\":\"timestamp\"}," +
                              "\"errorCode\":" + (ultrasonicOk ? "null" : "\"NO_ECHO_RESPONSE\"") + "}";
  firebasePatchFull("devices/" + String(DEVICE_ID) + "/sensors/ultrasonic", ultrasonicPayload);

  // 정상 -> 고장으로 "방금" 바뀐 순간에만 알림 (매 하트비트마다 반복 전송 방지)
  if (!ultrasonicOk && lastUltrasonicOkState) {
    sendUserAlert("device_issue",
                  "\xea\xb8\xb0\xea\xb8\xb0\x20\xec\x9d\xb4\xec\x83\x81",
                  "\xec\xb4\x88\xec\x9d\x8c\xed\x8c\x8c\x20\xec\x84\xbc\xec\x84\x9c\x20\xec\x9d\xb4\xec\x83\x81\x20\xea\xb0\x90\xec\xa7\x80\x28\xec\x9d\x91\xeb\x8b\xb5\x20\xec\x97\x86\xec\x9d\x8c\x29"); // "기기 이상" / "초음파 센서 이상 감지(응답 없음)"
  }
  lastUltrasonicOkState = ultrasonicOk;

  // motor/dispenser는 아직 실제 고장 진단 로직 없음(추후 보강 필요). 로드셀은 미사용이라 제외.
}

// ---------------------------------------------------------
// 원격 명령(WITHDRAW_MEDICATION) 폴링
// ---------------------------------------------------------
String pendingCommandId = "";
int pendingCommandDoseCount = 1;
int pendingCommandMorningDoses = 0; // commands/{id}의 morningDays
int pendingCommandEveningDoses = 0; // commands/{id}의 eveningDays
unsigned long lastCommandPollMs = 0;
constexpr unsigned long COMMAND_POLL_INTERVAL_MS = 5000;

// ---------------------------------------------------------
// performLoadCellCalibration 삭제됨(로드셀 안 씀)

void checkForPendingCommand() {
  if (currentState != STATE_STANDBY) return;      // 다른 작업 중이면 새 명령 안 받음
  if (pendingCommandId.length() > 0) return;       // 이미 처리 중인 명령 있음
  if (millis() - lastCommandPollMs < COMMAND_POLL_INTERVAL_MS) return;
  lastCommandPollMs = millis();

  String resp;
  if (!firebaseGetFull("devices/" + String(DEVICE_ID) + "/commands", resp)) return;
  if (resp == "null" || resp.length() < 3) return;

  JSONVar commands = JSON.parse(resp);
  if (JSON.typeof(commands) == "undefined") {
    Serial.println("[WARN] commands 파싱 실패");
    return;
  }

  JSONVar keys = commands.keys();
  for (int i = 0; i < keys.length(); i++) {
    String key = keys[i];
    JSONVar cmd = commands[key];

    String status = "";
    if (JSON.typeof(cmd["status"]) == "string") {
      status = (const char*) cmd["status"];
    }

    String cmdType = "";
    if (JSON.typeof(cmd["type"]) == "string") {
      cmdType = (const char*) cmd["type"];
    }

    if (status == "PENDING" && cmdType == "ADD_MEDICATION_STOCK") {
      // 약 추가(리필): days만큼 아침/저녁 각각 채워주고, 전체는 days*2로 갱신
      int days = (JSON.typeof(cmd["days"]) != "undefined") ? (int)cmd["days"] : 0;

      if (days <= 0) {
        Serial.println("[WARN] ADD_MEDICATION_STOCK 명령에 유효한 days 없음: " + key);
        String failPayload = "{\"status\":\"FAILED\",\"completedAt\":{\".sv\":\"timestamp\"},\"errorCode\":\"INVALID_DAYS\"}";
        firebasePatchFull("devices/" + String(DEVICE_ID) + "/commands/" + key, failPayload);
        continue;
      }

      if (cachedRemainingMorningCount < 0) cachedRemainingMorningCount = 0;
      if (cachedRemainingEveningCount < 0) cachedRemainingEveningCount = 0;
      if (cachedRemainingDoseCount < 0) cachedRemainingDoseCount = 0;

      cachedRemainingMorningCount += days;
      cachedRemainingEveningCount += days;
      cachedRemainingDoseCount += days * 2;

      Serial.printf("[INV] 약 추가(%d일분): 아침=%d, 저녁=%d, 전체=%d\n",
                    days, cachedRemainingMorningCount, cachedRemainingEveningCount, cachedRemainingDoseCount);

      String invPayload = "{\"remainingDoseCount\":" + String(cachedRemainingDoseCount) +
                           ",\"remainingDoseCountByPeriod/morning\":" + String(cachedRemainingMorningCount) +
                           ",\"remainingDoseCountByPeriod/evening\":" + String(cachedRemainingEveningCount) +
                           ",\"updatedAt\":{\".sv\":\"timestamp\"}}";
      firebasePatchFull("devices/" + String(DEVICE_ID) + "/inventory", invPayload);

      String cmdPayload = "{\"status\":\"COMPLETED\",\"completedAt\":{\".sv\":\"timestamp\"}}";
      firebasePatchFull("devices/" + String(DEVICE_ID) + "/commands/" + key, cmdPayload);

      sendNotification("stock_added", String(days) + "일분 약 추가됨");
      continue;
    }

    if (status == "PENDING" && cmdType != "WITHDRAW_MEDICATION") {
      // 그 외(WITHDRAW도 ADD_MEDICATION_STOCK도 아닌) 알 수 없는 타입 - 건드리지 않고 건너뜀
      continue;
    }

    if (status == "PENDING") {
      // devices/{id}/commands/{id} 리스트는 원격 배출(WITHDRAW) 전용
      if (cachedRemainingDoseCount == 0) {
        // 약이 없어서 원격배출도 불가 - 명령 실패 처리하고 알림
        Serial.println("[WARN] 약이 없어서 원격배출 명령 실패 처리: " + key);
        String failPayload = "{\"status\":\"FAILED\",\"completedAt\":{\".sv\":\"timestamp\"},\"errorCode\":\"OUT_OF_STOCK\"}";
        firebasePatchFull("devices/" + String(DEVICE_ID) + "/commands/" + key, failPayload);
        sendNotification("out_of_stock", "원격배출 요청됐으나 약이 없어서 실패");
        sendUserAlert("out_of_stock",
                      "\xec\x95\xbd\x20\xec\x86\x8c\xec\xa7\x84",
                      "\xec\x95\xbd\xec\x9d\xb4\x20\xec\x97\x86\xec\x96\xb4\xec\x84\x9c\x20\xeb\xb0\xb0\xec\xb6\x9c\xed\x95\x98\xec\xa7\x80\x20\xeb\xaa\xbb\xed\x96\x88\xec\x8a\xb5\xeb\x8b\x88\xeb\x8b\xa4"); // "약 소진" / "약이 없어서 배출하지 못했습니다"
        break;
      }

      pendingCommandId = key;
      pendingCommandDoseCount = (JSON.typeof(cmd["requestedDoseCount"]) != "undefined")
                                  ? (int)cmd["requestedDoseCount"] : 1;
      if (pendingCommandDoseCount <= 0) pendingCommandDoseCount = 1;

      pendingCommandMorningDoses = (JSON.typeof(cmd["morningDays"]) != "undefined")
                                      ? (int)cmd["morningDays"] : 0;
      pendingCommandEveningDoses = (JSON.typeof(cmd["eveningDays"]) != "undefined")
                                      ? (int)cmd["eveningDays"] : 0;
      if (pendingCommandMorningDoses < 0) pendingCommandMorningDoses = 0;
      if (pendingCommandEveningDoses < 0) pendingCommandEveningDoses = 0;
      // morningDays/eveningDays 둘 다 없는 예전 명령이면 전체를 아침으로 처리(기존 동작 유지)
      if (pendingCommandMorningDoses == 0 && pendingCommandEveningDoses == 0) {
        pendingCommandMorningDoses = pendingCommandDoseCount;
      }

      Serial.printf("[INFO] 원격 배출 명령 수신: %s (아침 %d회, 저녁 %d회)\n",
                    pendingCommandId.c_str(), pendingCommandMorningDoses, pendingCommandEveningDoses);

      Serial.println("[INFO] 원격 배출 명령 수신: " + pendingCommandId);

      pendingMealSlot = MEAL_NONE; // 원격 명령은 특정 시간대(슬롯) 없음
      currentState = STATE_DISPENSE; // 원격 배출은 순발력 게임 없이 바로 배출
      break;
    }
  }
}

// ---------------------------------------------------------
// 초기 설정(캘리브레이션) 명령 폴링 - devices/{id}/setup/command (단일 객체, status 필드 없음)
// 완료되면 devices/{id}/setup/result/setupComplete 를 true로 갱신
// ---------------------------------------------------------
String lastProcessedSetupCommandId = "";
unsigned long lastSetupCommandPollMs = 0;
constexpr unsigned long SETUP_COMMAND_POLL_INTERVAL_MS = 5000;

void checkForSetupCommand() {
  if (currentState != STATE_STANDBY) return;
  if (millis() - lastSetupCommandPollMs < SETUP_COMMAND_POLL_INTERVAL_MS) return;
  lastSetupCommandPollMs = millis();

  String resp;
  if (!firebaseGetFull("devices/" + String(DEVICE_ID) + "/setup/command", resp)) return;
  if (resp == "null" || resp.length() < 3) return;

  JSONVar cmd = JSON.parse(resp);
  if (JSON.typeof(cmd) == "undefined") return;

  String commandId = "";
  if (JSON.typeof(cmd["commandId"]) == "string") {
    commandId = (const char*) cmd["commandId"];
  }
  if (commandId.length() == 0 || commandId == lastProcessedSetupCommandId) return; // 없거나 이미 처리함

  // requestedAt이 이번 부팅보다 이전이면 재부팅 전에 남아있던 오래된 명령이므로 무시
  if (JSON.typeof(cmd["requestedAt"]) == "number") {
    unsigned long long requestedAt = (unsigned long long)(double)cmd["requestedAt"];
    if (requestedAt > 0 && requestedAt < deviceBootEpochMs) {
      Serial.println("[INFO] 이전 세션의 오래된 setup 명령이라 무시함: " + commandId);
      lastProcessedSetupCommandId = commandId;
      firebasePutFull("devices/" + String(DEVICE_ID) + "/setup/command", "null"); // 이 김에 정리
      return;
    }
  }

  String type = "";
  if (JSON.typeof(cmd["type"]) == "string") {
    type = (const char*) cmd["type"];
  }

  Serial.println("[INFO] setup 명령 수신: " + commandId + " (" + type + ")");

  bool success = true;
  String errorMessage = "";

  // CALIBRATE_LOAD_CELL_ZERO 처리도 삭제
  Serial.println("[WARN] 알 수 없는(또는 미지원) setup 명령 타입: " + type);
  success = false;
  errorMessage = "UNKNOWN_TYPE";

  String resultPayload = "{\"setupComplete\":" + String(success ? "true" : "false") +
                          ",\"completedAt\":{\".sv\":\"timestamp\"},\"errorMessage\":" +
                          (errorMessage.length() > 0 ? ("\"" + errorMessage + "\"") : "null") + "}";
  firebasePatchFull("devices/" + String(DEVICE_ID) + "/setup/result", resultPayload);

  // 처리 끝난 명령은 Firebase에서 지워서, 재부팅해도 같은 명령이 다시 실행되지 않게 함
  firebasePutFull("devices/" + String(DEVICE_ID) + "/setup/command", "null");

  lastProcessedSetupCommandId = commandId; // (재부팅 전까지의) 재실행 방지용, 위 삭제가 주된 방어선
}

void sendNotification(const String &type, const String &message) {
  String payload = "{\"type\":\"" + type + "\",\"message\":\"" + message +
                    "\",\"timestamp\":\"" + getISOTimestamp() + "\"}";
  Serial.println("[NOTIFY] " + type + ": " + message);
  firebasePush("events", payload);
}

// users/{ownerUid}/alerts 에 기록 (앱이 이 경로 보고 푸시알림 띄우는 용도)
void sendUserAlert(const String &type, const String &title, const String &message) {
  String payload = "{\"type\":\"" + type + "\"," +
                    "\"title\":\"" + title + "\"," +
                    "\"message\":\"" + message + "\"," +
                    "\"createdAt\":{\".sv\":\"timestamp\"}," +
                    "\"active\":true," +
                    "\"resolved\":false," +
                    "\"read\":false," +
                    "\"deviceId\":\"" + String(DEVICE_ID) + "\"}";
  Serial.println("[ALERT] " + title + ": " + message);
  firebasePushFull("devices/" + String(DEVICE_ID) + "/alerts", payload);
}

void sendGameScore(MealSlot slot, const String &gameType, int score) {
  String slotName;
  switch (slot) {
    case MEAL_MORNING: slotName = "morning"; break;
    case MEAL_DINNER:  slotName = "dinner";  break;
    default: slotName = "none"; break;
  }
  String payload = "{\"slot\":\"" + slotName + "\",\"game\":\"" + gameType +
                    "\",\"score\":" + String(score) +
                    ",\"timestamp\":\"" + getISOTimestamp() + "\"}";
  Serial.println("[SCORE] " + gameType + ": " + String(score) + "점");
  firebasePush("scores", payload); // 서버(앱)에서 이 리스트를 평균내서 사용
}

// ---------------------------- 오디오 알림 ----------------------------
constexpr float AUDIO_IDLE_GAIN     = 0.0f;
constexpr float AUDIO_PLAYBACK_GAIN = 0.6f;

// handlePlayTtsRequest, startVoiceServer 둘 다 지금은 안 씀 (라즈베리파이 연동 나중에)

void playAlertSound(const char* wavPath) {
  if (audioWav) {
    if (audioWav->isRunning()) audioWav->stop();
    delete audioWav;
    audioWav = nullptr;
  }
  if (audioFile) {
    delete audioFile;
    audioFile = nullptr;
  }
  if (!LittleFS.exists(wavPath)) {
    Serial.printf("[WARN] 알림음 파일 없음: %s\n", wavPath);
    return;
  }
  audioFile = new AudioFileSourceLittleFS(wavPath);
  audioWav = new AudioGeneratorWAV();
  audioOut->SetGain(AUDIO_PLAYBACK_GAIN);
  bool started = audioWav->begin(audioFile, audioOut);
  Serial.printf("[AUDIO] 재생 시도: %s, begin()=%s\n", wavPath, started ? "성공" : "실패");
}

// playTtsFromUrl도 마찬가지로 보류

void audioLoopTick() {
  if (audioWav && audioWav->isRunning()) {
    if (!audioWav->loop()) {
      audioWav->stop();
      audioOut->SetGain(AUDIO_IDLE_GAIN);
      // 재생 자연 종료 시, 쓰고 있던 로컬 파일 소스도 같이 정리
      if (audioFile) { delete audioFile; audioFile = nullptr; }
    }
  }
}

// delay()는 loop()로 제어권이 안 돌아가서 그 사이에 오디오가 완전히 방치됨.
// 대기하는 동안에도 오디오를 계속 먹여주는(tick) 버전.
void delayWithAudioTick(unsigned long ms) {
  unsigned long start = millis();
  while (millis() - start < ms) {
    audioLoopTick();
    delay(5);
  }
}

// ----------------------------- 로드셀 -----------------------------
// readWeightGram/calibrateNewFill/getRemainingDays 다 로드셀 관련이라 삭제.
//  잔량 표시는 cachedRemainingDoseCount(전체 개수) 기반)

// --------------------------- 서보 (배출) ---------------------------
void dispenseServo(Servo &servo) {
  Serial.printf("[DEBUG] 연속회전 시작: 속도값=%d, 유지시간=%lums\n", SERVO_RUN_SPEED_VALUE, SERVO_DISPENSE_DURATION_MS);

  servo.write(SERVO_RUN_SPEED_VALUE); // 정해진 속도로 회전 시작 (역회전 없음, 한 방향으로만 계속 돔)
  delayWithAudioTick(SERVO_DISPENSE_DURATION_MS); // 회전하는 동안에도 안내음성이 계속 재생되게 함
  servo.write(SERVO_STOP_VALUE);      // 정지

  Serial.println("[DEBUG] 회전 종료, 정지");
}

void dispenseMedication(MealSlot slot) {
  switch (slot) {
    case MEAL_MORNING: dispenseServo(servoMorning); break;
    case MEAL_DINNER:  dispenseServo(servoDinner);  break;
    default: break;
  }
}

// 앱에서 원격으로 "지금 꺼내기(WITHDRAW_MEDICATION)" 요청 시 사용.
// commands/{id}의 morningDays/eveningDays 값만큼 각각의 서보로 배출하고,
// 슬롯이 명확하므로 재고도 해당 period(morning/evening)까지 정확히 차감함.
void dispenseRemote(int morningDoses, int eveningDoses) {
  morningDoses = constrain(morningDoses, 0, 10); // 안전 상한
  eveningDoses = constrain(eveningDoses, 0, 10);

  for (int i = 0; i < morningDoses; i++) {
    dispenseServo(servoMorning);
    decrementInventory(MEAL_MORNING);
    delayWithAudioTick(300);
  }
  for (int i = 0; i < eveningDoses; i++) {
    dispenseServo(servoDinner);
    decrementInventory(MEAL_DINNER);
    delayWithAudioTick(300);
  }
}

// --------------------------- 초음파 센서(HC-SR04) ---------------------------
// (lastUltrasonicDistanceCm, ultrasonicOnline은 파일 상단 전역변수 섹션으로 이동함)

// 실제로 트리거 펄스를 쏘고 에코 시간을 재서 거리(cm)를 계산.
// 응답이 없으면(타임아웃) -1을 반환하고 ultrasonicOnline을 false로 갱신함.
unsigned long lastUltrasonicMeasureMs = 0;
constexpr unsigned long ULTRASONIC_MIN_INTERVAL_MS = 65; // HC-SR04 권장 최소 트리거 간격(음파 잔향 소멸 시간)

float readUltrasonicDistanceCm() {
  // 너무 빨리 연속으로 재면(음파가 아직 안 가라앉음) 응답이 없다고 오판할 수 있어서,
  // 최소 간격 안 지났으면 새로 트리거 안 하고 방금 잰 값을 그대로 재사용함
  unsigned long nowMs = millis();
  if (nowMs - lastUltrasonicMeasureMs < ULTRASONIC_MIN_INTERVAL_MS) {
    return lastUltrasonicDistanceCm;
  }
  lastUltrasonicMeasureMs = nowMs;

  digitalWrite(ULTRASONIC_TRIG_PIN, LOW);
  delayMicroseconds(2);
  digitalWrite(ULTRASONIC_TRIG_PIN, HIGH);
  delayMicroseconds(10);
  digitalWrite(ULTRASONIC_TRIG_PIN, LOW);

  unsigned long durationUs = pulseIn(ULTRASONIC_ECHO_PIN, HIGH, 30000); // 최대 30ms 대기(약 5m 왕복)

  if (durationUs == 0) {
    ultrasonicOnline = false;
    lastUltrasonicDistanceCm = -1;
    return -1;
  }

  ultrasonicOnline = true;
  float distanceCm = durationUs / 58.0f; // 음속 기준 왕복시간 -> cm 변환 공식
  lastUltrasonicDistanceCm = distanceCm;
  return distanceCm;
}

float ultrasonicBaselineCm = -1; // 배출 시작 직전 측정한 "빈 경사로" 거리 (기준선)

// 배출(서보) 시작 직전에 호출: 지금(=아직 약 없는 상태)의 거리를 기준선으로 저장
void captureUltrasonicBaseline() {
  float d = readUltrasonicDistanceCm();
  if (ultrasonicOnline) {
    ultrasonicBaselineCm = d;
    Serial.printf("[US] 기준선(빈 경사로) 거리 = %.2fcm\n", d);
  } else {
    ultrasonicBaselineCm = -1;
    Serial.println("[US] 센서 응답 없어서 기준선 측정 못함");
  }
}

// 기준선 대비 "충분히 가까워졌는지"로 판단 (설치 위치에 따른 절대거리 편차에 강함)
bool isTrayItemPresent() {
  float d = readUltrasonicDistanceCm();
  if (d < 0) return false; // 센서 응답 없으면 감지 안 된 것으로 처리

  if (ultrasonicBaselineCm < 0) {
    // 기준선을 아직 못 구했으면(예: 최초 부팅 직후) 예전 절대기준으로 폴백
    return d < ULTRASONIC_CLOSE_THRESHOLD_CM;
  }
  return (ultrasonicBaselineCm - d) >= ULTRASONIC_ARRIVAL_DELTA_CM;
}

// 배출 직후: 약이 경사로를 타고 내려와 트레이 끝(초음파) 앞에 도착하는지 확인
constexpr unsigned long DISPENSE_DETECT_TIMEOUT_MS = 5000; // 경사로 이동시간 감안

// true = 도착 확인됨(초음파든 버튼이든), false = 2분 버튼대기까지 넘겨서 진짜 실패
// 예전엔 센서 정상인데 timeout난 경우도 바로 실패처리해서 doseRecord/MLP계산까지
// 다 스킵되는 버그가 있었음. 이제 센서고장이든 timeout이든 다 버튼확인으로 합류시킴
constexpr unsigned long DISPENSE_BUTTON_CONFIRM_TIMEOUT_MS = 2UL * 60 * 1000; // 2분
constexpr unsigned long DISPENSE_BUTTON_CONFIRM_REMINDER_MS = 30000; // 30초마다 재안내

// true면 이번 배출은 "초음파로 직접 확인"이 아니라 "버튼 확인"으로 통과된 것.
// 이 경우 handleDispense()에서 별도의 픽업 모니터링 단계 없이, 버튼 1회로
// 배출확인+복약확인을 동시에 처리하고 바로 MLP 계산까지 진행함.
bool dispenseConfirmedViaUnifiedButton = false;

bool waitForDispenseButtonConfirm() {
  Serial.println("[WARN] 초음파로 도착 확인 불가 - 배출/복약 확인을 버튼 1회로 통합 처리");
  tftMessage("\xec\x84\xbc\xec\x84\x9c\x20\xec\x98\xa4\xeb\xa5\x98\n\xec\x95\xbd\x20\xeb\xb0\x9b\xec\x9c\xbc\xec\x85\xa8\xec\x9c\xbc\xeb\xa9\xb4\x20\xeb\xb2\x84\xed\x8a\xbc\xec\x9d\x84\x20\xeb\x88\x8c\xeb\x9f\xac\xec\xa3\xbc\xec\x84\xb8\xec\x9a\x94"); // "센서 오류\n약 받으셨으면 버튼을 눌러주세요"
  playAlertSound("/alert_done.wav");

  unsigned long start = millis();
  unsigned long lastReminder = millis();
  while (millis() - start < DISPENSE_BUTTON_CONFIRM_TIMEOUT_MS) {
    if (isButtonPressed()) {
      Serial.println("[INFO] 버튼으로 배출+복약 확인됨(통합 처리)");
      return true;
    }
    if (!(audioWav && audioWav->isRunning()) && millis() - lastReminder >= DISPENSE_BUTTON_CONFIRM_REMINDER_MS) {
      lastReminder = millis();
      playAlertSound("/alert_done.wav");
    }
    audioLoopTick();
    delay(20);
  }
  Serial.println("[WARN] 버튼 확인 시간(2분) 초과 - 배출 실패로 처리");
  return false;
}

bool waitForDispenseDetection() {
  dispenseConfirmedViaUnifiedButton = false;

  if (!ultrasonicOnline) {
    // 센서가 아예 고장이면 낙관적으로 통과시키지 말고, 버튼으로 직접 확인받음
    bool ok = waitForDispenseButtonConfirm();
    dispenseConfirmedViaUnifiedButton = ok;
    return ok;
  }

  unsigned long start = millis();
  while (millis() - start < DISPENSE_DETECT_TIMEOUT_MS) {
    bool present = isTrayItemPresent(); // 내부에서 ultrasonicOnline도 같이 갱신됨
    if (!ultrasonicOnline) {
      // 도중에 고장나도 버튼방식으로
      bool ok = waitForDispenseButtonConfirm();
      dispenseConfirmedViaUnifiedButton = ok;
      return ok;
    }
    if (present) return true; // 초음파로 직접 확인됨 (버튼 통합처리 아님)
    delayWithAudioTick(100);
  }

  // 센서는 계속 정상 응답했지만 timeout까지 도착을 못 잡은 경우도
  // 이제는 바로 실패 확정하지 않고 버튼 확인으로 한 번 더 기회를 줌
  Serial.println("[WARN] 초음파로 도착 확인 실패(timeout) - 버튼 확인으로 전환");
  bool ok = waitForDispenseButtonConfirm();
  dispenseConfirmedViaUnifiedButton = ok;
  return ok;
}

// 논블로킹 픽업 감지 상태
bool pickupMonitoring = false;
unsigned long pickupMonitorStart = 0;
bool pickupWasPresent = false;
bool pickupUsingButtonFallback = false; // 초음파를 못 믿을 때 버튼으로 대체
MealSlot pickupMonitorSlot = MEAL_NONE;
constexpr unsigned long PICKUP_TIMEOUT_MS = 30000; // 초음파 방식 제한시간
constexpr unsigned long BUTTON_FALLBACK_TIMEOUT_MS = 5UL * 60 * 1000; // 버튼 방식은 5분
constexpr unsigned long BUTTON_FALLBACK_REMINDER_INTERVAL_MS = 30000; // 5분 동안 30초마다 알림 재생
unsigned long lastButtonFallbackReminderMs = 0;

// 마지막으로 기록한 doseRecord 경로 (픽업 감지되면 이 경로에 이어서 PATCH)
String lastDispensedRecordPath = "";

// 초음파로 감지했든 버튼으로 확인했든, 완료 처리는 완전히 동일한 데이터로 함
// 픽업 모니터링이 끝나고 시계로 복귀한 뒤에 저녁시각 계산을 실제로 수행함
// (배출~가져감 판단 도중에 다른 연산이 끼어들지 않도록 미뤄뒀던 것)
void resolvePendingEveningCalcIfNeeded() {
  if (!pendingEveningCalcForMorning) return;
  pendingEveningCalcForMorning = false;

  dynamicEveningTargetMin = predictEveningTargetMinutes(pendingEveningCalcActualMorningMin);

  char dinnerTimeBuf[6];
  snprintf(dinnerTimeBuf, sizeof(dinnerTimeBuf), "%02d:%02d",
           dynamicEveningTargetMin / 60, dynamicEveningTargetMin % 60);
  String schedulePayload = "{\"dinnerTime\":\"" + String(dinnerTimeBuf) +
                            "\",\"updatedAt\":{\".sv\":\"timestamp\"}}";
  firebasePatchFull("devices/" + String(DEVICE_ID) + "/medicationSchedule", schedulePayload);

  // 화면에 다음 복약 시간 안내: "다음 복약 시간은 OO시 OO분입니다"
  char hourBuf[3], minBuf[3];
  snprintf(hourBuf, sizeof(hourBuf), "%02d", dynamicEveningTargetMin / 60);
  snprintf(minBuf, sizeof(minBuf), "%02d", dynamicEveningTargetMin % 60);
  String nextTimeMsg = "\xeb\x8b\xa4\xec\x9d\x8c\x20\xeb\xb3\xb5\xec\x95\xbd\x20\xec\x8b\x9c\xea\xb0\x84\xec\x9d\x80\x20\n" +
                        String(hourBuf) + "\xec\x8b\x9c\x20" + String(minBuf) + "\xeb\xb6\x84\xec\x9e\x85\xeb\x8b\x88\xeb\x8b\xa4"; // "다음 복약 시간은 \nOO시 OO분입니다"
  tftMessage(nextTimeMsg.c_str());
  delayWithAudioTick(2000);
  forceClockRedraw = true;
}

void recordMedicationTaken() {
  sendNotification("picked_up", "약 가져감 확인");

  String slotLabel = (pickupMonitorSlot == MEAL_MORNING) ? "\xec\x95\x84\xec\xb9\xa8" :   // "아침"
                      (pickupMonitorSlot == MEAL_DINNER) ? "\xec\xa0\x80\xeb\x85\x81" : "" ; // "저녁"
  sendUserAlert("picked_up",
                "\xeb\xb3\xb5\xec\x95\xbd\x20\xec\x99\x84\xeb\xa3\x8c", // "복약 완료"
                slotLabel + "\x20\xec\x95\xbd\xec\x9d\x84\x20\xeb\x93\x9c\xec\x85\xa8\xec\x96\xb4\xec\x9a\x94"); // " 약을 드셨어요"

  if (lastDispensedRecordPath.length() > 0) {
    unsigned long long now = nowEpochMillis();
    String payload = "{\"pouchPickedUpAt\":" + llToString(now) +
                      ",\"estimatedTakenAt\":" + llToString(now) +
                      ",\"status\":\"TAKEN\"}";
    firebasePatchFull(lastDispensedRecordPath, payload);
    lastDispensedRecordPath = "";
  }
}

void startPickupMonitoring(MealSlot slot) {
  pickupMonitoring = true;
  pickupMonitorStart = millis();
  pickupMonitorSlot = slot;

  if (ultrasonicOnline) {
    pickupUsingButtonFallback = false;
    pickupWasPresent = isTrayItemPresent();
  } else {
    // 초음파 센서 자체가 고장 -> 처음부터 버튼으로 복약 확인하는 방식으로 전환
    pickupUsingButtonFallback = true;
    lastButtonFallbackReminderMs = millis();
    Serial.println("[WARN] 초음파 센서 이상 - 버튼으로 복약 확인하는 방식으로 전환 (5분간 유지)");
    tftMessage("\xec\x84\xbc\xec\x84\x9c \xec\x98\xa4\xeb\xa5\x98\n\xeb\xb3\xb5\xec\x9a\xa9 \xed\x9b\x84 \xeb\xb2\x84\xed\x8a\xbc\xec\x9d\x84 \xeb\x88\x84\xeb\xa5\xb4\xec\x84\xb8\xec\x9a\x94"); // "센서 오류\n복용 후 버튼을 누르세요"
    playAlertSound("/alert_done.wav"); // "버튼을 눌러 수동으로 복약 완료를 알려주세요"
    delayWithAudioTick(1500);
  }
}

void tickPickupMonitoring() {
  if (!pickupMonitoring) return;

  // 모니터링 도중 초음파가 고장나면 그 즉시 버튼 방식으로 전환
  if (!pickupUsingButtonFallback && !ultrasonicOnline) {
    pickupUsingButtonFallback = true;
    lastButtonFallbackReminderMs = millis();
    Serial.println("[WARN] 픽업 모니터링 중 초음파 이상 감지 - 버튼 방식으로 전환 (5분간 유지)");
    tftMessage("\xec\x84\xbc\xec\x84\x9c \xec\x98\xa4\xeb\xa5\x98\n\xeb\xb3\xb5\xec\x9a\xa9 \xed\x9b\x84 \xeb\xb2\x84\xed\x8a\xbc\xec\x9d\x84 \xeb\x88\x84\xeb\xa5\xb4\xec\x84\xb8\xec\x9a\x94"); // "센서 오류\n복용 후 버튼을 누르세요"
  }

  bool completed = false;

  // 버튼은 모드(초음파/버튼 대체) 상관없이 항상 먼저 확인함.
  //   isButtonPressed()는 눌림을 한 번만 감지하는 엣지 방식이라, 여기서 안 잡아주면
  //   handleStandby()의 다른 버튼 처리 로직이 대신 소비해버려서 엉뚱한 화면으로 튈 수 있음.
  if (isButtonPressed()) {
    completed = true;
  } else if (pickupUsingButtonFallback) {
    if (!(audioWav && audioWav->isRunning()) &&
        millis() - lastButtonFallbackReminderMs >= BUTTON_FALLBACK_REMINDER_INTERVAL_MS) {
      // 30초마다 다시 안내 (재생 중인 다른 소리 있으면 안 겹치게 건너뜀)
      lastButtonFallbackReminderMs = millis();
      playAlertSound("/alert_done.wav");
    }
  } else {
    bool nowPresent = isTrayItemPresent();
    if (pickupWasPresent && !nowPresent) completed = true;
  }

  if (completed) {
    recordMedicationTaken(); // 초음파/버튼 어느 쪽이든 완전히 동일한 데이터로 기록
    pickupMonitoring = false;
    forceClockRedraw = true; // 안내화면 계속 떠있던 걸 시계로 복귀시킴
    resolvePendingEveningCalcIfNeeded(); // 시계로 완전히 돌아온 뒤에 저녁시각 계산
    return;
  }

  unsigned long timeoutForThisMode = pickupUsingButtonFallback ? BUTTON_FALLBACK_TIMEOUT_MS : PICKUP_TIMEOUT_MS;
  if (millis() - pickupMonitorStart > timeoutForThisMode) {
    sendNotification("not_picked_up", "약을 가져가지 않음");
    String slotLabel = (pickupMonitorSlot == MEAL_MORNING) ? "아침" :
                        (pickupMonitorSlot == MEAL_DINNER) ? "저녁" : "";
    sendUserAlert("not_picked_up", "복약 미확인", slotLabel + " 약을 아직 가져가지 않으셨어요");
    pickupMonitoring = false;
    forceClockRedraw = true; // 안내화면 계속 떠있던 걸 시계로 복귀시킴
    resolvePendingEveningCalcIfNeeded(); // 못 가져갔어도 저녁시각 계산은 진행
  }
}

// --------------------------- 점수 산정 ---------------------------
int scoreFromReactionMs(long ms) {
  if (ms < 0) return 0; // 타임아웃
  if (ms <= REACTION_BEST_MS) return 100;
  if (ms >= REACTION_WORST_MS) return 0;
  float score = 100.0f - (ms - REACTION_BEST_MS) / 29.0f;
  if (score < 0) score = 0;
  if (score > 100) score = 100;
  return (int)round(score);
}

int scoreFromError(float errorPx, float maxErrorPx) {
  if (maxErrorPx <= 0) return 0;
  float score = 100.0f - (errorPx * 100.0f / maxErrorPx);
  if (score < 0) score = 0;
  if (score > 100) score = 100;
  return (int)round(score);
}

// --------------------------- TFT 화면 ---------------------------
// 간단한 신호 세기 아이콘으로 WiFi 상태 표시 (연결시 흰색, 미연결시 빨강)
void drawWifiIcon(int x, int y) {
  uint16_t color = isWiFiConnected() ? TFT_WHITE : TFT_RED;
  int barW = 4, gap = 2;
  for (int i = 0; i < 3; i++) {
    int barH = 6 + i * 6;
    int bx = x + i * (barW + gap);
    int by = y + (18 - barH);
    tft.fillRect(bx, by, barW, barH, color);
  }
}

void tftShowStandbyClock() {
  time_t now = time(nullptr);
  struct tm timeinfo;
  localtime_r(&now, &timeinfo);

  // 분(分) 또는 WiFi 연결 상태가 실제로 바뀌었을 때만 다시 그림 (깜빡임 방지)
  static int lastDrawnHM = -1;
  static bool lastDrawnWifi = false;
  int currentHM = timeinfo.tm_hour * 60 + timeinfo.tm_min;
  bool currentWifi = isWiFiConnected();

  if (currentHM == lastDrawnHM && currentWifi == lastDrawnWifi && !forceClockRedraw) {
    return; // 바뀐 게 없으면 화면 그대로 유지
  }
  lastDrawnHM = currentHM;
  lastDrawnWifi = currentWifi;
  forceClockRedraw = false;

  int w = tft.width();
  int h = tft.height();

  tft.fillScreen(TFT_BLACK);
  tft.setTextColor(TFT_WHITE, TFT_BLACK);
  tft.setTextDatum(TC_DATUM); // 위쪽 중앙 기준 정렬

  char timeBuf[6];
  snprintf(timeBuf, sizeof(timeBuf), "%02d:%02d", timeinfo.tm_hour, timeinfo.tm_min);
  char dateBuf[16];
  snprintf(dateBuf, sizeof(dateBuf), "%d\xec\x9b\x94 %d\xec\x9d\xbc", timeinfo.tm_mon + 1, timeinfo.tm_mday); // "N월 N일"

  constexpr int SIDE_MARGIN = 10;
  constexpr int GAP_BETWEEN = 3; // 날짜와 시간 사이 간격

  // 시간 (113pt 폰트로 확정)
  tft.loadFont("NanumGothic113", LittleFS);
  int timeW = tft.textWidth(timeBuf);
  int timeH = tft.fontHeight();

  // 날짜: 28pt 그대로
  tft.unloadFont();
  tft.loadFont("NanumGothic28", LittleFS);
  int dateH = tft.fontHeight();

  // 날짜+간격+시간 전체 블록을 화면 세로 중앙에 배치
  int totalH = dateH + GAP_BETWEEN + timeH;
  int blockTop = (h - totalH) / 2;
  int dateY = blockTop;
  int timeY = dateY + dateH + GAP_BETWEEN;

  tft.drawString(dateBuf, w / 2, dateY);
  tft.unloadFont();

  tft.loadFont("NanumGothic113", LittleFS);
  tft.drawString(timeBuf, w / 2, timeY);
  tft.unloadFont();

  tft.setTextDatum(TL_DATUM); // 기본값으로 복귀

  // WiFi 아이콘 (오른쪽 상단)
  drawWifiIcon(w - 30, 8);
}

void tftShowMedStatus() {
  int w = tft.width();
  int h = tft.height();
  int margin = w * 0.03;
  constexpr int SLOT_COUNT = 2; // 아침/저녁만 사용 (점심 미사용)
  int colW = (w - margin * (SLOT_COUNT + 1)) / SLOT_COUNT;

  tft.fillScreen(TFT_BLACK);
  tft.setTextColor(TFT_WHITE, TFT_BLACK);
  tft.setTextDatum(TC_DATUM); // 위쪽 중앙 기준 정렬
  tft.loadFont("NanumGothic28", LittleFS);

  const char* labels[SLOT_COUNT] = {"\xec\x95\x84\xec\xb9\xa8", "\xec\xa0\x80\xeb\x85\x81"}; // 아침, 저녁
  bool taken[SLOT_COUNT] = {takenMorning, takenDinner};

  for (int i = 0; i < SLOT_COUNT; i++) {
    int cx = margin + i * (colW + margin) + colW / 2;

    tft.drawString(labels[i], cx, h * 0.08);

    int iconY = h * 0.28;
    int iconR = min(colW, (int)(h * 0.16)) / 2;
    if (taken[i]) {
      // 체크 아이콘 (초록, 간단한 선 2개로 표현)
      tft.drawLine(cx - iconR, iconY, cx - iconR / 3, iconY + iconR, TFT_GREEN);
      tft.drawLine(cx - iconR / 3, iconY + iconR, cx + iconR, iconY - iconR / 2, TFT_GREEN);
      tft.drawLine(cx - iconR, iconY + 1, cx - iconR / 3, iconY + iconR + 1, TFT_GREEN);
      tft.drawLine(cx - iconR / 3, iconY + iconR + 1, cx + iconR, iconY - iconR / 2 + 1, TFT_GREEN);
    } else {
      // X 아이콘 (빨강)
      tft.drawLine(cx - iconR, iconY - iconR, cx + iconR, iconY + iconR, TFT_RED);
      tft.drawLine(cx + iconR, iconY - iconR, cx - iconR, iconY + iconR, TFT_RED);
      tft.drawLine(cx - iconR, iconY - iconR + 1, cx + iconR, iconY + iconR + 1, TFT_RED);
      tft.drawLine(cx + iconR, iconY - iconR + 1, cx - iconR, iconY + iconR + 1, TFT_RED);
    }
  }

  // 아이콘과 구분선 사이: "지금은 약 복용 시간이 아닙니다"
  tft.drawString("\xec\xa7\x80\xea\xb8\x88\xec\x9d\x80 \xec\x95\xbd \xeb\xb3\xb5\xec\x9a\xa9 \xec\x8b\x9c\xea\xb0\x84\xec\x9d\xb4 \xec\x95\x84\xeb\x8b\x99\xeb\x8b\x88\xeb\x8b\xa4", w / 2, h * 0.4);

  // 구분선
  int dividerY = h * 0.5;
  tft.drawFastHLine(margin, dividerY, w - margin * 2, TFT_WHITE);

  // 잔량 표시(2자리 0패딩, 가운데 정렬): "잔량 : 00봉"
  String remainText;
  if (cachedRemainingDoseCount >= 0) {
    char buf[4];
    snprintf(buf, sizeof(buf), "%02d", cachedRemainingDoseCount);
    remainText = "\xec\x9e\x94\xeb\x9f\x89\x20\x3a\x20" + String(buf) + "\xeb\xb4\x89"; // "잔량 : 00봉"
  } else {
    remainText = "\xec\xa0\x95\xeb\xb3\xb4 \xec\x97\x86\xec\x9d\x8c"; // "정보 없음"
  }
  tft.drawString(remainText, w / 2, h * 0.62);

  tft.unloadFont();
  tft.setTextDatum(TL_DATUM);
}

void tftMessage(const char* msg) {
  int w = tft.width();
  int h = tft.height();

  tft.fillScreen(TFT_BLACK);
  tft.setTextColor(TFT_WHITE, TFT_BLACK);
  tft.setTextDatum(MC_DATUM); // 정중앙 기준 정렬
  tft.loadFont("NanumGothic28", LittleFS);

  String fullText = String(msg);
  int splitIdx = fullText.indexOf('\n');

  if (splitIdx == -1) {
    // 줄바꿈 없으면 기존처럼 한 줄 중앙 출력
    tft.drawString(fullText, w / 2, h / 2);
  } else {
    // \n 기준으로 여러 줄 처리 (2줄까지 지원, 필요시 더 늘릴 수 있음)
    String line1 = fullText.substring(0, splitIdx);
    String rest = fullText.substring(splitIdx + 1);
    int secondSplit = rest.indexOf('\n');
    String line2 = (secondSplit == -1) ? rest : rest.substring(0, secondSplit);

    tft.drawString(line1, w / 2, h / 2 - 20);
    tft.drawString(line2, w / 2, h / 2 + 20);
  }

  tft.unloadFont();
  tft.setTextDatum(TL_DATUM);
}

// --------------------------- 버튼 입력 ---------------------------
bool isButtonPressed() {
  static bool lastState = HIGH;
  bool state = digitalRead(BUTTON_PIN);
  bool pressed = false;
  if (lastState == HIGH && state == LOW) {
    pressed = true;
  }
  lastState = state;
  return pressed;
}

bool waitForButtonPress(unsigned long timeoutMs) {
  unsigned long start = millis();
  while (millis() - start < timeoutMs) {
    if (isButtonPressed()) return true;
    delay(10);
  }
  return false;
}

// ------------------------ 순발력 측정 게임 ------------------------

// (1) 빨강->초록: 초록으로 바뀐 뒤 반응시간 측정
long gameRedGreen(int &scoreOut) {
  tft.fillScreen(TFT_RED);
  delay(500 + random(0, 2500)); // 랜덤 대기 (예측 방지), 500~3000ms

  tft.fillScreen(TFT_GREEN);
  unsigned long t0 = millis();

  long reactionMs = -1;
  if (waitForButtonPress(3000)) {
    reactionMs = millis() - t0;
  }
  scoreOut = scoreFromReactionMs(reactionMs);
  return reactionMs;
}

// (2) 움직이는 원: 좌->우로 이동하는 원이 고정된 초록 원(오른쪽)에 왔을 때 버튼
long gameMovingCircle(int &scoreOut) {
  int w = tft.width();
  int h = tft.height();
  int centerY = h / 2;

  int targetR = min(w, h) * 0.12;
  int targetX = w * 0.8;
  int movingR = targetR * 0.7;

  tft.fillScreen(TFT_BLACK);
  tft.fillCircle(targetX, centerY, targetR, TFT_GREEN); // 고정 목표

  int minX = w * 0.08;
  int maxX = w * 0.92;
  int x = minX;
  int stepX = max(2, w / 150);

  unsigned long t0 = millis();
  long errorPxResult = -1;

  while (millis() - t0 < 6000) {
    tft.fillCircle(x, centerY, movingR, TFT_BLACK); // 이전 위치 지우기 (목표 원과 안 겹치는 구간만)
    if (abs(x - targetX) > targetR + movingR) {
      // 겹치는 범위 밖일 때만 안전하게 지웠으므로 목표 원 다시 그릴 필요 없음
    } else {
      tft.fillCircle(targetX, centerY, targetR, TFT_GREEN); // 겹쳤을 수 있으니 다시 그림
    }
    x += stepX;
    if (x > maxX) x = minX;
    tft.fillCircle(x, centerY, movingR, TFT_RED);

    if (isButtonPressed()) {
      errorPxResult = abs(x - targetX);
      float maxError = (maxX - minX); // 화면 이동범위 전체를 최대오차 기준으로
      scoreOut = scoreFromError(errorPxResult, maxError);
      return errorPxResult;
    }
    delay(15);
  }
  scoreOut = 0; // 타임아웃
  return -1;
}

// (3) 줄어드는 원: 흰 테두리 원이 줄어들며 고정된 초록 원(중앙)에 맞춰졌을 때 버튼
long gameShrinkingCircle(int &scoreOut) {
  int w = tft.width();
  int h = tft.height();
  int cx = w / 2, cy = h / 2;

  int targetR = min(w, h) * 0.15;
  int startR = min(w, h) * 0.48; // 화면 최대 크기를 넘지 않는 선
  int minR = 5;

  tft.fillScreen(TFT_BLACK);
  tft.fillCircle(cx, cy, targetR, TFT_GREEN); // 고정 목표

  int currentR = startR;
  unsigned long t0 = millis();
  long errorResult = -1;

  while (currentR > minR) {
    if (currentR < startR) {
      tft.drawCircle(cx, cy, currentR + 1, TFT_BLACK); // 이전 테두리 지우기
    }
    currentR -= 1;
    if (currentR > targetR) { // 목표 원보다 클 때만 흰 테두리로 표시(겹침 방지)
      tft.drawCircle(cx, cy, currentR, TFT_WHITE);
    }

    if (isButtonPressed()) {
      errorResult = abs(currentR - targetR);
      float maxError = (startR - targetR);
      scoreOut = scoreFromError(errorResult, maxError);
      return errorResult;
    }
    delay(15);
  }
  scoreOut = 0; // 시간 내 못 누름(원이 목표보다 작아짐)
  return -1;
}

// ----------------------------------------------------
// 게임 시작 전: 안내 문구(텍스트+음성) 표시 후 3-2-1 카운트다운
// ----------------------------------------------------
void showGameInstruction(GameType g) {
  const char* text;
  const char* wavPath;

  switch (g) {
    case GAME_RED_GREEN:
      text = "\xec\xb4\x88\xeb\xa1\x9d\xec\x83\x89 \xeb\xb6\x88\xec\x9d\xb4 \xec\xbc\x9c\xec\xa7\x80\xeb\xa9\xb4\n\xeb\xb2\x84\xed\x8a\xbc\xec\x9d\x84 \xeb\x88\x84\xeb\xa5\xb4\xec\x84\xb8\xec\x9a\x94"; // "초록색 불이 켜지면\n버튼을 누르세요"
      wavPath = "/instr_redgreen.wav";
      break;
    case GAME_MOVING_CIRCLE:
      text = "\xeb\xb9\xa8\xea\xb0\x84 \xec\x9b\x90\xec\x9d\xb4 \xec\xb4\x88\xeb\xa1\x9d \xec\x9b\x90\xec\x97\x90\n\xeb\x8b\xbf\xec\x9c\xbc\xeb\xa9\xb4 \xeb\xb2\x84\xed\x8a\xbc\xec\x9d\x84 \xeb\x88\x84\xeb\xa5\xb4\xec\x84\xb8\xec\x9a\x94"; // "빨간 원이 초록 원에\n닿으면 버튼을 누르세요"
      wavPath = "/instr_moving.wav";
      break;
    default:
      text = "\xed\x9d\xb0 \xec\x9b\x90\xec\x9d\xb4 \xec\xb4\x88\xeb\xa1\x9d \xec\x9b\x90\xea\xb3\xbc\n\xea\xb0\x99\xec\x95\x84\xec\xa7\x80\xeb\xa9\xb4 \xeb\xb2\x84\xed\x8a\xbc\xec\x9d\x84 \xeb\x88\x84\xeb\xa5\xb4\xec\x84\xb8\xec\x9a\x94"; // "흰 원이 초록 원과\n같아지면 버튼을 누르세요"
      wavPath = "/instr_shrinking.wav";
      break;
  }

  int w = tft.width();
  int h = tft.height();

  tft.fillScreen(TFT_BLACK);
  tft.setTextColor(TFT_WHITE, TFT_BLACK);
  tft.setTextDatum(MC_DATUM);
  tft.loadFont("NanumGothic28", LittleFS);

  // 두 줄로 나눠서 출력 (\n 기준)
  String fullText = String(text);
  int splitIdx = fullText.indexOf('\n');
  String line1 = fullText.substring(0, splitIdx);
  String line2 = fullText.substring(splitIdx + 1);

  tft.drawString(line1, w / 2, h / 2 - 20);
  tft.drawString(line2, w / 2, h / 2 + 20);
  tft.unloadFont();
  tft.setTextDatum(TL_DATUM);

  playAlertSound(wavPath); // 안내 음성 재생 (파일 없으면 조용히 스킵됨)

  // 안내 음성이 끝날 때까지(또는 최대 4초) 대기하면서 재생 루프 유지
  unsigned long instrStart = millis();
  while ((audioWav && audioWav->isRunning()) && millis() - instrStart < 6000) {
    audioLoopTick();
    delay(10);
  }
  delay(300); // 안내 다 듣고 잠깐 여유
}

void showCountdown() {
  int w = tft.width();
  int h = tft.height();

  tft.setTextDatum(MC_DATUM);
  tft.loadFont("NanumGothic113", LittleFS);

  for (int n = 3; n >= 1; n--) {
    tft.fillScreen(TFT_BLACK);
    tft.setTextColor(TFT_WHITE, TFT_BLACK);
    char buf[2];
    snprintf(buf, sizeof(buf), "%d", n);
    tft.drawString(buf, w / 2, h / 2);
    playAlertSound("/beep.wav"); // 단순 비프음
    delayWithAudioTick(1000); // 대기 중에도 비프음이 실제로 재생되게 함
  }

  tft.unloadFont();
  tft.setTextDatum(TL_DATUM);
}

// 3개 중 랜덤 실행, 점수는 scoreOut으로 반환
long lastGameRawValue = -1; // GAME_RED_GREEN이면 반응시간(ms), 나머지는 오차(px)

// 특정 게임을 지정해서 실행 (시리얼 테스트 및 실제 랜덤 실행 둘 다 이걸 씀)
GameType runReflexGame(GameType chosen, int &scoreOut) {
  showGameInstruction(chosen);
  showCountdown();

  switch (chosen) {
    case GAME_RED_GREEN: lastGameRawValue = gameRedGreen(scoreOut); break;
    case GAME_MOVING_CIRCLE: lastGameRawValue = gameMovingCircle(scoreOut); break;
    default: lastGameRawValue = gameShrinkingCircle(scoreOut); break;
  }
  return chosen;
}

GameType runRandomReflexGame(int &scoreOut) {
  int choice = random(0, 3);
  GameType chosen = (choice == 0) ? GAME_RED_GREEN : (choice == 1) ? GAME_MOVING_CIRCLE : GAME_SHRINKING_CIRCLE;
  return runReflexGame(chosen, scoreOut);
}

String gameTypeName(GameType g) {
  switch (g) {
    case GAME_RED_GREEN: return "red_green";
    case GAME_MOVING_CIRCLE: return "moving_circle";
    default: return "shrinking_circle";
  }
}

// --------------------------- 상태별 처리 ---------------------------
// 아침 실제 배출 시각(자정 이후 분)을 받아서, MLP 모델 + 6시간 안전규칙을
// 적용한 최종 저녁 목표 시각(자정 이후 분)을 계산해서 반환
int predictEveningTargetMinutes(int actualMorningMin) {
  int morningShift = actualMorningMin - BASE_MORNING_MIN;
  int aiCandidateMin;

  if (morningShift < MORNING_SHIFT_MIN_TRAINED || morningShift > MORNING_SHIFT_MAX_TRAINED) {
    Serial.printf("[MLP][WARN] 아침 변화량(%d분)이 학습 범위(%d~%d분) 밖 - 기본 저녁시각 사용\n",
                  morningShift, MORNING_SHIFT_MIN_TRAINED, MORNING_SHIFT_MAX_TRAINED);
    aiCandidateMin = BASE_EVENING_MIN;
  } else if (!mlpModelReady) {
    Serial.println("[MLP][WARN] 모델이 초기화 안 된 상태 - 기본 저녁시각 사용");
    aiCandidateMin = BASE_EVENING_MIN;
  } else {
    float normalizedInput = morningShift / MORNING_NORM_DIVISOR;
    modelSetInput(normalizedInput, 0);

    if (!modelRunInference()) {
      Serial.println("[MLP][ERROR] 추론 실패 - 기본 저녁시각 사용");
      aiCandidateMin = BASE_EVENING_MIN;
    } else {
      float rawOutput = modelGetOutput(0);
      float denormMin = rawOutput * EVENING_DENORM_MULTIPLIER;
      int roundedMin = (int)round(denormMin);
      aiCandidateMin = BASE_EVENING_MIN + roundedMin;

      Serial.printf("[MLP] 아침변화량=%d분, 정규화입력=%.4f, 모델원본출력=%.4f, 역정규화=%.2f분, 반올림=%d분, AI후보시각=%02d:%02d\n",
                    morningShift, normalizedInput, rawOutput, denormMin, roundedMin,
                    aiCandidateMin / 60, aiCandidateMin % 60);
    }
  }

  // 최소 6시간 안전 규칙 - 항상 AI 결과보다 우선함
  int minAllowedMin = actualMorningMin + MIN_GAP_MINUTES;
  if (minAllowedMin >= 1440) {
    // 아침이 밤 9시 넘어서면 6시간 더했을 때 자정 넘어감. 다음날 스케줄은 아직 안 짜놔서 23:59로 컷
    Serial.println("[MLP][WARN] 6시간 안전규칙이 자정을 넘어감 - 23:59로 제한(다음날 스케줄은 미지원)");
    minAllowedMin = 1439;
  }
  int finalMin = max(aiCandidateMin, minAllowedMin);

  Serial.printf("[MLP] AI후보=%02d:%02d, 최소허용(6시간룰)=%02d:%02d, 최종=%02d:%02d %s\n",
                aiCandidateMin / 60, aiCandidateMin % 60,
                minAllowedMin / 60, minAllowedMin % 60,
                finalMin / 60, finalMin % 60,
                (finalMin > aiCandidateMin) ? "(안전규칙 적용됨)" : "(AI값 그대로 사용)");

  return finalMin;
}

MealSlot getActiveDispenseSlot() {
  time_t now = time(nullptr);
  struct tm timeinfo;
  localtime_r(&now, &timeinfo);
  int nowMin = timeinfo.tm_hour * 60 + timeinfo.tm_min;

  auto withinMargin = [&](MealTime mt) {
    int target = mt.hour * 60 + mt.minute;
    return abs(nowMin - target) <= DISPENSE_MARGIN_MIN;
  };

  if (!takenMorning && withinMargin(dynamicMorningSchedule)) return MEAL_MORNING;

  if (!takenDinner) {
    int eveningTargetMin = (dynamicEveningTargetMin >= 0)
                              ? dynamicEveningTargetMin
                              : (MEAL_TIME_DINNER.hour * 60 + MEAL_TIME_DINNER.minute);
    if (abs(nowMin - eveningTargetMin) <= DISPENSE_MARGIN_MIN) return MEAL_DINNER;
  }
  return MEAL_NONE;
}

// 복용 가능 시간대(스케줄 ±2시간)가 다 지났는데도 안 먹었으면(버튼 자체를 안 눌렀으면) 서버에 기록
void checkForMissedDoses() {
  time_t now = time(nullptr);
  struct tm timeinfo;
  localtime_r(&now, &timeinfo);
  int nowMin = timeinfo.tm_hour * 60 + timeinfo.tm_min;

  // --- 아침: 1시간 경과 리마인더 ---
  if (!takenMorning && !morningReminder1hrSent) {
    int morningTarget = dynamicMorningSchedule.hour * 60 + dynamicMorningSchedule.minute;
    if (nowMin > morningTarget + 60) {
      morningReminder1hrSent = true;
      Serial.println("[INFO] 아침 복용 1시간 경과 리마인더");
      sendNotification("reminder", "아침약 복용 시간 1시간 경과");
      sendUserAlert("reminder", "\xeb\xb3\xb5\xec\x95\xbd\x20\xec\x95\x8c\xeb\xa6\xbc", "\xec\x95\x84\xec\xb9\xa8\x20\xec\x95\xbd\x20\xeb\x93\x9c\xec\x8b\xa4\x20\xec\x8b\x9c\xea\xb0\x84\xec\x9d\xb4\x20" "1" "\xec\x8b\x9c\xea\xb0\x84\x20\xec\xa7\x80\xeb\x82\xac\xec\x96\xb4\xec\x9a\x94\x2e\x20\xed\x99\x95\xec\x9d\xb8\xed\x95\xb4\xec\xa3\xbc\xec\x84\xb8\xec\x9a\x94"); // "복약 알림" / "아침 약 드실 시간이 1시간 지났어요. 확인해주세요"
    }
  }

  // --- 저녁: 1시간 경과 리마인더 ---
  if (!takenDinner && !dinnerReminder1hrSent) {
    int eveningTargetMinForReminder = (dynamicEveningTargetMin >= 0)
                              ? dynamicEveningTargetMin
                              : (MEAL_TIME_DINNER.hour * 60 + MEAL_TIME_DINNER.minute);
    if (nowMin > eveningTargetMinForReminder + 60) {
      dinnerReminder1hrSent = true;
      Serial.println("[INFO] 저녁 복용 1시간 경과 리마인더");
      sendNotification("reminder", "저녁약 복용 시간 1시간 경과");
      sendUserAlert("reminder", "\xeb\xb3\xb5\xec\x95\xbd\x20\xec\x95\x8c\xeb\xa6\xbc", "\xec\xa0\x80\xeb\x85\x81\x20\xec\x95\xbd\x20\xeb\x93\x9c\xec\x8b\xa4\x20\xec\x8b\x9c\xea\xb0\x84\xec\x9d\xb4\x20" "1" "\xec\x8b\x9c\xea\xb0\x84\x20\xec\xa7\x80\xeb\x82\xac\xec\x96\xb4\xec\x9a\x94\x2e\x20\xed\x99\x95\xec\x9d\xb8\xed\x95\xb4\xec\xa3\xbc\xec\x84\xb8\xec\x9a\x94"); // "복약 알림" / "저녁 약 드실 시간이 1시간 지났어요. 확인해주세요"
    }
  }

  // --- 아침: 2시간 경과(마진 끝) = 미복용 확정 ---
  if (!takenMorning && !morningWindowMissedReported) {
    int morningTarget = dynamicMorningSchedule.hour * 60 + dynamicMorningSchedule.minute;
    if (nowMin > morningTarget + DISPENSE_MARGIN_MIN) {
      morningWindowMissedReported = true;
      Serial.println("[INFO] 아침 복용 시간대 종료, 미복용으로 기록");
      sendNotification("missed_dose", "아침약 복용 시간대가 지났는데 복용 안 함");
      sendUserAlert("missed_dose", "복약 놓침", "아침 약 드실 시간이 지났어요");

      if (cachedOwnerUid.length() > 0) {
        String today = getTodayDateString();
        unsigned long long scheduledAt = mealTimeToEpochMillisToday(dynamicMorningSchedule);
        String payload = "{\"scheduledAt\":" + llToString(scheduledAt) + ",\"status\":\"MISSED\"}";
        firebasePutFull("users/" + cachedOwnerUid + "/doseRecords/" + today + "/morning", payload);
      }
    }
  }

  // --- 저녁: 2시간 경과(마진 끝) = 미복용 확정 ---
  if (!takenDinner && !dinnerWindowMissedReported) {
    int eveningTargetMin = (dynamicEveningTargetMin >= 0)
                              ? dynamicEveningTargetMin
                              : (MEAL_TIME_DINNER.hour * 60 + MEAL_TIME_DINNER.minute);
    if (nowMin > eveningTargetMin + DISPENSE_MARGIN_MIN) {
      dinnerWindowMissedReported = true;
      Serial.println("[INFO] 저녁 복용 시간대 종료, 미복용으로 기록");
      sendNotification("missed_dose", "저녁약 복용 시간대가 지났는데 복용 안 함");
      sendUserAlert("missed_dose", "복약 놓침", "저녁 약 드실 시간이 지났어요");

      if (cachedOwnerUid.length() > 0) {
        String today = getTodayDateString();
        MealTime eveningMt = { (uint8_t)(eveningTargetMin / 60), (uint8_t)(eveningTargetMin % 60) };
        unsigned long long scheduledAt = mealTimeToEpochMillisToday(eveningMt);
        String payload = "{\"scheduledAt\":" + llToString(scheduledAt) + ",\"status\":\"MISSED\"}";
        firebasePutFull("users/" + cachedOwnerUid + "/doseRecords/" + today + "/evening", payload);
      }
    }
  }
}

void resetDailyFlagsIfNewDay() {
  time_t now = time(nullptr);
  struct tm timeinfo;
  localtime_r(&now, &timeinfo);
  if (timeinfo.tm_mday != lastResetDay) {
    takenMorning = false;
    takenDinner = false;
    morningWindowMissedReported = false;
    dinnerWindowMissedReported = false;
    morningReminder1hrSent = false;
    dinnerReminder1hrSent = false;
    dynamicEveningTargetMin = -1; // AI 저녁시각도 초기화 (오늘 아침 배출 후 다시 계산됨)
    lastResetDay = timeinfo.tm_mday;
    Serial.println("[INFO] 하루가 바뀌어 복약 상태 초기화");
  }
}

void markTaken(MealSlot slot) {
  switch (slot) {
    case MEAL_MORNING: takenMorning = true; break;
    case MEAL_DINNER:  takenDinner = true;  break;
    default: break;
  }
}

String mealSlotName(MealSlot slot) {
  switch (slot) {
    case MEAL_MORNING: return "morning";
    case MEAL_DINNER:  return "dinner";
    default: return "none";
  }
}

// ---------------- 대기 모드 ----------------
unsigned long long buttonPressedAtEpochMs = 0; // 예약 슬롯(아침/점심/저녁) 진입시 버튼 누른 시각
GameType lastGamePlayedType = GAME_RED_GREEN;
int lastGameScore = 0;

// ---------------------------------------------------------
// 복약 가능 시간 LED 점멸 (0.5초 간격, 논블로킹)
// ---------------------------------------------------------
void updateMedicationLed(bool shouldBlink) {
  static unsigned long lastToggleMs = 0;
  static bool ledOn = false;

  if (!shouldBlink) {
    if (ledOn) {
      digitalWrite(MED_LED_PIN, LOW);
      ledOn = false;
    }
    return;
  }

  if (millis() - lastToggleMs >= 500) {
    lastToggleMs = millis();
    ledOn = !ledOn;
    digitalWrite(MED_LED_PIN, ledOn ? HIGH : LOW);
  }
}

void handleStandby() {
  // 아래 폴링들 다 Firebase 호출이라 TLS 핸드셰이크로 몇백ms~2초씩 먹음.
  // 알림음 재생 중엔 끊기니까 그동안은 건너뜀
  bool audioCurrentlyPlaying = (audioWav && audioWav->isRunning());

  if (!audioCurrentlyPlaying) {
    resetDailyFlagsIfNewDay();
    checkForMissedDoses();
    fetchOwnerUidIfNeeded();
    fetchMorningScheduleIfDue();
    fetchInventoryIfDue();
    sendHeartbeatIfDue();
    checkForPendingCommand(); // 원격 "지금 꺼내기" 명령이 있으면 여기서 상태 전환됨
    checkForSetupCommand();   // 로드셀 영점 등 초기 설정 명령 확인
  }
  tickPickupMonitoring(); // 로컬 판단(초음파/버튼)이라 항상 체크, 완료되는 그 순간만 네트워크 호출 발생

  MealSlot activeSlot = getActiveDispenseSlot();
  updateMedicationLed(activeSlot != MEAL_NONE);

  // 복용 가능 시간대가 "방금 열렸을 때"(꺼져있다가 켜지는 순간)만 1번 안내
  static MealSlot lastActiveSlot = MEAL_NONE;
  if (activeSlot != MEAL_NONE && lastActiveSlot == MEAL_NONE) {
    playAlertSound("/alert_eat.wav"); // "약 드실 시간입니다. 버튼을 눌러주세요."
  }
  lastActiveSlot = activeSlot;

  if (isButtonPressed()) {
    if (activeSlot != MEAL_NONE) {
      if (cachedRemainingDoseCount == 0) {
        // 약이 없어서 배출 불가
        tftMessage("\xec\x95\xbd\xec\x9d\xb4\x20\xec\x97\x86\xec\x96\xb4\xec\x84\x9c\n\xeb\xb0\xb0\xec\xb6\x9c\xed\x95\xa0\x20\xec\x88\x98\x20\xec\x97\x86\xec\x8a\xb5\xeb\x8b\x88\xeb\x8b\xa4"); // "약이 없어서\n배출할 수 없습니다"
        delayWithAudioTick(2000);
        sendNotification("out_of_stock", "복약 시간인데 약이 없어서 배출 못 함");
        sendUserAlert("out_of_stock",
                      "\xec\x95\xbd\x20\xec\x86\x8c\xec\xa7\x84",
                      "\xec\x95\xbd\xec\x9d\xb4\x20\xec\x97\x86\xec\x96\xb4\xec\x84\x9c\x20\xeb\xb3\xb5\xec\x95\xbd\x20\xec\x8b\x9c\xea\xb0\x84\xec\x97\x90\x20\xeb\xb0\xb0\xec\xb6\x9c\xed\x95\x98\xec\xa7\x80\x20\xeb\xaa\xbb\xed\x96\x88\xec\x8a\xb5\xeb\x8b\x88\xeb\x8b\xa4"); // "약 소진" / "약이 없어서 복약 시간에 배출하지 못했습니다"
        forceClockRedraw = true;
        return;
      }
      pendingMealSlot = activeSlot;
      buttonPressedAtEpochMs = nowEpochMillis();
      currentState = STATE_REFLEX_TEST;
      abnormalPressCount = 0;
      return;
    } else {
      // 복약 상태 화면으로 전환 (아침/점심/저녁 + 잔여일수 한 화면에 표시)
      currentState = STATE_MED_STATUS;
      medStatusEnterTime = millis();
      tftShowMedStatus();

      unsigned long nowMs = millis();
      if (nowMs - abnormalWindowStart > ABNORMAL_WINDOW_MS) {
        abnormalWindowStart = nowMs;
        abnormalPressCount = 0;
      }
      abnormalPressCount++;
      if (abnormalPressCount >= ABNORMAL_PRESS_THRESHOLD) {
        sendNotification("abnormal_input", "비정상적인 버튼 입력이 반복됩니다");
        abnormalPressCount = 0;
      }
      return;
    }
  }

  static unsigned long lastClockUpdate = 0;
  // 버튼으로 복약확인 대기 중(5분)엔 안내화면을 그대로 유지 (시계로 덮어쓰지 않음)
  bool holdingButtonFallbackScreen = pickupMonitoring && pickupUsingButtonFallback;
  if (!holdingButtonFallbackScreen && millis() - lastClockUpdate > 1000) {
    tftShowStandbyClock();
    lastClockUpdate = millis();
  }
}

// ---------------- 복약 상태 화면 모드 ----------------
void handleMedStatus() {
  unsigned long elapsed = millis() - medStatusEnterTime;
  if (elapsed > MED_STATUS_AUTO_RETURN_MS) {
    forceClockRedraw = true;
    currentState = STATE_STANDBY;
  }
}

// ---------------- 순발력 측정 모드 ----------------
void handleReflexTest() {
  int score = 0;
  GameType playedGame = runRandomReflexGame(score);
  lastGamePlayedType = playedGame;
  lastGameScore = score;

  // 원격 명령이든 예약 슬롯이든 동일하게 게임을 거침 (사용자 확인)
  String slotForLog = (pendingCommandId.length() > 0) ? "remote" : mealSlotName(pendingMealSlot);
  sendGameScore(pendingMealSlot, gameTypeName(playedGame) + "(" + slotForLog + ")", score);
  // 결과는 화면에 표시하지 않고 바로 배출로 진행 (보호자만 서버에서 확인)

  currentState = STATE_DISPENSE;
}

// ---------------- 약 배출 모드 ----------------
void handleDispense() {
  bool isRemoteCommand = (pendingCommandId.length() > 0);

  if (!isRemoteCommand && pendingMealSlot == MEAL_NONE) {
    forceClockRedraw = true;
    currentState = STATE_STANDBY;
    return;
  }

  tftMessage("\xeb\xb0\xb0\xec\xb6\x9c\xec\xa4\x91..."); // "배출중..."

  captureUltrasonicBaseline(); // 아직 약 없는(빈 경사로) 상태를 기준선으로 저장
  playAlertSound("/dispense_alert.wav"); // "약이 배출중입니다. 잠시만 기다려주세요" - 서보 회전과 동시에 시작

  if (isRemoteCommand) {
    dispenseRemote(pendingCommandMorningDoses, pendingCommandEveningDoses);
  } else {
    dispenseMedication(pendingMealSlot);
    decrementInventory(pendingMealSlot); // 아침->morning, 저녁->evening 및 전체(remainingDoseCount) 각 1개씩 차감
  }

  // 약이 경사로를 타고 내려와 트레이(초음파) 앞에 도착했는지 확인
  bool trayDetected = waitForDispenseDetection();

  // 이 아래 Firebase 호출들이 블로킹이라 오디오가 끊길 수 있어서, 통신 전에 안내음성부터 끝까지(최대 8초) 재생
  unsigned long dispenseAudioStart = millis();
  while ((audioWav && audioWav->isRunning()) && millis() - dispenseAudioStart < 8000) {
    audioLoopTick();
    delay(10);
  }

  if (!trayDetected) {
    // 실패면 여기서 끝 - 저녁시각 계산이나 복약완료 처리는 안 태움
    tftMessage("\xec\x95\xbd\x20\xeb\xb0\xb0\xec\xb6\x9c\xec\x9d\xb4\x0a\xec\xa0\x9c\xeb\x8c\x80\xeb\xa1\x9c\x20\xeb\x90\x98\xec\xa7\x80\x20\xec\x95\x8a\xec\x95\x98\xec\x8a\xb5\xeb\x8b\x88\xeb\x8b\xa4"); // "약 배출이\n제대로 되지 않았습니다"
    delayWithAudioTick(2000);
    sendNotification("dispense_failed", "\xec\x95\xbd\xec\x9d\xb4\x20\xed\x8a\xb8\xeb\xa0\x88\xec\x9d\xb4\xea\xb9\x8c\xec\xa7\x80\x20\xeb\x8f\x84\xeb\x8b\xac\xed\x95\x98\xec\xa7\x80\x20\xec\x95\x8a\xec\x9d\x8c\x28\xea\xb2\xbd\xec\x82\xac\xeb\xa1\x9c\x20\xea\xb1\xb8\xeb\xa6\xbc\x20\xec\x9d\x98\xec\x8b\xac\x29"); // "약이 트레이까지 도달하지 않음(경사로 걸림 의심)"
    sendUserAlert("dispense_failed",
                  "\xea\xb8\xb0\xea\xb8\xb0\x20\xed\x99\x95\xec\x9d\xb8\x20\xed\x95\x84\xec\x9a\x94", // "기기 확인 필요"
                  "\xec\x95\xbd\x20\xeb\xb0\xb0\xec\xb6\x9c\x20\xec\x98\xa4\xeb\xa5\x98\xea\xb0\x80\x20\xeb\xb0\x9c\xec\x83\x9d\xed\x96\x88\xec\x8a\xb5\xeb\x8b\x88\xeb\x8b\xa4\x2e"); // "약 배출 오류가 발생했습니다."

    firebasePatchFull("devices/" + String(DEVICE_ID) + "/componentErrors",
      "{\"dispenser\":\"\xeb\xb0\xb0\xec\xb6\x9c\x20\xed\x9b\x84\x20\xed\x8a\xb8\xeb\xa0\x88\xec\x9d\xb4\xec\x97\x90\xec\x84\x9c\x20\xec\x95\xbd\xec\x9d\xb4\x20\xea\xb0\x90\xec\xa7\x80\xeb\x90\x98\xec\xa7\x80\x20\xec\x95\x8a\xec\x9d\x8c\"}"); // "배출 후 트레이에서 약이 감지되지 않음"

    if (isRemoteCommand) {
      String cmdPayload = "{\"status\":\"FAILED\",\"completedAt\":{\".sv\":\"timestamp\"}}";
      firebasePatchFull("devices/" + String(DEVICE_ID) + "/commands/" + pendingCommandId, cmdPayload);
      pendingCommandId = "";
    }

    pendingMealSlot = MEAL_NONE;
    forceClockRedraw = true;
    currentState = STATE_STANDBY;
    return;
  }

  // --- 여기부터는 트레이 도착이 확인됐을 때(또는 센서고장으로 판단보류)만 진행 ---
  tftMessage("\xec\x99\x84\xeb\xa3\x8c!"); // "완료!"
  firebasePatchFull("devices/" + String(DEVICE_ID) + "/componentErrors", "{\"dispenser\":null}");

  if (isRemoteCommand) {
    // --- 원격 명령 완료 처리: commands/{id} 에 결과 이어붙이기(PATCH) ---
    String cmdPayload = "{\"status\":\"COMPLETED\",\"completedAt\":{\".sv\":\"timestamp\"}}";
    firebasePatchFull("devices/" + String(DEVICE_ID) + "/commands/" + pendingCommandId, cmdPayload);

    sendNotification("dispensed", "\xec\x9b\x90\xea\xb2\xa9 \xeb\xaa\x85\xeb\xa0\xb9\xec\x9c\xbc\xeb\xa1\x9c \xec\x95\xbd \xeb\xb0\xb0\xec\xb6\x9c \xec\x99\x84\xeb\xa3\x8c"); // "원격 명령으로 약 배출 완료"
    pendingCommandId = "";
  } else {
    // --- 예약 슬롯 완료 처리: users/{ownerUid}/doseRecords/{date}/{slot} 기록 ---
    markTaken(pendingMealSlot);
    sendNotification("dispensed", mealSlotName(pendingMealSlot) + " 약 배출 완료");

    if (cachedOwnerUid.length() > 0) {
      String slotName = mealSlotName(pendingMealSlot);
      String today = getTodayDateString();
      MealTime mt = (pendingMealSlot == MEAL_MORNING) ? dynamicMorningSchedule : MEAL_TIME_DINNER;
      unsigned long long scheduledAt = mealTimeToEpochMillisToday(mt);
      unsigned long long dispensedAt = nowEpochMillis();

      long reactionMs = (lastGamePlayedType == GAME_RED_GREEN) ? lastGameRawValue : -1;

      // 아침약이면, 저녁 목표시각 계산을 "지금" 하지 않고 픽업 모니터링이 완전히
      // 끝나서 시계 화면으로 복귀한 뒤로 미룸 (배출~가져감 처리 도중엔 다른 연산 안 끼어들게)
      if (pendingMealSlot == MEAL_MORNING) {
        time_t nowT = time(nullptr);
        struct tm ti;
        localtime_r(&nowT, &ti);
        pendingEveningCalcActualMorningMin = ti.tm_hour * 60 + ti.tm_min;
        pendingEveningCalcForMorning = true;
      }

      String payload = "{";
      payload += "\"scheduledAt\":" + llToString(scheduledAt) + ",";
      payload += "\"programScore\":" + String(lastGameScore) + ",";
      if (reactionMs >= 0) payload += "\"reactionTimeMillis\":" + String(reactionMs) + ",";
      payload += "\"buttonPressedAt\":" + llToString(buttonPressedAtEpochMs) + ",";
      payload += "\"dispenseDetected\":true,";
      payload += "\"dispensedAt\":" + llToString(dispensedAt) + ",";
      payload += "\"status\":\"DISPENSED\"";
      payload += "}";

      String recordPath = "users/" + cachedOwnerUid + "/doseRecords/" + today + "/" + slotName;
      firebasePutFull(recordPath, payload); // 오늘 이 슬롯 기록은 새로 만드는 것이므로 PUT(덮어쓰기)로 충분
      lastDispensedRecordPath = recordPath; // 픽업 감지되면 이어서 PATCH
    } else {
      Serial.println("[WARN] ownerUid를 아직 못 받아서 doseRecord 기록을 건너뜁니다");
    }
  }

  if (dispenseConfirmedViaUnifiedButton) {
    // 초음파를 못 믿어서 버튼 1회로 배출확인을 받은 경우: 그 버튼 1회를 "복약까지 완료"로
    // 간주하고, 별도의 픽업 모니터링(추가 버튼 대기) 없이 바로 완료 처리 + MLP 계산까지 진행함.
    pickupMonitorSlot = isRemoteCommand ? MEAL_NONE : pendingMealSlot;
    recordMedicationTaken();          // picked_up 알림 + (있다면) doseRecord를 TAKEN으로 PATCH
    resolvePendingEveningCalcIfNeeded(); // 아침이었다면 여기서 바로 MLP 계산 + dinnerTime 갱신
  } else {
    startPickupMonitoring(isRemoteCommand ? MEAL_NONE : pendingMealSlot);
  }

  delayWithAudioTick(1000); // "완료!" 표시 유지 + 안내음성 마저 재생
  pendingMealSlot = MEAL_NONE;
  forceClockRedraw = true;
  currentState = STATE_STANDBY;
}

// ------------------------------ setup ------------------------------
// 부팅 시 버튼을 3초 이상 누르고 있으면 저장된 WiFi 정보를 지우고 설정모드(B-OMM)로 재진입
// 시리얼 모니터에 "reset" 입력하면 저장된 WiFi 정보를 지우고 재부팅
void resetWifiCredentials() {
  Serial.println("[INFO] WiFi 정보 초기화 실행");
  wifiPrefs.begin("wifi", false);
  wifiPrefs.clear();
  wifiPrefs.end();

  tftMessage("WiFi 정보가\n초기화되었습니다");
  delay(1500);
  ESP.restart();
}

void setup() {
  Serial.begin(115200);
  delay(300);
  Serial.println();
  Serial.println("=== 스마트 복약 관리기 시작 (v2) ===");

  randomSeed(esp_random());

  // TFT를 WiFi 연결보다 먼저 초기화 (WiFi 설정 모드 진입 시 화면 안내를 위해)
  pinMode(TFT_LED_PIN, OUTPUT);
  digitalWrite(TFT_LED_PIN, HIGH);
  tft.init();
  tft.setRotation(1);
  tft.fillScreen(TFT_BLACK);

  // LittleFS도 WiFi 연결보다 먼저 마운트 (설정화면 폰트 로딩을 위해)
  if (!LittleFS.begin(true)) {
    Serial.println("[WARN] LittleFS 마운트 실패 (알림음/폰트 재생 불가)");
  }

  connectWiFi(); // 저장된 WiFi 없거나 연결 실패 시 여기서 설정모드로 빠져 재부팅될 때까지 안 돌아옴
  setupTime();
  deviceBootEpochMs = nowEpochMillis(); // 이 시각 이전의 setup 명령은 오래된 것으로 간주하고 무시

  // 저녁약 시각 AI 조정용 MLP 모델 초기화
  mlpModelReady = modelInit(medication_model, mlpTensorArena, MLP_TENSOR_ARENA_SIZE);
  if (mlpModelReady) {
    Serial.println("[MLP] 모델 초기화 성공");
    // 알려진 예시값으로 자체 검증: 아침 07:00(420분) 배출 -> 문서 예시상 대략 16:30 근처 기대
    Serial.println("[MLP] 자체 검증 테스트 (아침 07:00 배출 가정)");
    int testResult = predictEveningTargetMinutes(420);
    Serial.printf("[MLP] 검증 결과 최종 저녁시각 = %02d:%02d\n", testResult / 60, testResult % 60);
  } else {
    Serial.println("[MLP][ERROR] 모델 초기화 실패 - 저녁시각은 항상 기본값(18:00) 사용됨");
  }

  audioOut = new AudioOutputI2S();
  audioOut->SetPinout(I2S_BCLK_PIN, I2S_LRC_PIN, I2S_DOUT_PIN);
  audioOut->SetGain(AUDIO_IDLE_GAIN);

  // (HX711 로드셀 초기화 제거됨 - 사용 안 함)

  ESP32PWM::allocateTimer(0);
  ESP32PWM::allocateTimer(1);
  ESP32PWM::allocateTimer(2);
  ESP32PWM::allocateTimer(3);

  servoMorning.setPeriodHertz(50);
  servoMorning.attach(SERVO_MORNING_PIN, 500, 2400);
  servoDinner.setPeriodHertz(50);
  servoDinner.attach(SERVO_DINNER_PIN, 500, 2400);
  // attach만 해두고 부팅시 특정 각도로 안 돌림 - 예전에 이것 때문에 역행하는 것처럼 보였음

  pinMode(BUTTON_PIN, INPUT_PULLUP);
  pinMode(ULTRASONIC_TRIG_PIN, OUTPUT);
  pinMode(ULTRASONIC_ECHO_PIN, INPUT);
  pinMode(MED_LED_PIN, OUTPUT);
  digitalWrite(MED_LED_PIN, LOW);

  abnormalWindowStart = millis();

  Serial.println("[INFO] 초기화 완료, 대기 모드 진입");
}

// ------------------------------- loop -------------------------------
void loop() {
  audioLoopTick();
  checkEmergencyButtonHold(); // 게임/배출 중이든 상관없이 5초 누르면 비상알림

  switch (currentState) {
    case STATE_STANDBY:
      handleStandby();
      break;
    case STATE_MED_STATUS:
      handleMedStatus();
      break;
    case STATE_REFLEX_TEST:
      handleReflexTest();
      break;
    case STATE_DISPENSE:
      handleDispense();
      break;
  }

  if (Serial.available()) {
    String cmd = Serial.readStringUntil('\n');
    cmd.trim();
    if (cmd == "status") tftShowMedStatus();
    else if (cmd == "reset") resetWifiCredentials();
    else if (cmd == "us") {
      // 초음파 센서 한 번 측정
      float d = readUltrasonicDistanceCm();
      if (ultrasonicOnline) {
        if (ultrasonicBaselineCm >= 0) {
          float delta = ultrasonicBaselineCm - d;
          Serial.printf("[US] 거리=%.2fcm, 기준선=%.2fcm, 차이=%.2fcm (감지기준=%.1fcm이상 -> %s)\n",
                        d, ultrasonicBaselineCm, delta, ULTRASONIC_ARRIVAL_DELTA_CM,
                        (delta >= ULTRASONIC_ARRIVAL_DELTA_CM) ? "감지됨" : "감지안됨");
        } else {
          Serial.printf("[US] 거리=%.2fcm (기준선 아직 없음, 폴백기준=%.1fcm미만 -> %s)\n",
                        d, ULTRASONIC_CLOSE_THRESHOLD_CM,
                        (d < ULTRASONIC_CLOSE_THRESHOLD_CM) ? "감지됨" : "감지안됨");
        }
      } else {
        Serial.println("[US] 응답 없음 (센서 연결/배선 확인 필요)");
      }
    }
    else if (cmd == "usbase") {
      // 지금 상태(약이 없는 상태여야 함)를 기준선으로 강제 저장 - 시리얼 테스트용
      captureUltrasonicBaseline();
    }
    else if (cmd == "usmon") {
      // 초음파 센서 연속 모니터링 (10초간 0.2초 간격, 아무 키나 입력하면 조기 종료)
      Serial.println("[US] 연속 모니터링 시작 (10초간, 아무 키 입력하면 중단)");
      unsigned long monStart = millis();
      while (millis() - monStart < 10000) {
        if (Serial.available()) { Serial.read(); break; }
        float d = readUltrasonicDistanceCm();
        if (ultrasonicOnline) {
          Serial.printf("[US] %.2fcm %s\n", d, (d < ULTRASONIC_CLOSE_THRESHOLD_CM) ? "<- 감지됨" : "");
        } else {
          Serial.println("[US] 응답 없음");
        }
        delay(200);
      }
      Serial.println("[US] 모니터링 종료");
    }
    else if (cmd == "test") {
      // 실제 버튼을 눌러서 아침약을 배출하는 것과 동일한 전체 흐름(게임+음성안내+배출+AI계산)을 트리거
      Serial.println("[TEST] 버튼 누른 것처럼 전체 흐름 시작 (게임 -> 배출 -> AI저녁시각계산)");
      pendingMealSlot = MEAL_MORNING;
      buttonPressedAtEpochMs = nowEpochMillis();
      currentState = STATE_REFLEX_TEST;
    }
    else if (cmd == "game1" || cmd == "game2" || cmd == "game3") {
      // 배출/서버 통신 없이 게임 화면+음성+판정만 단독으로 테스트
      GameType g = (cmd == "game1") ? GAME_RED_GREEN :
                   (cmd == "game2") ? GAME_MOVING_CIRCLE : GAME_SHRINKING_CIRCLE;
      Serial.println("[TEST] 게임 단독 실행: " + gameTypeName(g));
      int score = 0;
      runReflexGame(g, score);
      Serial.printf("[TEST] 게임 종료, 점수=%d, 원시값=%ld\n", score, lastGameRawValue);
      forceClockRedraw = true;
    }
    else if (cmd.startsWith("mlp ")) {
      // 사용법: 시리얼에 "mlp 07:30" 처럼 입력하면 그 시각으로 아침 배출됐다고 가정하고 테스트
      String timeStr = cmd.substring(4);
      timeStr.trim();
      MealTime testTime;
      if (parseHHMM(timeStr, testTime)) {
        int testMin = testTime.hour * 60 + testTime.minute;
        Serial.printf("[MLP] 테스트: 아침 %02d:%02d 배출 가정\n", testTime.hour, testTime.minute);
        int result = predictEveningTargetMinutes(testMin);
        Serial.printf("[MLP] 테스트 결과 최종 저녁시각 = %02d:%02d\n", result / 60, result % 60);
      } else {
        Serial.println("[WARN] 형식이 잘못됐어요. 예: mlp 07:30");
      }
    }
    else if (cmd == "morning") {
      Serial.println("[TEST] 아침 서보 동작 테스트");
      dispenseServo(servoMorning);
    } else if (cmd == "dinner") {
      Serial.println("[TEST] 저녁 서보 동작 테스트");
      dispenseServo(servoDinner);
    } else if (cmd.startsWith("spin ")) {
      // 사용법: spin <값(0~180)> <시간ms>   예) spin 0 2000
      int spaceIdx = cmd.indexOf(' ', 5);
      int value, durationMs;
      if (spaceIdx == -1) {
        value = cmd.substring(5).toInt();
        durationMs = 2000;
      } else {
        value = cmd.substring(5, spaceIdx).toInt();
        durationMs = cmd.substring(spaceIdx + 1).toInt();
      }
      Serial.printf("[TEST] 아침 서보 spin: value=%d, duration=%dms\n", value, durationMs);
      servoMorning.write(value);
      delay(durationMs);
      servoMorning.write(SERVO_STOP_VALUE);
      Serial.println("[TEST] 정지");
    }
  }
}
